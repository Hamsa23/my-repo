#!/bin/bash
#
# (C) Copyright 2019 Hewlett Packard Enterprise Development LP
#
#
#  run_api.sh
#
#  Initialize database and run the API
#
export APPDIR=/opt/app/eim
cd ${APPDIR}

# Setup SSL certificates
if [ ! -d /opt/shared/ssl ]; then
	mkdir /opt/shared/ssl
fi

if [ ! -f /opt/shared/ssl/server.crt ]; then
	openssl req -x509 -nodes -days 4096 \
                -subj "/C=US/ST=Texas/L=Houston/O=HPE/CN=hpe-eim" \
                -newkey rsa:2048 \
                -keyout /opt/shared/ssl/server.key \
                -out /opt/shared/ssl/server.crt
    chmod 600 /opt/shared/ssl/server.key
fi

/usr/sbin/nginx
