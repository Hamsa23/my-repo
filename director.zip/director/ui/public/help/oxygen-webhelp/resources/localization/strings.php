<?php
$translate = array();


global $translate;
?>