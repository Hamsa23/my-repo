let compression = require('compression');
let express = require('express');
let http = require('http');
let morgan = require('morgan');
let bodyParser = require('body-parser');
let cookieParser = require('cookie-parser');
let path = require('path');

const PORT = process.env.PORT || 8102;

let app = express()
  .use(compression())
  .use(cookieParser())
  .use(morgan('tiny'))
  .use(bodyParser.json());

// UI
app.use('/', express.static(path.join(__dirname, '/../dist')));
app.get('/*', (req, res) => {
  res.sendFile(path.resolve(path.join(__dirname, '/../dist/index.html')));
});

app.listen(PORT);

console.log(`Server started at http://localhost:${PORT}`);
