// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import AnnotatedMeter from '../components/AnnotatedMeter';
import Box from 'grommet/components/Box';
import DocsArticle from './DocsArticle';
import { loadDashboard, changePowerState } from '../actions/dashboard';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Tabs from 'grommet/components/Tabs';
import Tab from 'grommet/components/Tab';
import Label from 'grommet/components/Label';
import Anchor from 'grommet/components/Anchor';
import Paragraph from 'grommet/components/Paragraph';
import Notification from 'grommet/components/Notification';
import Spinning from 'grommet/components/icons/Spinning';
import PowerIcon from 'grommet/components/icons/base/Power';
import LayerForm from 'grommet-templates/components/LayerForm';
import RadioButton from 'grommet/components/RadioButton';

Label.displayName = 'Dashboard';

class DashBoard extends Component {

  constructor () {
    super();
    this._onClickStatus = this._onClickStatus.bind(this);
    this._getData = this._getData.bind(this);
    this._getServers = this._getServers.bind(this);
    this._getSelectedServers = this._getSelectedServers.bind(this);
    this._getServerInfo = this._getServerInfo.bind(this);
    this._onClickServerTab = this._onClickServerTab.bind(this);
    this._onClickChassisTab = this._onClickChassisTab.bind(this);
    this._openServerWindow = this._openServerWindow.bind(this);
    this._changePowerState = this._changePowerState.bind(this);
    this._PowerSettings = this._PowerSettings.bind(this);
    this._Settings = this._Settings.bind(this);
    this._onLayerClose = this._onLayerClose.bind(this);
    this._onCloseMsg = this._onCloseMsg.bind(this);
    this.state = {
      unknown: undefined,
      status: "Total",
      defaultVal: '',
      rowSelected: false,
      serverRowSelected: 0,
      selectedChassis: undefined,
      selectedSystem : undefined,
      statusSelected: undefined,
      tabActiveIndex: 0,
      biosVersion: undefined,
      dnsName: undefined,
      dateTime: undefined,
      fwVersion: undefined,
      hostName: undefined,
      macAddress: undefined,
      managerIP: undefined,
      serverPLD: undefined,
      serverSerial: undefined,
      procCores: undefined,
      procFamily: undefined,
      procSpeed: undefined,
      prodID: undefined,
      assetTag: undefined,
      WOL: undefined,
      pageloaded: false,
      refreshInterval: undefined,
      consoleLogin: undefined,
      showLayer : false,
      showNotification : false,
      operation: "PushPowerButton",
      selectedIP: undefined,
      EL300Selected: undefined,
      serverCount: {
        "Total": 0,
        "OK": 0,
        "Warning": 0,

        "Failed": 0
      }
    };
    this.res = undefined;
    this.serverNodes = [];
    this.data = undefined;
  }

  //After Page load perform actions
  componentDidMount() {
    this.state.pageloaded = false;
    this.props.dispatch(loadDashboard());

    //reload the page with a time interval of 20 secs
    var interval = setInterval( () => {
			this.props.dispatch(loadDashboard())}, 20000);
			this.setState({refreshInterval: interval});
	}

	//If redirecting to some other page stop Backend calls
	componentWillUnmount() {
		clearInterval(this.state.refreshInterval);
	}

  componentWillReceiveProps(nextProps){
    var data1 = nextProps.dashboardData;
    this.data = data1;
    if (data1 != undefined) {
      this.state.pageloaded = true;
    }
  }

  _onClickStatus (event) {
    var me = this;
    var dataKey = -1;
    var data = this.data;
    this.setState({ status: event, tabActiveIndex: 1, rowSelected: false, statusSelected: true });
    let serverData = []
    var status = event;
    var powerState;
    if (status == "Total"){
      this.serverNodes = this._getServers();
    } else {
        if (data[status] != undefined) {
          Object.keys(data[status]).map(function (key1) {
            var x = Object.keys(data[status][key1]).map(function (key2) {
              let systemData = data[status][key1][key2]
              if (typeof(data[status][key1][key2]) == "object") {
                if (systemData.ServerPower == 'On') {
                  powerState = 'ok'
                } else if (systemData.ServerPower == 'Off') {
                  powerState = 'warning'
                } else {
                  powerState = 'failed'
                }
                return <TableRow key1={key1} key2={key2} status={status} dataKey={dataKey++} onClick={me._getServerInfo.bind(this, {status, key1, key2, dataKey})}>
                 <td>{(systemData.Hibernate) ? '' : <PowerIcon size='small' colorIndex={powerState}/>}</td>
                  <td>{(systemData.ServerModel != undefined) ? (systemData.ServerModel) : (me.state.defaultVal)}</td>
                  <td onClick={(me.state.consoleLogin) ? null : me._openServerWindow.bind(me, systemData.ManagerIP)}><Anchor>{(systemData.ManagerIP != undefined) ? (systemData.ManagerIP) : (me.state.defaultVal)}</Anchor></td>
                </TableRow>
              }
            });
            x = x.filter(function( element ) {
              return element !== undefined;
            });
            if(x != undefined){serverData = serverData.concat(x)};
          });
        }
        this.serverNodes = serverData;
      }

    if (serverData[0] != undefined) {
      var dataKey = 0;
      var key1 = serverData[0].props.key1;
      var key2 = serverData[0].props.key2;
      var status = serverData[0].props.status;
      this._getServerInfo({status, key1, key2, dataKey});
    }
  }

  _onClickServerTab () {
    this.setState({ status: "Total", tabActiveIndex: 1, rowSelected: false, statusSelected: false });
    if (this.serverNodes[0] != undefined) {
      var dataKey = 0;
      var key1 = this.serverNodes[0].props.key1;
      var key2 = this.serverNodes[0].props.key2;
      var status = this.serverNodes[0].props.status;
      this._getServerInfo({status, key1, key2, dataKey});
    }
  }

  _onClickChassisTab() {
    this.setState({ status: "Total", tabActiveIndex: 0, rowSelected: false });
  }

  _getData() {
    var me = this;
    var data = this.data;
    var tableData = [];
    let chassisList = []
    if (data != undefined) {
      Object.keys(data).map(function (status) {
      if (data[status] != undefined) {
        var x = Object.keys(data[status]).map(function (key1) {
          if(chassisList.indexOf(data[status][key1].ChassisID) == -1){
            chassisList.push(data[status][key1].ChassisID);
            var chassisData = data[status][key1];
            return <TableRow key1={key1} onClick={me._getSelectedServers.bind(this, key1)}>
              <td>{chassisData.ChassisID != undefined ? ('CH' + chassisData.ChassisID) : (me.state.defaultVal)}</td>
              <td>{chassisData.ChassisSerial != undefined ? (chassisData.ChassisSerial) : (me.state.defaultVal)}</td>
              <td>{chassisData.ChassisModel != undefined ? (chassisData.ChassisModel) : (me.state.defaultVal)}</td>
              <td>{chassisData.ChassisFirmware != undefined ? (chassisData.ChassisFirmware) : (me.state.defaultVal)}</td>
              <td>{chassisData.ChassisAbstraction != undefined ? (chassisData.ChassisAbstraction) : (me.state.defaultVal)}</td>
              <td>{chassisData.ChassisPLD != undefined ? (chassisData.ChassisPLD) : (me.state.defaultVal)}</td>
            </TableRow>
          }
        });
        tableData = tableData.concat(x);
      }
    });
    }
    return tableData;
  }

  _getServers() {
    var me = this;
    var dataKey = -1;
    var powerState;
    this.state.selectedChassis = undefined;
    var serverData= {
      "OK": [],
      "Warning": [],
      "Unknown": [],
      "Failed": []
    }
    this.state.serverCount= {
      "Total": 0,
      "OK": 0,
      "Warning": 0,
      "Unknown":0,
      "Failed": 0
    };
    var data = this.data;
    if (data != undefined) {
        Object.keys(data).map(function (status) {
          if (data[status] != undefined) {
            Object.keys(data[status]).map(function (key1) {
              var x = Object.keys(data[status][key1]).map(function (key2) {
                let systemData = data[status][key1][key2];
                var name = 'CH' + systemData.ChassisID + 'N' + systemData.SystemID;
                if (typeof(systemData) == "object") {
                  if (systemData.ServerPower == 'On') {
                    powerState = 'ok'
                  } else if (systemData.ServerPower == 'Off') {
                    powerState = 'warning'
                  } else {
                    powerState = 'failed'
                  }

                  return <TableRow key1={key1} key2={key2} status={status} dataKey={dataKey++} onClick={(systemData.Hibernate) ? null : me._getServerInfo.bind(this, {status, key1, key2, dataKey})}>
                    <td>{(systemData.Hibernate) ? '' : <PowerIcon size='small' colorIndex={powerState}/>}</td>
                    <td>{(systemData.Hibernate) ? <div style={{color: '#999999', fontWeight: 'bold'}}>{(systemData.ServerModel)}</div> : (systemData.ServerModel)}</td>
                    <td  onClick={(me.state.consoleLogin || systemData.Hibernate) ? null : me._openServerWindow.bind(me, systemData.ManagerIP)}>
                    {(systemData.Hibernate) ? <div style={{color: '#999999',fontWeight: 'bold'}}>{(systemData.ManagerIP)}{(me.state.defaultVal)}</div> : <Anchor>{(systemData.ManagerIP != undefined) ? (systemData.ManagerIP) : (me.state.defaultVal)}</Anchor>}</td>
                  </TableRow>
                }
              });
              x = x.filter(function( element ) {
                return element !== undefined;
              });
              if(x != undefined){serverData[status] = serverData[status].concat(x)};
            });
            me.state.serverCount[status] = serverData[status].length;
          }
        });
        serverData["Total"] = serverData["OK"].concat(serverData["Warning"]).concat(serverData["Unknown"]).concat(serverData["Failed"]);


        this.state.serverCount["Total"] = serverData["Total"].length;
       // console.log('ok ', serverData["OK"]);
        //console.log('unknown ', serverData["Unknown"]);
        //console.log('Failed ', serverData["Failed"]);
    }
    return serverData["Total"];
  }

  _getSelectedServers (event) {
    var me = this;
    var data = this.data;
    var dataKey = -1;
    var key1 = event;
    var powerState = 'unknown';
    var serverNodes = {
      "OK": [],
      "Warning": [],
      //"unknown": [],

      "Failed": []
    }
    this.setState({ tabActiveIndex: 1, rowSelected: true });
    if (data != undefined) {
      Object.keys(data).map(function (status) {
      if (data[status] != undefined) {
        if (data[status][key1] != undefined) {
          if (data[status][key1].ChassisID != undefined) {
            me.setState({ selectedChassis: "Chassis CH" + data[status][key1].ChassisID });
          }
          var x = Object.keys(data[status][key1]).map(function (key2) {
          let systemData = data[status][key1][key2]
          if (typeof(systemData) == "object") {
            if (systemData.ServerPower == 'On') {
              powerState = 'ok'
            } else if (systemData.ServerPower == 'Off') {
              powerState = 'warning'
            } else {
              powerState = 'failed'
            }
            return <TableRow key2={key2} status={status} dataKey={dataKey++} onClick={me._getServerInfo.bind(this, {status, key1, key2, dataKey})}>
                <td>{(systemData.Hibernate) ? '' : <PowerIcon size='small' colorIndex={powerState}/>}</td>
                    <td>{(systemData.Hibernate) ? <div style={{color: '#999999', fontWeight: 'bold'}}>{(systemData.ServerModel)}</div> : (systemData.ServerModel)}</td>
                    <td  onClick={(me.state.consoleLogin || systemData.Hibernate) ? null : me._openServerWindow.bind(me, systemData.ManagerIP)}>
                    {(systemData.Hibernate) ? <div style={{color: '#999999',fontWeight: 'bold'}}>{(systemData.ManagerIP)}{(me.state.defaultVal)}</div> : <Anchor>{(systemData.ManagerIP != undefined) ? (systemData.ManagerIP) : (me.state.defaultVal)}</Anchor>}</td>
            </TableRow>
          }
          });
          x = x.filter(function( element ) {
            return element !== undefined;
          });
          if(x != undefined){serverNodes[status] = serverNodes[status].concat(x)};
        }
      }
    });
    this.serverNodes = serverNodes["OK"].concat(serverNodes["Warning"]).concat(serverNodes["Failed"]);
    //console.log('ok ', serverNodes["OK"]);
    //console.log('unknown ', serverNodes["Unknown"]);
       // console.log('Failed ', serverNodes["Failed"]);
    }
    if (this.serverNodes[0] != undefined){
      var key2 = this.serverNodes[0].props.key2;
      var status = this.serverNodes[0].props.status;
      var dataKey = 0;
      this._getServerInfo({status, key1, key2, dataKey});
    }
  }

  _getServerInfo (param) {
    this.setState({ serverRowSelected: param.dataKey });
    var data = this.data;
    var status = param.status;
    var key1 = param.key1;
    var key2 = param.key2;
    let systemData = data[status][key1][key2];
    if(systemData.ServerModel === "Edgeline EL300"){
      this.setState({EL300Selected: true});
    }else{
      this.setState({EL300Selected: false});
    }
    if(this.EL300Selected){
      if (data != undefined && status!= undefined && key1 != undefined && key2 != undefined) {
        this.setState({
          biosVersion: (systemData.BiosVersion != "" && systemData.BiosVersion != undefined ) ? (systemData.BiosVersion) : (this.state.defaultVal),
          macAddress: (systemData.MacAddress != "" && systemData.MacAddress != undefined) ? (systemData.MacAddress) : (this.state.defaultVal),
          managerIP: (systemData.ManagerIP != "" && systemData.ManagerIP != undefined) ? (systemData.ManagerIP) : (this.state.defaultVal),
          procCores: (systemData.ProcessorCores != "" && systemData.ProcessorCores != undefined) ? (systemData.ProcessorCores) : (this.state.defaultVal),
          procFamily: (systemData.ProcessorFamily != "" && systemData.ProcessorFamily != undefined) ? (systemData.ProcessorFamily) : (this.state.defaultVal),
          procSpeed: (systemData.ProcessorSpeed != "" && systemData.ProcessorSpeed != undefined) ? (((systemData.ProcessorSpeed)/1000) +' GHz'): (this.state.defaultVal),
          assetTag: (systemData.ServerAssetTag != "" && systemData.ServerAssetTag != undefined) ? (systemData.ServerAssetTag) : (this.state.defaultVal),
          serverSerial: (systemData.ServerSerial != "" && systemData.ServerSerial != undefined) ? (systemData.ServerSerial) : (this.state.defaultVal),
        });
      }
    }else{
      if (data != undefined && status!= undefined && key1 != undefined && key2 != undefined) {
        this.setState({
          biosVersion: (systemData.BiosVersion != "" && systemData.BiosVersion != undefined ) ? (systemData.BiosVersion) : (this.state.defaultVal),
          dnsName: (systemData.DNSName != "" && systemData.DNSName != undefined) ? (systemData.DNSName) : (this.state.defaultVal),
          dateTime: (systemData.DateTime != "" && systemData.DateTime != undefined) ? (systemData.DateTime) : (this.state.defaultVal),
          fwVersion: (systemData.FirmwareVersion != "" && systemData.FirmwareVersion != undefined) ? (systemData.FirmwareVersion) : (this.state.defaultVal),
          hostName: (systemData.HostName != "" && systemData.HostName != undefined) ? (systemData.HostName) : (this.state.defaultVal),
          macAddress: (systemData.MacAddress != "" && systemData.MacAddress != undefined) ? (systemData.MacAddress) : (this.state.defaultVal),
          managerIP: (systemData.ManagerIP != "" && systemData.ManagerIP != undefined) ? (systemData.ManagerIP) : (this.state.defaultVal),
          serverPLD: (systemData.ServerPLD != "" && systemData.ServerPLD != undefined) ? (systemData.ServerPLD) : (this.state.defaultVal),
          serverSerial: (systemData.ServerSerial != "" && systemData.ServerSerial != undefined) ? (systemData.ServerSerial) : (this.state.defaultVal),
          procCores: (systemData.ProcessorCores != "" && systemData.ProcessorCores != undefined) ? (systemData.ProcessorCores) : (this.state.defaultVal),
          procFamily: (systemData.ProcessorFamily != "" && systemData.ProcessorFamily != undefined) ? (systemData.ProcessorFamily) : (this.state.defaultVal),
          procSpeed: (systemData.ProcessorSpeed != "" && systemData.ProcessorSpeed != undefined) ? (((systemData.ProcessorSpeed)/1000) +' GHz'): (this.state.defaultVal),
          prodID: (systemData.ProductId != "" && systemData.ProductId != undefined) ? (data[status][key1][key2].ProductId) : (this.state.defaultVal),
          assetTag: (systemData.ServerAssetTag != "" && systemData.ServerAssetTag != undefined) ? (systemData.ServerAssetTag) : (this.state.defaultVal),
          WOL: (systemData.WOL != "" && systemData.WOL != undefined) ? (systemData.WOL) : (this.state.defaultVal)
        });
      }
    }
  }

  _openServerWindow(event) {
    let serverWindow = window.open("https://" + event, "blank", "toolbar=no,type=fullscreen");
    if (serverWindow !== null) {
      serverWindow.focus();
    }
  }
  _changePowerState(powerState, name,ip) {
    this.setState({ selectedSystem: name,selectedIP: ip});

    if (powerState.toUpperCase() == 'ON') {
      this.setState({ showLayer: true });
    }
    else {
      this.props.dispatch(changePowerState('On', name));
    }
  }
  //Function to get the selected operation for server poweroff
  _PowerSettings(event) {
    this.setState({ operation: event });
  }

  //Function to execute the backend api call for server poweroff
  _Settings() {
    this.props.dispatch(changePowerState(this.state.operation, this.state.selectedSystem));
    this.setState({ showLayer: false, showNotification: true, operation: "PushPowerButton" });
  }

  //Function to close the layer
  _onLayerClose() {
    this.setState({ showLayer: false });
  }
  //Function to close the notification message
  _onCloseMsg() {
    this.setState({ showNotification: false });
  }

  render () {
    var message = undefined;
    // message = this.props.sessionError;
    var powermessage;
    powermessage =this.props.poweroffmessage;
    let notification,notification1, serverDataInfo;
    let changestateLayer;
    if(this.state.showLayer==true){
      changestateLayer=
    (
        <LayerForm align='center' title="Server poweroff " submitLabel="Yes, poweroff" onClose={this._onLayerClose} overlayClose={true}
        onSubmit={this._Settings} >

              <Paragraph>Are you sure you want to poweroff the server ? </Paragraph>
              <Paragraph>select one of the option listed below to poweroff the server</Paragraph>
              <Box>
               <RadioButton id='"PushPowerButton' name='PushPowerButton' checked={"PushPowerButton" === this.state.operation} label='Graceful Power Off' value='PushPowerButton' onChange={this._PowerSettings.bind(this, "PushPowerButton")}/>
                <RadioButton id='ForceOff' name='force-power-off' checked={"ForceOff" === this.state.operation} label='Force Power Off' value='ForceOff' onChange={this._PowerSettings.bind(this, "ForceOff")}/>
                <RadioButton id='ForceRestart' name='ForceRestart' checked={"ForceRestart" === this.state.operation} label='Force System Reset' value='ForceRestart' onChange={this._PowerSettings.bind(this, "ForceRestart")}/>
                <RadioButton id='nmi' name='nmi' checked={"nmi" === this.state.operation} label='Force Power Cycle' value='"nmi' onChange={this._PowerSettings.bind(this, "nmi")}/>
              </Box>
        </LayerForm>
    );}
    if (message != undefined  && this.state.showNotification == true && this.state.pageloaded == true){
      this.state.error = true;
      notification=(
        <Notification onClose={this._onCloseMsg} pad="medium" status='critical' size='medium' closer='true' message={message}/>
      )
    }
    if (powermessage != undefined && this.state.showNotification== true ){
      notification1=(
        <Notification onClose={this._onCloseMsg} pad="medium" status='ok' size='medium' closer='true' message={powermessage}/>
      )
    }
    if(window.location.host == '127.0.0.1'){
      this.state.consoleLogin = true;
    }

    if(this.state.EL300Selected == true){
      var serverInfo = [
        {key: 'BIOS Version' , value: this.state.biosVersion},
        {key: 'MAC Address' , value: this.state.macAddress},
        {key: 'Server Serial' , value: this.state.serverSerial},
        {key: 'Manager IP' , value: this.state.managerIP},
        {key: 'Processor Cores' , value: this.state.procCores},
        {key: 'Processor Family' , value: this.state.procFamily},
        {key: 'Processor Speed' , value: this.state.procSpeed},
        {key: 'Asset Tag' , value: this.state.assetTag},
      ];
    }else{
      var serverInfo = [
        {key: 'BIOS Version' , value: this.state.biosVersion},
        {key: 'DNS Name' , value: this.state.dnsName},
        {key: 'Date Time' , value: this.state.dateTime},
        {key: 'Firmware Version' , value: this.state.fwVersion},
        {key: 'Host Name' , value: this.state.hostName},
        {key: 'MAC Address' , value: this.state.macAddress},
        {key: 'Server Serial' , value: this.state.serverSerial},
        {key: 'Server CPLD' , value: this.state.serverPLD},
        {key: 'Manager IP' , value: this.state.managerIP},
        {key: 'Processor Cores' , value: this.state.procCores},
        {key: 'Processor Family' , value: this.state.procFamily},
        {key: 'Processor Speed' , value: this.state.procSpeed},
        {key: 'Product ID' , value: this.state.prodID},
        {key: 'Asset Tag' , value: this.state.assetTag},
        {key: 'WOL' , value: this.state.WOL}
      ];
    }

    var rows = [];
    rows = this._getData();
    if (this.state.rowSelected == false && this.state.statusSelected != true ){
      this.serverNodes = this._getServers();
    }
    if(this.serverNodes != undefined) {
      serverDataInfo = serverInfo.map((server) =>
        <TableRow>
          <td><strong>{server.key}</strong></td>
          <td>{this.serverNodes[0]!=undefined ? (server.value):(undefined)}</td>
        </TableRow>
      );
    }

    return (
      <DocsArticle title='Dashboard'>
      {notification}
          {this.state.pageloaded == false && this.state.error == undefined ? (
            <Box justify='center'
            align='center'
            wrap={true}
            pad='none'
            margin='none'
            colorIndex='light-1'>
              <Spinning size='small' /><Label size='medium'>Loading please wait ...</Label>
            </Box>
          ) : ("")}
          <Box pad='none'
            direction='row'>
            <Box pad='medium' width='25%'>
              <AnnotatedMeter
                legend = {true}
                size='small'
                type='circle'
                max={1}
                defaultMessage="Servers"
                series={[{"label": "Servers", "value": this.state.serverCount["Total"], "colorIndex": "accent-1", onClick: this._onClickStatus.bind(this, 'Total')}]} />
            </Box>
            <Box pad='medium' width='25%'>
              <AnnotatedMeter
                legend = {true}
                size='small'
                type='circle'
                max={1}
                defaultMessage='Servers'
                series={[{"label": "Good health", "value": this.state.serverCount["OK"], "colorIndex": "ok", onClick: this._onClickStatus.bind(this, 'OK')}]} />
            </Box>
            <Box pad='medium' width='25%'>
              <AnnotatedMeter
                legend = {true}
                size='small'
                type='circle'
                max={1}
                defaultMessage='Servers'
                label="Chassis"
                series={[{"label": "Warning", "value": this.state.serverCount["Warning"], "colorIndex": "warning", onClick: this._onClickStatus.bind(this, 'Warning')}]} />
            </Box>
            <Box pad='medium' width='25%'>
              <AnnotatedMeter
                legend = {true}
                size='small'
                type='circle'
                max={1}
                defaultMessage='Servers'
                series={[{"label": "Critical", "value": this.state.serverCount["Failed"] , "colorIndex": "critical", onClick: this._onClickStatus.bind(this, 'Failed') }]} />

            </Box>


          </Box>

          <Tabs activeIndex={this.state.tabActiveIndex} >
            <Tab title='Chassis' onClick={this._onClickChassisTab} >

            <Box pad='none'>
              <Table selectable={true}  >
              <thead>
                <tr>
                  <th><strong>Chassis ID</strong></th>
                  <th><strong>Chassis Serial</strong></th>
                  <th><strong>Chassis Model</strong></th>
                  <th><strong>Chassis Firmware</strong></th>
                  <th><strong>Abstraction Firmware</strong></th>
                  <th><strong>CPLD</strong></th>
                </tr>
              </thead>
              <tbody>
                {rows}
              </tbody>
            </Table></Box>

            </Tab>
            <Tab title='Servers' onClick={this._onClickServerTab} >
            {notification1}
              <Paragraph><strong>{this.state.selectedChassis}</strong></Paragraph>
              <Box direction='row'>
                <Box separator="all" basis='1/2'>
                  <Table selectable={true} selected={this.state.serverRowSelected}>
                  <thead>
                    <tr>
                      <th><strong>Power</strong></th>
                      <th><strong>Model</strong></th>
                      <th><strong>IP address</strong></th>
                    </tr>
                    </thead>
                    <tbody>
                      {this.serverNodes}
                    </tbody>
                </Table>
                {changestateLayer}
                </Box>
                <Box basis='1/2'>
                  <Box colorIndex='light-2' pad='none' separator='all'>
                    <Table>
                      {serverDataInfo}
                    </Table>
                  </Box>
                </Box>
              </Box>
            </Tab>
          </Tabs>
 <strong>*Some of the columns may be listed as unknown until EIM has completed discovering the target systems</strong>
      </DocsArticle>
    );
  }
};

const select = state => ({ ...state.dashboardInfo });

export default connect(select)(DashBoard);
