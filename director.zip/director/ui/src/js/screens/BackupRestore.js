// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import DocsArticle from './DocsArticle';
import Tab from 'grommet/components/Tab';
import Tabs from 'grommet/components/Tabs';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Paragraph from 'grommet/components/Paragraph';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import {RestoreFile} from '../actions/restore';
import {Download, DownloadSupportDump} from '../actions/backuprestore';
import Label from 'grommet/components/Label';
import Layer from 'grommet/components/Layer';
import Notification from 'grommet/components/Notification';
import {ResetEIMConfig} from '../actions/resetEIM';

FormField.displayName = 'FormField';
Form.displayName = 'Form';
Label.displayName = 'BackupRestore';

class BackupRestore extends Component {

  constructor (props) {
    super(props);
    this._onChange = this._onChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._onclose = this._onclose.bind(this);
    this._UploadFile = this._UploadFile.bind(this);
    this._UploadConfigFile = this._UploadConfigFile.bind(this);
    this._onConfirmationClose = this._onConfirmationClose.bind(this);
    this._onDownloadSupportDump = this._onDownloadSupportDump.bind(this);
    this.state = {
      LayerOpen: false,
      showNotification: false,
      errorMessage: null,
      errorms: undefined,
      config_required: undefined,
      config_file: null,
      consoleLogin: false
    };

  }

  componentDidMount(){

  }

  componentWillReceiveProps(nextProps){
    this.setState({errorms: nextProps.error});
  }


  _onConfirmationClose() {
    this.setState({ LayerOpen: false });
  }

  _UploadFile() {
    let file = this.state.config_file;
    this.props.dispatch(RestoreFile(file));
    this.setState({showNotification: true});
    this.setState({ LayerOpen: false });
  }

  _UploadConfigFile () {
    this.setState({ config_required: "" });
    this.setState({ LayerOpen: true });
    let configfile = this.refs.file.files[0];
    this.setState({ config_file: this.refs.file.files[0] });
    if (configfile == undefined) {
      let errMsg = "configuration file is required";
      this.setState({ config_required: errMsg });
      this.setState({ LayerOpen: false });
    }
  }

  _onclose()
  {
    this.setState({notificatonMessage: false})
  }

  _onSubmit(file) {
    this.props.dispatch(Download(file));
  }

  _onDownloadSupportDump(file){
    this.props.dispatch(DownloadSupportDump(file));
  }
  _onChange(event) {
    this.setState( {myFileName: event.target.files[0].name} );
    this.setState( {myFileHandle: event.target.files[0]} );
    this.setState({json_config_file:event.target.files[0]})
  }

  render () {
    const { error } = this.props;
    const { configUpdate } = this.props;
    let consoleMessage = undefined;
    let notification;
    if (this.state.showNotification === true) {
      if ( this.props.configUpdate != undefined && this.props.configUpdate.statusCode.restart_required === 'True') {// successs and reboot required
        //reboot the eim
        var resetData = { "restart_required": "True" };
		window.localStorage.timeoutRebootMsg = "Reboot is in progress. Please wait...";
        this.props.dispatch(ResetEIMConfig(resetData));
		setTimeout(function() {
          window.location.href = '/Login';
         }, 5000);
      }
      else { //error
        notification =
          <Notification onClose={this._onClose} pad='medium' size='medium'
                        closer='true' status='critical' message='Failed to update configuration file' />
      }
    }
    //Layer Component for Configuration  and reset confirmation
    let layer;
    if (this.state.LayerOpen) {
      layer =
        (
          <Layer align="right" closer={true} onClose={this._onConfirmationClose} compact={true} >
            <Form submitLabel="Restore configuration file">
              <Header><Heading tag='h2'>Restore configuration file and Reboot</Heading></Header>
              <fieldset>
                <Paragraph>Applying Configuration file requires an EIM Reboot. Would you like to apply and Reboot EIM now? </Paragraph><br />
              </fieldset>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='Apply & Reboot' primary={true} onClick={this._UploadFile} />
              </Box>
            </Form>
          </Layer>
        );
    }
    if(window.location.host == '127.0.0.1'){
      this.state.consoleLogin = true;
      consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
    }
    return (
      <DocsArticle title='Appliance Configuration'>
        <section>
          <div>{notification}</div>
          <Tabs justify='start'>
            <Tab title='Backup'>
              <Box pad={{vertical:'none'}}>
                {consoleMessage}
              </Box>
              <Paragraph>
                <strong>
                  Save EIM configuration settings to a json formatted file.
                </strong>
              </Paragraph>
              <Form>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Download' primary={true} onClick={(this.state.consoleLogin) ? null : this._onSubmit}/>
                </Box>
              </Form>
              <Paragraph>
                <strong>Download Support Dump in a zip file format.</strong>
              </Paragraph>
              <Form>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Download' primary={true} onClick={(this.state.consoleLogin) ? null : this._onDownloadSupportDump}/>
                </Box>
              </Form>
            </Tab>
            <Tab title='Restore'>
              <Box pad={{vertical:'none'}}>
                {consoleMessage}
              </Box>
              <Paragraph><strong>Upload EIM configuration file (.json)</strong></Paragraph>
              <Form>
                <FormField label='Configuration file' htmlFor='input-id' error={this.state.config_required}>
                  <input disabled={this.state.consoleLogin} type="file" id="file" ref="file" accept=".json"  name="json_config_file" key='json_config_file' onChange={this._onChange} />
                </FormField>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Restore' primary={true} onClick={(this.state.consoleLogin) ? null : this._UploadConfigFile} />
                </Box>
              </Form>
            </Tab>
          </Tabs>
          {layer}
        </section>
      </DocsArticle>
    );
  }
};
const select = state => ({
  ...state.restore
});
export default connect(select)(BackupRestore);
