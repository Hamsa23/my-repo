// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Label from 'grommet/components/Label';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import FormFields from 'grommet/components/FormFields';
import Button from 'grommet/components/Button';
import CheckBox from 'grommet/components/CheckBox';
import { GetLdap, SubmitLdap, TestLdap } from '../actions/ldap';
import Notification from 'grommet/components/Notification';
import { ResetEIMConfig } from '../actions/resetEIM';
import Layer from 'grommet/components/Layer';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import Paragraph from 'grommet/components/Paragraph';

Label.displayName = 'DirectoryGroups';

class DirectoryGroups extends Component {

  constructor () {
    super();
    this.state = {
      IsChecked: undefined,
      Enable: undefined,
      BindPassword: undefined,
      ServerUri: undefined,
      BindDn: undefined,
      UserSearch: undefined,
      DenyGroup: undefined,
      RequireGroup: undefined,
      errors: {},
      showNotification: false,
      errorMessage: null,
      errormsg: undefined,
      LayerOpen: false,
      inPayload: {},
      IsLdap: undefined,
      ldaperror: undefined,
    };
    this._onChange = this._onChange.bind(this);
    this._validateInput = this._validateInput.bind(this);
    this._onLdapSubmit = this._onLdapSubmit.bind(this);
    this._onTestLdap = this._onTestLdap.bind(this);
    this._onChangeCheckBox = this._onChangeCheckBox.bind(this);
    this._onConfirmationClose = this._onConfirmationClose.bind(this);
    this._onApply = this._onApply.bind(this);
  }

  //After Page load perform actions
  componentDidMount() {
    this.props.dispatch(GetLdap());
    this.setState({IsLdap: window.localStorage.getItem('ldap')})
  }

  componentWillUnmount(){
    this.setState({ldaperror: ""});
  }
  
  componentWillReceiveProps(nextProps){
    let Enable = (nextProps.Enable == 'true' ? true : false);
    this.setState({
    BindPassword:nextProps.BindPassword,
    ServerUri:nextProps.ServerUri,
    BindDn:nextProps.BindDn,
    UserSearch: nextProps.UserSearch,
    DenyGroup: nextProps.DenyGroup,
    RequireGroup: nextProps.RequireGroup
    })

    if(this.state.IsChecked == undefined) {
      this.setState({ IsChecked: Enable })
    }
  }
 
  //On text Box value change assign value
  _onChange(event) {
    this.setState({
      [event.target.name] : event.target.value
    });
    this._validateInput(event);  //Validate user input in add form
    this.setState({showNotification: false});
  }

  _onChangeCheckBox(event){
      this.setState({IsChecked: event.target.checked});
    }

  _onLdapSubmit () {
    var reqErr = "required";
    let err = Object.assign({}, this.state.errors); 
    this.state.isValid = undefined;
    
    // Set error message on empty text boxes before submit
		if(this.state.BindPassword == '' || this.state.BindPassword == undefined){
			  err["BindPassword"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    if(this.state.ServerUri == '' || this.state.ServerUri == undefined){
			  err["ServerUri"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    if(this.state.BindDn == '' || this.state.BindDn == undefined){
			  err["BindDn"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    if(this.state.UserSearch == '' || this.state.UserSearch == undefined){
			  err["UserSearch"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    if(this.state.DenyGroup == '' || this.state.DenyGroup == undefined){
			  err["DenyGroup"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    if(this.state.RequireGroup == '' || this.state.RequireGroup == undefined){
			  err["RequireGroup"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
    }
    //POST information if no error
    if(this.state.IsLdap == "False"){
      if(this.state.isValid == undefined){
        let Enable = (this.state.IsChecked == true ? "true" : "false");
        var input = {};
        input = {
          "Enable": Enable,
          "BindPassword": this.state.BindPassword,
          "ServerUri": this.state.ServerUri,
          "BindDn": this.state.BindDn,
          "UserSearch": this.state.UserSearch,
          "DenyGroup": this.state.DenyGroup,
          "RequireGroup": this.state.RequireGroup 
        };      
        this.setState({ inPayload: input });
        this.setState({ LayerOpen: true });
        }
      }else{
        this.setState({ldaperror: "LDAP user not authorized to edit"});
      }
    }
    
    
  _onApply() {
    if(this.state.IsLdap == "False"){
      this.props.dispatch(SubmitLdap(this.state.inPayload));
      this.setState({ showNotification: true });
      this.setState({ LayerOpen: false });
    }else{
      this.setState({showNotification: true});
    }
  }
  _onConfirmationClose() {
    this.setState({ LayerOpen: false })
  }
  
  _onTestLdap () {
    this.props.dispatch(TestLdap());
    this.setState({showNotification: true});
	}

  //Validate Add user Form inputs
	_validateInput(event) {
    let err = {};
    var errMsg;
		var value = event.target.value;
    switch(event.target.name) {
      case "BindPassword": 
        if (value != "null" || value != "undefined"){
          this.state.isValid = value.match(/^[a-zA-Z0-9_.@ ]{2,30}$/);
        }
        errMsg = (this.state.isValid) ? "" : "Enter a valid Bind Password";
        err = Object.assign({}, this.state.errors); 
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;

      case "ServerUri": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9_.@/: ]{2,50}$/);
				}
				errMsg = (this.state.isValid) ? "" : "Enter a valid Server Uri";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
        break;

      case "BindDn": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*(?:,(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*)*$/);
				}
				errMsg = (this.state.isValid) ? "" : "Enter a valid Bind Dn";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
        break;
        
      case "UserSearch": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*(?:,(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*)*$/);
				}
				errMsg = (this.state.isValid) ? "" : "Enter a valid UserSearch";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
        break;
      
      case "DenyGroup": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*(?:,(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*)*$/);
				}
				errMsg = (this.state.isValid) ? "" : "Enter a valid DenyGroup";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
        break;

      case "RequireGroup": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*(?:,(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*")(?:\+(?:[A-Za-z][\w-]*|\d+(?:\.\d+)*)=(?:#(?:[\dA-Fa-f]{2})+|(?:[^,=\+<>#;\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*|"(?:[^\\"]|\\[,=\+<>#;\\"]|\\[\dA-Fa-f]{2})*"))*)*$/);
				}
				errMsg = (this.state.isValid) ? "" : "Enter a valid RequireGroup";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
        break;
						
      default:
        break;
    }
	};

  render () {
    const { err } = this.props;

    if(this.props.Enable != undefined && this.state.Enable === undefined) {
        this.state.Enable = this.props.Enable;
        this.state.BindPassword = this.props.BindPassword;
        this.state.ServerUri = this.props.ServerUri;
        this.state.BindDn = this.props.BindDn;
        this.state.UserSearch = this.props.UserSearch;
        this.state.DenyGroup = this.props.DenyGroup;
        this.state.RequireGroup = this.props.RequireGroup;
    }
 
    let notification;
    if(this.state.IsLdap == "True"){
      notification = <Notification onClose={this._onClose} size='medium' message={"LDAP users are not authorized to change directory server settings."}/>
    }
    if (this.state.showNotification == true){
      if(err == "LDAP settings are saved. Please reboot the system to reflect the applied changes."){
        notification = <Notification onClose={this._onClose} size='medium' status='ok' message={'LDAP settings are saved. The system will reboot in few seconds'}/>
        var resetData = {"restart_required":"True"};
		window.localStorage.timeoutRebootMsg = "Reboot is in progress. Please wait...";
        this.props.dispatch(ResetEIMConfig(resetData));
        setTimeout(function() {
          window.location.href = '/Login';
        }, 5000);
       }
      else if (err == "ldap connected."){
        notification = <Notification onClose={this._onClose} size='medium' status='ok' message={err}/>
      }
      else{
        notification = <Notification onClose={this._onClose} size='medium' status='critical' message={err}/>
      }
     }

    let layer;
    if (this.state.LayerOpen) {
      layer =
        (

          <Layer align="right" closer={true}  overlayClose={true}
                 onClose={this._onConfirmationClose} compact={true} >
            <Form >
              <Header><Heading tag='h2'>Apply LDAP settings.</Heading></Header>
              <Paragraph>Applying LDAP settings will reboot the system, Do you want to continue?
              </Paragraph>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='OK & Reboot' primary={true} onClick={this._onApply} />
              </Box>
            </Form>
          </Layer>
        );
    }

    return (
      <Form>
      <div>{notification}</div>
      &thinsp;
      <FormFields>
      &thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;  
      <CheckBox label='Enable LDAP' toggle={true} reverse={true} name="Enable" checked={(this.state.IsChecked != undefined)?(this.state.IsChecked):(this.props.Enable == 'true' ? true : false)}
                onChange={this._onChangeCheckBox} />
        <fieldset>
          <FormField label='Bind password'  error={this.state.errors["BindPassword"]}>
            <input id='BindPassword' type='Password' name="BindPassword" onChange={this._onChange} value={this.state.BindPassword}/>
          </FormField>
        </fieldset>
      </FormFields>

      <FormFields>
        <fieldset>
          <FormField label='Server URI' error={this.state.errors["ServerUri"]}>
            <input id='ServerUri' type='text' name="ServerUri" onChange={this._onChange} value={this.state.ServerUri}/>
          </FormField>
        </fieldset>
      </FormFields>

      <FormFields>
        <fieldset>
          <FormField label='Bind DN' error={this.state.errors["BindDn"]}>
            <input id='BindDn' type='text' name="BindDn" onChange={this._onChange} value={this.state.BindDn}/>
          </FormField>
        </fieldset>
      </FormFields>
      
      <FormFields>
        <fieldset>
          <FormField label='Search user' error={this.state.errors["UserSearch"]}>
            <input id='UserSearch' type='text' name="UserSearch" onChange={this._onChange} value={this.state.UserSearch}/>
          </FormField>
        </fieldset>
      </FormFields>

      <FormFields>
        <fieldset>
          <FormField label='Deny group' error={this.state.errors["DenyGroup"]}>
            <input id='DenyGroup' type='text' name="DenyGroup" onChange={this._onChange} value={this.state.DenyGroup}/>
          </FormField>
        </fieldset>
      </FormFields>

      <FormFields>
        <fieldset>
          <FormField label='Require group' error={this.state.errors["RequireGroup"]}>
            <input id='RequireGroup' type='text' name="RequireGroup" onChange={this._onChange} value={this.state.RequireGroup}/>
          </FormField>
        </fieldset>
      </FormFields>
      
      <Label><font color="#FF0000">{this.state.ldaperror}</font></Label>
        <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
          <Button label='Test LDAP Configuration' onClick={this._onTestLdap} />
          <Box pad={{horizontal: 'small',vertical:'none'}}>
              <Button label='Test & Apply' primary={true} onClick={this._onLdapSubmit} />
          </Box>
        </Box>
        {layer}
        </Form>    
    );
  }
};

const select = state => ({
 ...state.ldap
});

export default connect(select)(DirectoryGroups);
