// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Label from 'grommet/components/Label';
import Form from 'grommet/components/Form';
import Button from 'grommet/components/Button';
import Paragraph from 'grommet/components/Paragraph';
import Select from 'grommet/components/Select';
import Search from 'grommet/components/Search';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import CheckBox from 'grommet/components/CheckBox';
import { GetFWBundleList, SubmitFWRequest } from '../actions/fwupdate';
import { loadDashboard } from '../actions/dashboard';
import {LoadLicense, LoadSysUuid, UnloadLicense} from '../actions/license';
import Layer from 'grommet/components/Layer';
import LayerForm from 'grommet-templates/components/LayerForm';
import FormFields from 'grommet/components/FormFields';
import FormField from 'grommet/components/FormField';
import Notification from 'grommet/components/Notification';
import RadioButton from 'grommet/components/RadioButton';
import { DryRun } from './urls';
import { sendRedfishActionRequest } from '../actions/redfishActionUtil';

Label.displayName = 'Firmware Update';

class FWUpdate extends Component {

  constructor () {
    super();
    this._onChange = this._onChange.bind(this);
    this._getData = this._getData.bind(this);
    this._onSelect = this._onSelect.bind(this);
    this._UploadFile = this._UploadFile.bind(this);
    this._onUpdateLayerClose = this._onUpdateLayerClose.bind(this);
    this._flashFW = this._flashFW.bind(this);
    this._doSearch = this._doSearch.bind(this);
    this._RadioButton = this._RadioButton.bind(this);
    this._onSelectAll = this._onSelectAll.bind(this);
    this._onClose = this._onClose.bind(this);
    this._onDryRun = this._onDryRun.bind(this);
    this._onCloseWarning = this._onCloseWarning.bind(this);
    this.data = undefined,
    this.state = {
      searchkey: '',
      val: undefined,
      updateiplist: [],
      UpdateLayerActive: false,
      showNotification: false,
      hasValidLic:false,
      invalidLic: '',
      showLicNotification: false,
      doPost: "Yes",
      layerNotificationMsg: undefined,
      hasSystems: false,
      selectAll: false,
      selectedSystems: [],
      showDryRunNotification: false,
      dryRunMessage: '',
      openWarning : true
    };
  }

  //After Page load perform actions
  componentDidMount() {
    this.props.dispatch(LoadLicense());
    this.props.dispatch(LoadSysUuid());
    this.props.dispatch(GetFWBundleList());
    this.props.dispatch(loadDashboard());    
    this.setState({showNotification: false});
    this.setState({showDryRunNotification: false});
    
  }

  componentWillReceiveProps(nextProps){
    var data1 = nextProps.dashboardData;
    this.data = data1;
    
    if ( nextProps.agg_deviceID != undefined ) {    
      var dateOfExp =  nextProps.agg_expirationDate;
      var currDate = new Date().toISOString();
      if(dateOfExp >= currDate || dateOfExp == "No expiration" || nextProps.agg_expired == "False" ){
        this.setState({ licenseNotification: '' , showLicNotification: false, hasValidLic: true });
      }else{
        this.setState({ licenseNotification: 'Licensing is expired, Valid licensing required to flash firmware.' , showLicNotification: true, hasValidLic: false  });
      }
    }else{
      this.setState({ licenseNotification: 'Firmware flash requires valid License, Update license.' , showLicNotification: true,  hasValidLic: false  });
    }

    var dryRunSuccess = nextProps.successResponse;  
    if(dryRunSuccess != undefined ) {
      if (dryRunSuccess.hasOwnProperty("task_id")){
        this.setState({showDryRunNotification: true, dryRunMessage: 'Dry run is initiated successfuly' });
      } else {
        //need to handle this error
        //this.setState({showDryRunNotification: true, dryRunMessage: 'Dry run is failed to initiate' });      
      }
    } else{
      this.setState({showDryRunNotification: false, dryRunMessage: '' });
    }
  }

    //on click of upload open confirmation dialogue
  _onDryRun (){
    var selectedIPs = [];
    var systems = Object.assign({}, this.state.selectedSystems);
    Object.keys(systems).map(function (key) {
      if (systems[key][0] == true) {
        selectedIPs.push(key);
      }
    });
    if(selectedIPs.length > 0) {
    //Construct Payload
    var inPayload = {
      "Targets": selectedIPs,
      "Config": this.state.val
    }
  }
  var payload = JSON.stringify(inPayload);
    this.props.dispatch(sendRedfishActionRequest( 'POST', DryRun, payload));
  }
  _onClose(){
    this.setState({showDryRunNotification: false, dryRunMessage: '', showLicNotification:false, showNotification:false });
  }
   _onCloseWarning ()
  {
    this.setState({openWarning:false});
  }

  _onSelect(e) {
    this.setState({showNotification: false});
    const item = e.target.id;
    const isChecked = e.target.checked;
    var systems = Object.assign({}, this.state.selectedSystems);
    systems[item][0] = isChecked;
    this.setState({
      selectedSystems: systems,
      selectAll: false
    });
  }

  //on select/deselect all systems
  _onSelectAll(e) {
    this.setState({showNotification: false});
    var systems = Object.assign({}, this.state.selectedSystems);
    if (e.target.checked) {
        Object.keys(systems).map(function (key) {
            systems[key][0] = true;
        });
    } else {
        Object.keys(systems).map(function (key) {
            systems[key][0] = false;
        });
    }
    this.setState({
        selectedSystems: systems,
        selectAll: e.target.checked
    });
  }


  //UpdateLayerActive close
  _onUpdateLayerClose () {
    this.setState({ UpdateLayerActive: false });
    this.setState({showNotification: false});
  }

  _UploadFile(){
    var hasSelectedSystems = false;
    var systems = Object.assign({}, this.state.selectedSystems);
    Object.keys(systems).map(function (key) {
        if (systems[key][0] == true) {
            hasSelectedSystems = true;
        }
    })
    if (hasSelectedSystems == true && this.state.showLicNotification == false) {
        this.setState({
          UpdateLayerActive: true,
          systemErr: "",
          showNotification: false
        });
    } else {
        this.setState({ systemErr: "Select one or more systems to delete" });
    }
  }

  // On drop down menu list
  _onChange(event) {
    this.setState({ val: event.value });
    this.setState({showNotification: false});
  }

  _flashFW(){
    var me = this;
     var selectedIPs = [];
     var delSystems = this.state.selectedSystems;
     this.setState({
       UpdateLayerActive: false,
       showNotification: true,
       selectedSystems: [],
       selectAll: false
     });
     Object.keys(delSystems).map(function (key) {
       if (delSystems[key][0] == true) {
         selectedIPs.push(key);
       }
     });

     if (selectedIPs.length != 0 && this.state.val != undefined){
      if(this.state.doPost == "Yes"){
        var val = "True"
      }else{
        var val = "False"
      }
      var body = {
          "Targets": selectedIPs,
          "Config": this.state.val
         //, "DoPOST": val
        }
        this.props.dispatch(SubmitFWRequest(body));
        this.setState({showNotification: true});
        this.setState({ UpdateLayerActive: false });
     }
  }

  //Perform DoPost selection
  _RadioButton(event){
    this.setState({doPost: event});
  }

_getData(){
  var me = this;
  var serverData = [];
  var data = this.data;
  var searchText = this.state.searchkey;
  if (data != undefined) {
    Object.keys(data).map(function (status) {
      if (data[status] != undefined) {
        Object.keys(data[status]).map(function (key1) {
          var x = Object.keys(data[status][key1]).map(function (key2) {
            var ip = data[status][key1][key2].ManagerIP;
            if(searchText == '' || ip != undefined && ip.indexOf(searchText) >=0) {
              if (typeof(data[status][key1][key2]) == "object") {
                var tasks = Object.assign({}, me.state.selectedSystems);
                var ip = data[status][key1][key2].ManagerIP;
                var chassis_id = data[status][key1][key2].ChassisID;
                var server_id = data[status][key1][key2].SystemID;
                if (tasks[ip] == undefined) {
                  tasks[ip] = [false];
                }
                me.state.selectedSystems = tasks;
                return <TableRow>
                  <td><CheckBox id={data[status][key1][key2].ManagerIP} checked={me.state.selectedSystems[data[status][key1][key2].ManagerIP][0]} onChange={me._onSelect}/></td>
                  <td>{data[status][key1][key2].ManagerIP}</td>
                  <td>{data[status][key1][key2].ServerModel}</td>
                </TableRow>
              }
            }
          });
          x = x.filter(function( element ) {
            return element !== undefined;
          });
          if(x != undefined){serverData = serverData.concat(x)};
        });
      }
    });
  }
  if (serverData[0] == undefined) {
    serverData = "No systems found";
    this.state.hasSystems = false;
  } else {
    this.state.hasSystems = true;
  }
  return serverData;
}

  //Function for search
  _doSearch(event){
    this.setState({searchkey:event.target.value});
  }


  render () {
    const { BundleInfo } = this.props;
    const { FWFlashInfo } = this.props;
    let notification;
    if (this.state.showNotification == true){
      if((FWFlashInfo != 'Unable to initiate Firmware Update.') && (FWFlashInfo != 'Internal Server Error')){
        notification = <Notification onClose={this._onClose} closer='true' size='medium' status='ok' message={'Firmware Flash Successfully initiated.'}/>
      }
      else{
        notification = <Notification onClose={this._onClose} closer='true' size='medium' status='critical' message={FWFlashInfo}/>
      }
    }
    if (this.state.showDryRunNotification == true){
      if(this.state.dryRunMessage == 'Dry run is initiated successfuly'){
        notification = <Notification onClose={this._onClose} size='medium' closer='true' status='ok' message={this.state.dryRunMessage}/>
      }
      else{
        notification = <Notification onClose={this._onClose} size='medium' closer='true'  status='critical' message={this.state.dryRunMessage}/>
      }	      
    }
    if (this.state.showLicNotification == true){
      notification = <Notification onClose={this._onClose} closer='true' size='medium' status='disabled' message={this.state.licenseNotification}/>
    }
    var tableinfo = [];
    tableinfo = this._getData();
    var targetCount = tableinfo.length;
    var layerNotification = undefined;
    var validLicenseCount = this.props.agg_availableCapacity;
    var checkLicensecount = (validLicenseCount < targetCount) ? true :false;
    if (validLicenseCount < targetCount) {
      this.state.layerNotificationMsg = 'You have discovered more servers than you have licenses for the firmware update feature.  Licenses: ' + validLicenseCount + ', Discovered Servers: ' + targetCount;
      layerNotification = <Notification size='medium' status='warning' message={this.state.layerNotificationMsg}/>
    }
    if(checkLicensecount && this.state.openWarning){
      this.state.layerNotificationMsg = 'You have discovered more servers than you have licenses for the firmware update feature.  Licenses: ' + validLicenseCount + ', Discovered Servers: ' + targetCount;	      this.state.layerNotificationMsg = 'You have discovered more servers than you have licenses for the firmware update feature.  Licenses: ' + validLicenseCount + ', Discovered Servers: ' + targetCount;
      layerNotification = <Notification size='medium' status='warning' message={this.state.layerNotificationMsg}/>	      
      layerNotification = <Notification onClose={this._onCloseWarning} size='medium'  closer='true' status='warning' message={this.state.layerNotificationMsg}/>
    }	    
  

    //LAYER
    let UpdateFW;
    if(this.state.UpdateLayerActive){
      UpdateFW=
        (
          <LayerForm align='center' title="Update Firmware" submitLabel="Yes, Update" overlayClose={true}
            onClose={this._onUpdateLayerClose} onSubmit={this._flashFW}>
            <fieldset>
              <Box>
                <Paragraph>The selected target systems may be powered on to identify their current firmware revisions.<br/>
                Are you sure you want to update Server(s)?</Paragraph>
              </Box>
            </fieldset>
          </LayerForm>
        );
      }

    return (
      <Form>
        <div>{notification}</div>
        <div>{layerNotification}</div>
        <br/>
        <FormField label='Select Firmware Bundle'>
          <Select placeHolder='-- Choose The Configuration File --' options={BundleInfo} value={this.state.val} onChange={this._onChange} />
        </FormField>
        <br/>
        <Search placeHolder='Search' inline={true} value={this.searchkey} onDOMChange={this._doSearch}/>
        <Table scrollable={false}>
          <thead>
          <tr>
            <th><CheckBox disabled={!this.state.hasSystems} checked={this.state.selectAll} onChange={this._onSelectAll}/></th>
            <th><strong>Target IP</strong></th>
            <th><strong>Server Model</strong></th>
          </tr>
          </thead>
          <tbody>
          {tableinfo}
          </tbody>
        </Table>
        <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
          <Button label='Update' primary={true} onClick={this._UploadFile} /> 
            <Box pad={{horizontal: 'small',vertical:'none'}} direction='row'>
            <Button label='Dry run' primary={true} onClick={this._onDryRun} /> 
            </Box>
          </Box>      
           <Box>
          <Paragraph><font color="red"> {this.state.invalidLic} </font></Paragraph>
          </Box>
        <Box>  
          {UpdateFW}
        </Box>
      </Form>
    );
  }
};

const select = state => ({ ...state.firmwareupdate, ...state.dashboardInfo, ...state.licenseInfo, ...state.redfishReducers });

export default connect(select)(FWUpdate);
