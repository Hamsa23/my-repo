// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Footer from 'grommet/components/Footer';

export default class DocsFooter extends Component {
  render () {
    const { colorIndex, centered } = this.props;
    return (
      <Footer align='start' colorIndex={colorIndex} appCentered={centered}
        size="large" pad="large">
        {this.props.children}

      </Footer>
    );
  }
};

DocsFooter.propTypes = {
  centered: PropTypes.bool,
  colorIndex: PropTypes.string
};

DocsFooter.defaultProps = {
  centered: false
};
