// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import DocsArticle from './DocsArticle';
import Tab from 'grommet/components/Tab';
import Tabs from 'grommet/components/Tabs';
import FormField from 'grommet/components/FormField';
import Table from 'grommet/components/Table';
import Form from 'grommet/components/Form';
import Label from 'grommet/components/Label';
import Notification from 'grommet/components/Notification';
import FirmwareConfigurationUpload from './FWConfigUpload';
import FirmwareUpdate from './FWUpdate';
import FirmwareStatus from './FWStatus';
import {GetFWBundleList, GetFWProfile, FWUploadEvent, Delfirmwarebundle} from '../actions/fwupload';
import Layer from 'grommet/components/Layer';
import Header from "grommet/components/Header";
import Heading from "grommet/components/Heading";
import Paragraph from "grommet/components/Paragraph";
import CheckBox from "grommet/components/CheckBox";

FormField.displayName = 'FormField';
Form.displayName = 'Form';
Label.displayName = 'Firmware Upload';

class FWUpload extends Component {

 constructor () {
   super();
   this._onChange = this._onChange.bind(this);
   this._UploadFirmwareFile = this._UploadFirmwareFile.bind(this);
   this._DeleteFirmwareFile = this._DeleteFirmwareFile.bind(this);
   this._closeNotification = this._closeNotification.bind(this);
   this._onConfirmationClose = this._onConfirmationClose.bind(this);
   this._Apply = this._Apply.bind(this);
   this._ProfileList = this._ProfileList.bind(this);
   this._onselectbundle = this._onselectbundle.bind(this);


   this.state = {
     LayerOpen: false,
     showNotification: false,
     errorMessage: null,
     errorms: undefined,
     config_required: undefined,
     config_file: null,
     firmware_file: null,
     list: undefined,
     bundlelist: [],
     firmwarelist:[],
     del: null,
     SelectionName: null,
     updateprofilelist: [],
     updatefirmwarelist: [],
     showDeleteNotification: false,
     consoleLogin: false
   };
 }

    //After Page load perform actions
	componentDidMount() {
    var me = this;
    this.props.dispatch(GetFWBundleList());
    this.props.dispatch(GetFWProfile());
    this._ProfileList();
    // var interval = setInterval( () => {
    // this.props.dispatch(GetFWBundleList());
    // this.props.dispatch(GetFWProfile())}, 1000);
		// this.setState({refreshInterval: interval});
  }

  componentWillUnmount() {
		// clearInterval(this.state.refreshInterval);
	}

  _ProfileList(){
    this.props.dispatch(GetFWProfile());
  }

	componentWillReceiveProps(nextprops){
  var list = undefined;
	list = nextprops.ProfileList;
  let array=[];
  if(list != undefined && list != 'Malformed Syntax' && list != 'Internal Server Error' && list != 'Unable to get Profile list'){
      if(list.bundles != undefined) {
        Object.keys(list.bundles).map(function (key) {
          array.push(key);
        });
      }
      if(list.firmware != undefined) {
        Object.keys(list.firmware).map(function (key) {
          array.push(list.firmware[key]);
        });
      }
    }
    this.setState({ bundlelist: array});
 }
 
  _UploadFirmwareFile () {
    let firmware_file = this.refs.firmware_file.files[0];
    this.setState({notification: null});
    if (firmware_file == undefined) {
      let errMsg = "firmware/bundle file is required";
      this.setState({
        file_message: errMsg,
        showNotification: false,
        firmware_file: null
      });
    } else {
      let firmware_file = this.refs.firmware_file.files[0];
      this.props.dispatch(FWUploadEvent(firmware_file));
      this.setState({
        showNotification: true,
        firmware_file: null,
        LayerOpen: false
      });
    }
  }

  _DeleteFirmwareFile (){
    if (this.state.updateprofilelist.length !=0 || this.state.updatefirmwarelist.length !=0) {
      this.setState({
        del: null,
        notification: null,
        file_message: "",
        showNotification: false,
        LayerOpen: true,
        showDeleteNotification: false
      });
    }
  }

  _onChange( ) {
    this.setState({
      del: null,
      notification: null,
      file_message: null,
      showNotification: false,
      showDeleteNotification: false
    });
  }

  _closeNotification() {
    this.setState({ showNotification: false,
      showDeleteNotification: false,
      file_message: ""
    });
  }

  _onConfirmationClose() {
    this.setState({
      LayerOpen: false,
      showDeleteNotification: false,
      file_message: ""
    });
  }

  _Apply() {
      var profilelist= this.state.updateprofilelist;
      var firmwarelist= this.state.updatefirmwarelist;
      this.props.dispatch(Delfirmwarebundle(profilelist,firmwarelist));
      this.setState({
        file_message: "",
        LayerOpen: false,
        showNotification: false,
        showDeleteNotification: true
      });
 }

_onselectbundle(FWindex, FWname) {
  let array = undefined;
  this.setState({file_message: ""});
  var ext = /^.+\.([^.]+)$/.exec(FWindex);
  if (  ext == null) {
    if (FWname.target.checked == false) {
      array = this.state.updateprofilelist;
      let index = array.indexOf(FWindex)
      array.splice(index,1);
      this.setState({ updateprofilelist: array});
    } else {
      array = this.state.updateprofilelist;
      array.push(FWindex);
      this.setState({ updateprofilelist:  array});
    }
  } else {
    if (FWname.target.checked == false) {
      array = this.state.updatefirmwarelist;
      let index = array.indexOf(FWindex)
      array.splice(index,1);
      this.setState({ updatefirmwarelist: array});
    } else {
      array = this.state.updatefirmwarelist;
      array.push(FWindex);
      this.setState({ updatefirmwarelist:  array});
    }
  }
  this.setState({
    showNotification: false,
    showDeleteNotification: false
  });
}

render () {
    let notification = "";
    let consoleMessage = undefined;
    const { ProfileInfo } = this.props;
    let tabledata = "";
    tabledata = Object.values(this.state.bundlelist).map((item,index) =>
      <tr key={index}>
       <td><CheckBox id={item} onChange={this._onselectbundle.bind(this,item)}/></td>
        <td>{item}</td>
      </tr>
    )
    if(window.location.host == '127.0.0.1'){
      this.state.consoleLogin = true;
      consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
    }
    if (this.state.showNotification === true) {
        if (this.props.fwuploadstatus == 201 || this.props.fwuploadstatus == 200 ) {
          notification =
              <Notification onClose={this._closeNotification} pad='medium' size='medium'
                closer='true' status='ok'
                message='Firmware/bundle is uploaded successfully' />
        } else  if (this.props.fwuploadstatus == 409) {
            notification =
              <Notification onClose={this._closeNotification} pad='medium' size='medium'
                closer='true' status='critical'
                message='Firmware/bundle already exists' />
        } else if (this.props.fwuploadstatus == 400) {
            notification = "";
            this.state.file_message = "File/bundle is not valid one";
        } else if (this.props.fwuploadstatus == 413) {
            notification =
              <Notification onClose={this._closeNotification} pad='medium' size='medium'
                closer='true' status='critical'
                message='Firmware/bundle is too large to upload' />
        } else if (this.state.del === 'ok') {
              notification =
              <Notification onClose={this._closeNotification} pad='medium' size='medium'
                closer='true' status='ok'
                message='Deleted successfully' />
        }
    }
    let layer;
    if (this.state.LayerOpen && tabledata != undefined) {
      layer =
        (
          <Layer align="right" closer={true}  overlayClose={true} label='Yes, Delete'
                 onClose={this._onConfirmationClose} compact={true} >
            <Form>
              <Header><Heading tag='h2'>Delete the firmware/bundle(s)</Heading></Header>
              <Paragraph>  Are you sure to delete the selected firmware/bundle(s) ?
              </Paragraph>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='Yes, Delete' primary={true} onClick={this._Apply} />
              </Box>
            </Form>
          </Layer>
        );
    }

    if (this.state.showDeleteNotification){
      if(ProfileInfo != undefined){
        if(ProfileInfo.success != undefined){
          notification = <Notification closer='true' onClose={this._closeNotification} size='medium' status='ok' message={'Firmware/bundle successfully deleted'}/>
        }else{
          notification = <Notification closer='true' onClose={this._closeNotification} size='medium' status='critical' message={'Failed to delete....'}/>
        }
      }
    }

    return (
      <DocsArticle title='Firmware Update'>
        <section>
          <Tabs justify='start'>
            <Tab title='Firmware Upload' >
              <Box pad={{ vertical: 'small', between:'small'}}>
                {consoleMessage}
                {notification}
              </Box>
              <Form>
                <FormField label='Bundle/File Upload' htmlFor='input-id'  error={this.state.file_message}>
                  <input disabled={this.state.consoleLogin} type="file" id="firmware_file" ref="firmware_file"  name="firmware_file" accept=".BIN,.Hpb,.zip"  key='firmware_file' onChange={this._onChange} />
                </FormField>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Upload' primary={true} onClick={(this.state.consoleLogin) ? null : (this._UploadFirmwareFile)}/>
                </Box>

                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Table   >
                    <thead>
                      <tr>
                        <th><strong>{}</strong></th>
                        <th><strong>Firmware/Bundles</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                      {tabledata}
                    </tbody>
                  </Table>
                </Box>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Delete' primary={true} onClick={this._DeleteFirmwareFile}/>
                </Box>
              </Form>
            </Tab>
            <Tab title='Firmware Configuration Upload'>
              <FirmwareConfigurationUpload />
            </Tab>
            <Tab title='Firmware Update'>
              <FirmwareUpdate />
            </Tab>
            <Tab title='Status'>
              <FirmwareStatus />
            </Tab>
          </Tabs>
          {layer}
        </section>
      </DocsArticle>
    );
  }
};

const select = state => ({...state.fwupload ,...state.fwfirmwarelist});

export default connect(select)(FWUpload);


