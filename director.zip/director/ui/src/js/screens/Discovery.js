// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocsArticle from './DocsArticle';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Layer from 'grommet/components/Layer';
import Article from 'grommet/components/Article';
import Button from 'grommet/components/Button';
import FormFields from 'grommet/components/FormFields';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Tabs from 'grommet/components/Tabs';
import Tab from 'grommet/components/Tab';
import TextInput from 'grommet/components/TextInput';
import CheckBox from 'grommet/components/CheckBox';
import Search from 'grommet/components/Search';
import Box from 'grommet/components/Box';
import Paragraph from 'grommet/components/Paragraph';
import PowerIcon from 'grommet/components/icons/base/Power';
import Spinning from 'grommet/components/icons/Spinning';
import {UnRegSystems} from '../actions/discovery';
import {RegConf} from '../actions/multiRegister';
import Notification from 'grommet/components/Notification';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import Label from 'grommet/components/Label';
import SystemRegister from './SystemRegister';
//import DiscoveryTasks from './DiscoveryTasks';
import { loadDashboard } from '../actions/dashboard';


//Update Document Title
FormField.displayName = 'FormField';
Form.displayName = 'Form';

 class Discovery extends Component {
  constructor () {
    super();
    this._checkCIRD = this._checkCIRD.bind(this);
    this._onChange = this._onChange.bind(this);
    this._validateInput = this._validateInput.bind(this);
    this._onRegister = this._onRegister.bind(this);
    this._getSystems = this._getSystems.bind(this);
    this._doSearch = this._doSearch.bind(this);
    this._onSelect = this._onSelect.bind(this);
    this._onSelectAll = this._onSelectAll.bind(this);
    this._onDelete = this._onDelete.bind(this);
    this._onClickDelete = this._onClickDelete.bind(this);
    this._closeNotification = this._closeNotification.bind(this);
    this._closeLayer = this._closeLayer.bind(this);
    this._onClickTargetDeleteTab = this._onClickTargetDeleteTab.bind(this);
    this._onClickNonTargetDeleteTab = this._onClickNonTargetDeleteTab.bind(this);
    this.state = {
      isValid: undefined,
      searchkey: '',
      selectedSystems: [],
      errors: {
        "ip": "",
        "subnet": "",
        "userName": "",
        "password": ""
       //, "frequency": ""
      },
      error: undefined,
      disabled: false,
      showNotification: false,
      showUnregNotification: false,
      showCIDRNotification:false,
      unregLayerOpen: false,
      unregProcessing: false,
      hasSystems: false,
      selectAll: false,
      systemErr: undefined,
      refreshInterval: undefined,
      ShowIP: '',
      ShowMask: ''
    };
    this.data = undefined;
  }

  //If redirecting to some other page stop Backend calls
  componentWillUnmount() {
    clearInterval(this.state.refreshInterval);
  }

  componentWillReceiveProps(nextProps) {
    this.data = nextProps.dashboardData;
    if (nextProps.unregisterResp != undefined || nextProps.unregisterErr != undefined) {
      this.setState({unregProcessing: false});
    }
  }

  _onChange(event) {
    this._validateInput(event);
  }
  //On click of other tabs,stop backend calls
   _onClickNonTargetDeleteTab() {
     this.setState({
          showUnregNotification: false
        });
     clearInterval(this.state.refreshInterval);
   }

  _onClickTargetDeleteTab() {
    this.props.dispatch(loadDashboard());
    //reload the page with a time interval of 20 secs
    var interval = setInterval(() => { this.props.dispatch(loadDashboard()) }, 20000);
    this.setState({ refreshInterval: interval });
  }
 _checkCIRD(value) {
     if (value.indexOf('.') < 0) {//CIDR
       if (value <= 21){
         this.setState({ showCIDRNotification: true });
       } else {
         this.setState({ showCIDRNotification: false });
       }
     } else {//subnet  IP
       var subnet = ["224.0.0.0","240.0.0.0","248.0.0.0","252.0.0.0","254.0.0.0","255.0.0.0","255.128.0.0","255.192.0.0","255.224.0.0","255.240.0.0","255.248.0.0","255.252.0.0","255.254.0.0","255.255.0.0","255.128.0.0","255.192.0.0","255.224.0.0","255.240.0.0","255.248.0.0",];
       if (subnet.indexOf(value) >= 0) {
         this.setState({ showCIDRNotification: true });
       } else {
         this.setState({ showCIDRNotification: false });

       }

     }
   }

  _validateInput(event){
    let err = Object.assign({}, this.state.errors);
    var errMsg;
    var value = event.target.value;
    switch(event.target.accept) {
      case "ip":
        var regex = RegExp('^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')
        if (value != "0.0.0.0"){
          this.state.isValid = regex.test(value);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid IP address";
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      case "netmask":
        this.state.isValid = value.match(/^((3[0-2]|2[0-9]|1[0-9]|[1-9])|(255.255.255.(25[542]|24[80]|224|192|128|0)|255.255.(25[42]|24[80]|224|192|128|0).0|255.(25[42]|24[80]|224|192|128|0).0.0|(25[42]|24[80]|224|192|128|0).0.0.0))$/);
        this._checkCIRD(value);
        errMsg = (this.state.isValid) ? "" : "enter a valid subnet mask or CIDR";
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      // case "frequency":
      //   var regex = RegExp('^0|[5-9]|[1-9][0-9]+$');
      //   if (value != "") {
      //     this.state.isValid = regex.test(value);
      //     errMsg = (this.state.isValid) ? "" : "enter a valid frequency";
      //   } else {
      //     errMsg = "";
      //     this.state.isValid = true;
      //   }
      //   err[event.target.name] = errMsg;
      //   this.setState({errors: err});
      //   break;
      default:
        var regex = RegExp('^[0-9a-zA-Z]+$');
        this.state.isValid = regex.test(value);
        errMsg = (this.state.isValid) ? "" : "enter a valid string";
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
    }
  }

  //Function for search
  _doSearch(event) {
    this.setState({searchkey:event.target.value});
  }

  _getSystems() {
    var me = this;
    var serverData = [];
    var data = this.data;
    var searchText = this.state.searchkey;
    if (data != undefined) {
      Object.keys(data).map(function (status) {
        if (data[status] != undefined) {
          Object.keys(data[status]).map(function (key1) {
            var x = Object.keys(data[status][key1]).map(function (key2) {
              var ip = data[status][key1][key2].ManagerIP;
              if(searchText == '' || ip != undefined && ip.indexOf(searchText) >=0) {
                if (typeof(data[status][key1][key2]) == "object") {
                  var tasks = Object.assign({}, me.state.selectedSystems);
                  var ip = data[status][key1][key2].ManagerIP;
                  var chassis_id = data[status][key1][key2].ChassisID;
                  var server_id = data[status][key1][key2].SystemID;
                  if (tasks[ip] == undefined) {
                    tasks[ip] = [false, 'CH' + chassis_id + 'N' + server_id];
                  }
                  me.state.selectedSystems = tasks;


                  return <TableRow>
                    <td><CheckBox id={data[status][key1][key2].ManagerIP} checked={me.state.selectedSystems[data[status][key1][key2].ManagerIP][0]} onChange={me._onSelect}/></td>
                    <td>{data[status][key1][key2].ManagerIP}</td>
                  </TableRow>
                }
              }
            });
            x = x.filter(function( element ) {
              return element !== undefined;
            });
            if(x != undefined){serverData = serverData.concat(x)};
          });
        }
      });
    }
    if (serverData[0] == undefined) {
      serverData = "No systems found";
      this.state.hasSystems = false;
    } else {
      this.state.hasSystems = true;
    }
    return serverData;
  }

  //on select/deselect system
  _onSelect(e) {
    const item = e.target.id;
    const isChecked = e.target.checked;
    var systems = Object.assign({}, this.state.selectedSystems);
    systems[item][0] = isChecked;
    this.setState({
      selectedSystems: systems,
      selectAll: false
    });
  }

  //on select/deselect all systems
  _onSelectAll(e) {
    var systems = Object.assign({}, this.state.selectedSystems);
    if (e.target.checked) {
        Object.keys(systems).map(function (key) {
            systems[key][0] = true;
        });
    } else {
        Object.keys(systems).map(function (key) {
            systems[key][0] = false;
        });
    }
    this.setState({
        selectedSystems: systems,
        selectAll: e.target.checked
    });
  }

  _onDelete() {
    var hasSelectedSystems = false;
    var systems = Object.assign({}, this.state.selectedSystems);
    Object.keys(systems).map(function (key) {
        if (systems[key][0] == true) {
            hasSelectedSystems = true;
        }
    })
    if (hasSelectedSystems == true) {
        this.setState({
          unregLayerOpen: true,
          systemErr: "",
          showUnregNotification: false
        });
    } else {
        this.setState({ systemErr: "Select one or more systems to delete" });
    }
  }

  //delete selected systems
   _onClickDelete() {
     var me = this;
     var selectedIPs = [];
     var delSystems = this.state.selectedSystems;
     this.setState({
       unregLayerOpen: false,
       showUnregNotification: true,
       selectedSystems: [],
       unregProcessing: true,
       selectAll: false
     });
     Object.keys(delSystems).map(function (key) {
       if (delSystems[key][0] == true) {
         selectedIPs.push(key);
       }
     });
     if (selectedIPs.length != 0)
       me.props.dispatch(UnRegSystems(selectedIPs));
   }

  _onRegister() {
    let reqErr = "required";
    let err = Object.assign({}, this.state.errors);
    this.state.isValid = true;
    if (IP.value == "") {
      err["ip"] = reqErr;
      this.setState({errors: err});
      this.state.isValid = false;
    }
    if (Subnet.value == "") {
      err["subnet"] = reqErr;
      this.setState({errors: err});
      this.state.isValid = false;
    }
    if (UserName.value == "") {
      err["userName"] = reqErr;
      this.setState({errors: err});
      this.state.isValid = false;
    }
    if (Password.value == "") {
      err["password"] = reqErr;
      this.setState({errors: err});
      this.state.isValid = false;
    }
    // if (Frequency.value == "") {
    //   Frequency.value = 0;
    // }

    if ((this.state.errors["ip"] != "") || (this.state.errors["subnet"] != "") || (this.state.errors["userName"] != "") || (this.state.errors["password"] != "") ){//|| (this.state.errors["frequency"] != "" || this.state.isValid == false)) {
      return false;
    }

    let ntpdata =
    {
      "IP": IP.value,
      "Subnet": Subnet.value,
      "UserName": UserName.value,
      "Password": Password.value
     //, "Frequency": parseInt(Frequency.value, 10)
    };
    this.props.dispatch(RegConf(ntpdata));
    this.setState({ShowIP: IP.value});
    this.setState({ShowMask: Subnet.value});
    this.setState({showNotification: true});
  }

  _closeNotification(event) {
    this.setState({ [event]: false })
    this._onClickNonTargetDeleteTab();
  }

  _closeLayer() {
    this.setState({ unregLayerOpen: false })
  }

  render () {
    let notification, systemsNotification, unregLayer = undefined;
    var tableInfo = this._getSystems();
    if (this.state.showCIDRNotification == true) {
      notification =
              <Notification onClose={this._closeNotification.bind(this, 'showCIDRNotification')} pad='medium' size='medium'
                closer='true' status='unknown'
                message='Warning: Specifying a
                network CIDR or corresponding subnet mask less than &#47;21 will put a considerable load on the VM, and may
                cause a number of problems in managing your target devices.  It is suggested
                to break your network scans into &#47;21 or smaller subnets for discovery.' />
    }
    if (this.state.showNotification == true) {
        if (this.props.discoveryResp != undefined) {
            notification =
              <Notification onClose={this._closeNotification.bind(this, 'showNotification')} pad='medium' size='medium'
                closer='true' status='unknown'
                message={'Discovery is initiated on ' + (this.state.ShowIP +'/' + this.state.ShowMask) + ', but will take a few minutes to complete.  Please click on the Dashboard to see newly discovered devices.'} />
        } else if (this.props.discoveryErr != undefined) {
            notification =
              <Notification onClose={this._closeNotification.bind(this, 'showNotification')} pad='medium' size='medium'
                closer='true' status='critical'
                message={this.props.discoveryErr} />
        }
    }
    if (this.state.showUnregNotification == true && this.state.unregProcessing == false) {
      if (this.props.unregisterResp != undefined) {
        systemsNotification =
          <Notification onClose={this._closeNotification.bind(this, 'showUnregNotification')} pad='medium' size='medium'
            closer='true' status='ok'
            message={this.props.unregisterResp} />
      } else if (this.props.unregisterErr != undefined) {
        systemsNotification =
          <Notification onClose={this._closeNotification.bind(this, 'showUnregNotification')} pad='medium' size='medium'
            closer='true' status='critical'
            message={this.props.unregisterErr} />
      }
    }
    if (this.state.unregLayerOpen == true) {
      unregLayer = <Layer align="right" closer={true} overlayClose={true} onClose={this._closeLayer}>
      <Article align='start' >
      <Form>
      <Header><Heading tag='h2'>Unregister Server(s)</Heading></Header>
      <Paragraph>Are you sure you want to unregister the selected server(s)?</Paragraph>
      <Button label='Yes, Unregister' type='submit' primary={true} onClick={this._onClickDelete} />
    </Form>
    </Article>
    </Layer>
    }
    return (
      <DocsArticle title='Discovery & Registration'>
        <Tabs justify='start'>
          <Tab title="Discovery" onClick={this._closeNotification.bind(this, 'showNotification')}>
          <Box pad={{ vertical: 'small' }}>{notification}</Box>
            <Form>
              <FormFields>
                <FormField label='Network IP' error={this.state.errors["ip"]}>
                  <TextInput disabled={this.state.disabled} id='IP' name='ip' type='text' accept='ip' onDOMChange={this._onChange} />
                </FormField>
                <FormField label='Subnet mask or CIDR' error={this.state.errors["subnet"]}>
                  <TextInput disabled={this.state.disabled} id='Subnet' name='subnet' type='text' accept='netmask' onDOMChange={this._onChange} />
                </FormField>
                <FormField label='Username' error={this.state.errors["userName"]}>
                  <TextInput disabled={this.state.disabled} id='UserName' name='userName' type='text' accept='' onDOMChange={this._onChange} />
                </FormField>
                <FormField label='Password' error={this.state.errors["password"]}>
                  <TextInput disabled={this.state.disabled} id='Password' name='password' type='password' accept='' onDOMChange={this._onChange} />
                </FormField>

              </FormFields>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='Register' primary={true} onClick={this._onRegister} />
              </Box>
            </Form>
          </Tab>
          <Tab title="Registration" onClick={this._onClickNonTargetDeleteTab}>
            <SystemRegister />
          </Tab>
          <Tab title="Target Delete" onClick={this._onClickTargetDeleteTab}>
            <Box pad={{ vertical: 'small' }}>{systemsNotification}</Box>
            {this.state.unregProcessing == true ? (
              <Box justify='center'
                align='center'
                wrap={true}
                pad='none'
                margin='none'
                colorIndex='light-1'>
                <Spinning size='small' /><Label size='medium'>Processing please wait ...</Label>
              </Box>
            ) : ("")}
            <Search placeHolder='Search' size ='medium' inline={true} value={this.searchkey} onDOMChange={this._doSearch} />
            <Form>
            <Table scrollable={false}>
              <thead>
                <th><CheckBox disabled={!this.state.hasSystems} checked={this.state.selectAll} onChange={this._onSelectAll}/></th>
                <th><strong>IP Address</strong></th>
              </thead>
              <tbody>
              {tableInfo}
              </tbody>
            </Table>
            </Form>
            <Box direction='row' pad={{ horizontal: 'small', vertical: 'none' }}>
              <Paragraph>{this.state.systemErr}</Paragraph>
          </Box>
          <Box direction='row' pad={{horizontal: 'small',vertical:'none'}}>
              <Button label='Unregister' primary={true} onClick={this._onDelete} />
          </Box>
          </Tab>

        </Tabs>
        {unregLayer}
      </DocsArticle>
    );
  }
};

Discovery.propTypes = {
  dispatch: PropTypes.func.isRequired,
  sessionError: PropTypes.string,
  discoveryResp: PropTypes.string,
};

const select = state => ({ ...state.discoveryInfo, ...state.multiRegisterInfo, ...state.dashboardInfo });

export default connect(select)(Discovery);
