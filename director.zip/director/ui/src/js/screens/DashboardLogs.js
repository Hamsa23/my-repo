// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Status from 'grommet/components/icons/Status';
import Label from 'grommet/components/Label';
import Section from 'grommet/components/Section';

//Update Document Title
Label.displayName = 'Logs';

export default class DashboardLogs extends Component {

  render () {
    return (
      <Section>
         
            <Table selectable={true} width="70%">
              
            <thead>
                 <tr>
                  <th>
                      <strong>
                      ID                                          
                      </strong>
                  </th>
                  <th>
                      <strong>
                      Severity
                      </strong>
                  </th>
                  <th>
                      <strong>
                      Description
                      </strong>
                  </th>
                  <th>
                      <strong>
                      Last Update
                      </strong>  
                  </th>
                  <th>
                      <strong>
                      Count
                      </strong>
                  </th>
                  <th>
                      <strong>
                      Category
                      </strong>  
                  </th>
                </tr>
              </thead>
              
            <tbody>
              <TableRow>
                <td>1</td>
                <td><Status value='ok' size='small'/></td>
                <td>User Logged in</td>
                <td>Jul 5, 20182:16 PM</td>
                <td>1</td>
                <td>System: admin</td>
              </TableRow>
              <TableRow>
                <td>2</td>
                <td><Status value='critical' size='small'/></td>
                <td>Authentication failed</td>
                <td>Jul 5, 20182:16 PM</td>
                <td>1</td>
                <td>System: admin</td>
              </TableRow>
              <TableRow>
                <td>3</td>
                <td><Status value='warning' size='small'/></td>
                <td>Unable to discover devices</td>
                <td>Jul 5, 20182:16 PM</td>
                <td>1</td>
                <td>System: admin</td>
              </TableRow>
              <TableRow>
                <td>4</td>
                <td><Status value='disabled' size='small'/></td>
                <td>User t1 modified by: admin.</td>
                <td>Jul 5, 20182:16 PM</td>
                <td>1</td>
                <td>System: admin</td>
              </TableRow>
              <TableRow>
                <td>5</td>
                <td><Status value='unknown' size='small'/></td>
                <td>Unable to create users</td>
                <td>Jul 5, 20182:16 PM</td>
                <td>1</td>
                <td>System: admin</td>
              </TableRow>
            </tbody>
          </Table>
         
          </Section>
    );
  }
};
