// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import DocsArticle from './DocsArticle';
import { getRegisteredChassis, getTargetPowerReport, getTargetThermalReport, unloadMonitoringData } from '../actions/moniteringtarget';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Heading from 'grommet/components/Heading';
import Form from 'grommet/components/Form';
import FormField from 'grommet/components/FormField';
import Section from 'grommet/components/Section';
import Select from 'grommet/components/Select';
import Tabs from 'grommet/components/Tabs';
import Tab from 'grommet/components/Tab';
import Label from 'grommet/components/Label';
import Legend from 'grommet/components/Legend';
import Chart from 'grommet/components/chart/Chart';
import Spinning from 'grommet/components/icons/Spinning';
import Status from 'grommet/components/icons/Status';
import Notification from 'grommet/components/Notification';

var LineChart = require("react-chartjs").Line;
function chartData() {
  return {
    labels: ['5 Minutes',  '',   '',  '',  '',  '',  '', '', '', '', '',  '', '', '', '', '',
            '', '', '', '', '',  '', '', '', '', '',  '','', '', '', ''],
    datasets: [
      {
        label: 'CPU',
        fillColor: 'transparent',
        strokeColor: 'rgb(0, 51, 153)',
        pointColor: 'rgb(0, 51, 153)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '10-NIC',
        fillColor: 'transparent',
        strokeColor: 'rgb(255, 102, 0)',
        pointColor: 'rgb(255, 102, 0)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '06-DIMM 4',
        fillColor: 'transparent',
        strokeColor: 'rgb(0, 153, 204)',
        pointColor: 'rgb(0, 153, 204)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '08-M.2 2',
        fillColor: 'transparent',
        strokeColor: 'rgb(51, 102, 204)',
        pointColor:'rgb(0, 153, 204)', 
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '22-L Cart Inlet',
        fillColor: 'transparent',
        strokeColor: 'rgb(0, 255, 255)',
        pointColor: 'rgb(0, 255, 255)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '40-GPU',
        fillColor: 'transparent',
        strokeColor: 'rgb(204, 102, 255)',
        pointColor:'rgb(204, 102, 255)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '22-HD Max',
        fillColor: 'transparent',
        strokeColor: 'rgb(102, 0, 153)',
        pointColor:  'rgb(102, 0, 153)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '23-R Cart Inlet',
        fillColor: 'transparent',
        strokeColor: 'rgb(0, 51, 102)',
        pointColor: 'rgb(0, 51, 102)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '34-GPU 1',
        fillColor: 'transparent',
        strokeColor: 'rgb(153, 51, 51)',
        pointColor: 'rgb(153, 51, 51)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
        label: '34-GPU 2',
        fillColor: 'transparent',
        strokeColor: 'rgb(153, 153, 153)',
        pointColor: 'rgb(153, 153, 153)',
        pointStrokeColor: 'transparent',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {	
      label: 'CPU',
      fillColor: 'transparent',
      strokeColor: 'rgb(0, 51, 153)',
      pointColor: 'rgb(0, 51, 153)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'iSM CPU',
      fillColor: 'transparent',
      strokeColor: 'rgb(255, 102, 0)',
      pointColor: 'rgb(255, 102, 0)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'Daughter Card',
      fillColor: 'transparent',
      strokeColor: 'rgb(0, 153, 204)',
      pointColor: 'rgb(0, 153, 204)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'Mini PCI-E Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(51, 102, 204)',
      pointColor:'rgb(0, 153, 204)', 
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'IR3899 Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(0, 255, 255)',
      pointColor: 'rgb(0, 255, 255)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'WAN Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(204, 102, 255)',
      pointColor:'rgb(204, 102, 255)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'Wi-Fi Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(102, 0, 153)',
      pointColor: 'rgb(102, 0, 153)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'iSM Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(0, 51, 102)',
      pointColor: 'rgb(0, 51, 102)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'SATA M.2 Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(153, 51, 51)',
      pointColor: 'rgb(153, 51, 51)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      {
      label: 'DIMM Zone',
      fillColor: 'transparent',
      strokeColor: 'rgb(153, 153, 153)',
      pointColor: 'rgb(153, 153, 153)',
      pointStrokeColor: 'transparent',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    }
    ]
  }
}

class MonitoringReporting extends Component {
  constructor () {
    super();
    this._getRequiredSensors = this._getRequiredSensors.bind(this);
    this._getChassisList = this._getChassisList.bind(this);
    this._onChangeChassis = this._onChangeChassis.bind(this);
    this._getPowerSupplies= this._getPowerSupplies.bind(this);
    this._getFans = this._getFans.bind(this);
    this._getSensor = this._getSensor.bind(this);
    this._onClickThermalTab = this._onClickThermalTab.bind(this);
    this._onClickPowerTab = this._onClickPowerTab.bind(this);
    this._onClickFanTab = this._onClickFanTab.bind(this);
    this.state = {
      chassisData: '',
      refreshInterval: undefined,
      value: '',
      pageLoad: undefined,
      ChassisInfo: undefined,
      thermalDataLoaded: undefined,
      powerDataLoaded: undefined
    };
    this.data = chartData();
    this.notification ='';
    this.el300 = ['CPU', 'iSM CPU', 'Daughter Card', 'Mini PCI-E Zone', 'IR3899 Zone', 'WAN Zone','Wi-Fi Zone','PCI-E M.2 Zone', 'iSM Zone', 'SATA M.2 Zone','DIMM Zone','HDD Zone','Ethernet Chip Zone','System Power Temp','Carrier EFUSE Temp','Pressure Sensor Temp'];
    this.el4000 = ['02-CPU', '10-NIC', '06-DIMM 4', '08-M.2 2', '22-L Cart Inlet', '23-R Cart Inlet','40-GPU'];
    this.el1000 = ['02-CPU', '10-NIC', '06-DIMM 4', '08-M.2 2', '22-L Cart Inlet', '23-R Cart Inlet','34-GPU 1','34-GPU 2','22-HD Max'];
    this.thermalHistory = [];
    this.selectedChassis = {
      ChassisSerial: '',
      ChassisModel: '',
      ChassisAbstraction: '',
      ChassisFirmware: '',
      ChassisPLD: '',
      ChassisID: ''
    }
  }
  
  _onClickFanTab(event){
    clearInterval(this.state.refreshInterval);
    var chassisId = this.selectedChassis.ChassisIndex
    if (chassisId != undefined) {
      this.props.dispatch(getTargetThermalReport(chassisId));
      this.setState({thermalDataLoaded: false});
    }
  }
  
  _onClickThermalTab(event){
    clearInterval(this.state.refreshInterval);
    var chassisId = this.selectedChassis.ChassisIndex
    if (chassisId != undefined) {
      this.props.dispatch(getTargetThermalReport(chassisId));
      this.setState({thermalDataLoaded: false});
    }
    //reload the page with a time interval of 60 secs
    var interval = setInterval( () => {
    this.props.dispatch(getTargetThermalReport(this.selectedChassis.ChassisIndex))}, 10000);    
    this.setState({refreshInterval: interval}); 
  }
  

  _onClickPowerTab(event){
    clearInterval(this.state.refreshInterval);
    var chassisId = this.selectedChassis.ChassisIndex
    if (chassisId != undefined) {
      this.props.dispatch(getTargetPowerReport(chassisId));
      this.setState({powerDataLoaded: false});
    }
  }

  _onChangeChassis(event){
    this.setState({
      value: event.value,
      pageLoad: true,
    });
    this.data = chartData();
    this.selectedChassis = this.state.ChassisInfo[event.value];
    var chassisId = this.selectedChassis.ChassisIndex;
    if(chassisId != undefined) {
      this.props.dispatch(getTargetThermalReport(chassisId)); 
      this.props.dispatch(getTargetPowerReport(chassisId));
      this.setState({thermalDataLoaded: false, powerDataLoaded: false});
    }
  }

  _getChassisList (data) {
    var chassisData;
    var selectData = [];
    var chassisList = [];
    var me = this;
    if (data != undefined) {
      Object.keys(data).map(function (status) {
        if (data[status] != undefined) {
          chassisData = Object.keys(data[status]).map(function (key1) {
            if(chassisList.indexOf(data[status][key1].ChassisID) == -1){
              chassisList.push(data[status][key1].ChassisID);
              var info =[];
              var rec = {};
              rec.ChassisSerial = data[status][key1].ChassisSerial;
              rec.ChassisModel = data[status][key1].ChassisModel;
              rec.ChassisFirmware = data[status][key1].ChassisFirmware;
              rec.ChassisAbstraction = data[status][key1].ChassisAbstraction;
              rec.ChassisPLD = data[status][key1].ChassisPLD;          
              rec.ChassisIndex = data[status][key1].ChassisID;
              rec.optn = "Serial :".concat(data[status][key1].ChassisSerial).concat(" : Model: ").concat(data[status][key1].ChassisModel);
              var info = Object.assign({}, me.state.ChassisInfo);
              info[rec.optn] = rec;
              me.state.ChassisInfo = info;
              return rec.optn;
            }
          });
          if (chassisData != undefined) {
            selectData = selectData.concat(chassisData);
          }
        }
      });
    }
   return selectData;
  }

  _getFans (data) {
    var me = this;
    var tableData;
    if (data != undefined) {
      if (data.Fans != undefined) {
        tableData = Object.keys(data.Fans).map(function (key1) {
          
          var status= '';
            if(data.Fans[key1].Status.Health.toString().toLowerCase() =='ok'){
              status =<Status value='ok' size='small'/>;
            } else if(data.Fans[key1].Status.Health.toString().toLowerCase() =='critical'){
              status =<Status value='critical' size='small'/>;
            
            } else if(data.Fans[key1].Status.Health.toString().toLowerCase() =='warning'){
              status =<Status value='warning' size='small'/>;
            
            } else if(data.Fans[key1].Status.Health.toString().toLowerCase() =='disabled'){
              status =<Status value='disabled' size='small'/>;
            
            } else if(data.Fans[key1].Status.Health.toString().toLowerCase() =='unknown'){
              status =<Status value='unknown' size='small'/>;
            }
        
        
          return <TableRow key1={key1} >
            <td>{data.Fans[key1].FanName}</td>
            <td>{status}</td>
            <td>{data.Fans[key1].CurrentReading}</td>
            <td>{data.Fans[key1].Oem.Hp.Location}</td>
          </TableRow>
        });
      }else{
        return <TableRow >
          <td colspan="4">Fan module is not available </td>
        </TableRow>;
      }
    }
    return tableData;
  }

  _getRequiredSensors (data) {
    var requiredSensors = [];
    if (this != undefined) {
      var model = this.selectedChassis.ChassisModel;
      var SensorList =[];
      if(model == undefined){
        return model;
      }
      if(model.indexOf("EL4000") > -1){
        SensorList = this.el4000;
      }else if(model.indexOf("EL300") > -1){
        SensorList = this.el300;
      }else {
        SensorList = this.el1000;
      }
      if (data != undefined && data.Temperatures != undefined) {        
        for(let i = 0; i < data.Temperatures.length; i++){// 
           var name = data.Temperatures[i].Name; 
          if(SensorList.indexOf(name) >= 0){
            requiredSensors.push(data.Temperatures[i]);
          
          for(let j = 0; j < this.data.datasets.length; j++){//line chart
            var currentReading = undefined;
            if(this.data.datasets[j].label == name){     
              if(this.data.datasets[j].data.length == 31){ 
                this.data.datasets[j].data.shift();
              } 
              if(data.Temperatures[i].hasOwnProperty('ReadingCelsius')){
                currentReading =data.Temperatures[i].ReadingCelsius;
              } else if(data.Temperatures[i].hasOwnProperty('CurrentReading')){
                currentReading =data.Temperatures[i].CurrentReading;
              }            
              this.data.datasets[j].data.push(currentReading);    
              
          if(data.Temperatures[i].Status.hasOwnProperty('Health')){        
              if( data.Temperatures[i].Status.Health.toString().toLowerCase() =='critical'){
                this.data.datasets[j].strokeColor = 'rgb(255,0,0)';
              } else if( data.Temperatures[i].Status.Health.toString().toLowerCase() =='warning'){
                this.data.datasets[j].strokeColor = 'rgb(255, 204, 0)';
              }
             } else if (data.Temperatures[i].Status.State == 'Absent'){
                this.data.datasets[j].strokeColor = 'unknown';
              } 
              continue;
            } else{
              continue;
            }
          }
        }
        } 
      }
      return requiredSensors; 
    }
  }
  
    _getPowerSupplies(data){      
    var tableData;
    if (data != undefined) {
      if (data.PowerSupplies != undefined) {
        tableData = Object.keys(data.PowerSupplies).map(function (key1) {
          var status= '';
            if(data.PowerSupplies[key1].Oem.Hp.PowerSupplyStatus.State.toString().toLowerCase() =='ok'){
              status =<Status value='ok' size='small'/>;
            } else if(data.PowerSupplies[key1].Oem.Hp.PowerSupplyStatus.State.toString().toLowerCase() =='critical'){
              status =<Status value='critical' size='small'/>;
            
            } else if(data.PowerSupplies[key1].Oem.Hp.PowerSupplyStatus.State.toString().toLowerCase() =='warning'){
              status =<Status value='warning' size='small'/>;
            
            } else if(data.PowerSupplies[key1].Oem.Hp.PowerSupplyStatus.State.toString().toLowerCase() =='disabled'){
              status =<Status value='disabled' size='small'/>;
            
            } else if(data.PowerSupplies[key1].Oem.Hp.PowerSupplyStatus.State.toString().toLowerCase() =='unknown'){
              status =<Status value='unknown' size='small'/>;
            }
        
        
              return <TableRow >
              <td>{data.PowerSupplies[key1].Oem.Hp.BayNumber}</td>
              <td>{data.PowerSupplies[key1].Name} </td>
              <td>{data.PowerSupplies[key1].Model}</td> 
              <td>{status}</td>
              <td>{data.PowerSupplies[key1].SerialNumber}</td>
              <td>{data.PowerSupplies[key1].SparePartNumber}</td>
              <td>{data.PowerSupplies[key1].PowerSupplyType}</td>
              <td>{data.PowerSupplies[key1].FirmwareVersion}</td>
              <td>{data.PowerSupplies[key1].PowerCapacityWatts} W</td>
              <td>{data.PowerSupplies[key1].LastPowerOutputWatts} W</td>
            </TableRow>;
        });
      }else{
        return <TableRow >
          <td colspan="10">Power Supplies not available </td>
        </TableRow>;
      }
    }
    return tableData;
    }

  _getSensor (data) {
    var tableData = [];
    if (data != undefined) {
        tableData = Object.keys(data).map(function (key1) {
          if (data[key1] != undefined) {  
            var status ='undefined';
            var unit = '';
            var caution= '';
            var critical= '';
            if(data[key1].Status.State != "Absent"){
              if(data[key1].Status.Health.toString().toLowerCase() =='ok'){
                status =<Status value='ok' size='small'/>;
              } else if(data[key1].Status.Health.toString().toLowerCase() =='critical'){
                status =<Status value='critical' size='small'/>;
              
              } else if(data[key1].Status.Health.toString().toLowerCase() =='warning'){
                status =<Status value='warning' size='small'/>;
              
              } else if(data[key1].Status.Health.toString().toLowerCase() =='disabled'){
                status =<Status value='disabled' size='small'/>;
              
              } else if(data[key1].Status.Health.toString().toLowerCase() =='unknown'){
                status =<Status value='unknown' size='small'/>;
              }
            } else{
              status ='Absent';
            }
            if(data[key1].hasOwnProperty('Units')){
            if(data[key1].Units.toString().toLowerCase() =='celsius'){
              unit =' °C ';
            } else {
              unit =' °F ';
            }
           }
            if(data[key1].hasOwnProperty('UpperThresholdCritical')){
              caution = data[key1].UpperThresholdCritical
              critical = data[key1].UpperThresholdFatal
            } else {
            if(data[key1].LowerThresholdCritical == undefined || data[key1].LowerThresholdCritical == 0 ){
                critical = 'N/A';
            } else{
              critical = data[key1].LowerThresholdCritical + unit; 
            }
            if(data[key1].LowerThresholdNonCritical == undefined || data[key1].LowerThresholdNonCritical == 0 ){
                caution = 'N/A';
            } else{
              caution = data[key1].LowerThresholdNonCritical + unit; 
            }}
            var currentReading = undefined;
            if(data[key1].hasOwnProperty('ReadingCelsius')){
              currentReading =data[key1].ReadingCelsius;
              unit =' °C ';
            } else if(data[key1].hasOwnProperty('CurrentReading')){
              currentReading =data[key1].CurrentReading;
            }
            var xmm = undefined;
            var ymm = undefined;
            if((data[key1] != undefined) && data[key1].hasOwnProperty('Oem')){
              xmm =data[key1].Oem.Hp.LocationXmm;
              data[key1].Oem.Hp.LocationYmm;
            } 

            return <TableRow >
            <td>{data[key1].Name}</td>
            <td>{data[key1].PhysicalContext}</td>
            <td>{xmm}</td>
            <td>{ymm}</td>
            <td>{status}</td>
            <td>{currentReading}{unit}</td>
            <td>Caution:  {caution}Critical:{critical}</td>
          </TableRow>;
          }
        });
    }
    return tableData;
  }

  componentDidMount() {
    this.props.dispatch(getRegisteredChassis());
  }

  componentWillReceiveProps(nextProps){
    if(nextProps.thermalData != undefined) {
      this.setState({thermalDataLoaded: true});
    }
    if(nextProps.powerData != undefined){
      this.setState({powerDataLoaded: true});
    }
  }

  componentWillUnmount(){
    clearInterval(this.state.refreshInterval);
    this.props.dispatch(unloadMonitoringData());
  }

  render () {
    const { thermalData } = this.props;
    const { powerData } = this.props;

    var optnData = [];
    var sensors = '';
    var fans = '';
    var powerReadings = '';
    var data = this.props.chassisData;
    if (thermalData != undefined) {
      fans = this._getFans(thermalData);
      var filtered = this._getRequiredSensors(thermalData);
      if(filtered != undefined){
        sensors = this._getSensor(filtered) ;
      }

    }
    if (powerData != undefined) {
      powerReadings = this._getPowerSupplies(powerData) 
    }
    var rows = this._getChassisList(data);
    if(rows != undefined && rows.length >= 0){
     if( rows.length > 0){

        Object.keys(rows).map(function (key) {
          if(rows[key] != undefined) {
            optnData = optnData.concat(rows[key]);
          }
        });
        if (this.state.pageLoad != true) {
          this.state.value = optnData[0];
          this.selectedChassis = this.state.ChassisInfo[optnData[0]] ;
        }
      } else {
        this.notification = (<Notification onClose={this._onCloseMsg} pad="medium" status='unknown' size='medium' closer='true'
        message='Registered chassis not available.'/>);
      }
    }
 
    return (
      <DocsArticle title='Monitoring and Reporting'>
          {this.props.chassisData == undefined && this.state.chassisError == undefined ? (
            <Box justify='center'
            align='center'
            wrap={true}
            pad='none'
            margin='none'
            colorIndex='light-1'>
              <Spinning size='small' /><Label size='medium'>Loading ...</Label>
            </Box>
          ) : ("")}
        <Form>
          <FormField label='Registered chassis'>
            <Select
              multiple={false}
              inline={false}
              options={optnData}
              value={this.state.value}
              onChange={this._onChangeChassis} />
             
          </FormField>
        </Form>
              <Tabs justify='start'>
                <Tab title='Information'>
                  <Table>
                    <tbody align="left">
                    <TableRow>
                      <td><strong>Chassis Serial:</strong></td>
                      <td align="left">{this.selectedChassis.ChassisSerial}</td>                      
                    </TableRow>
                    <TableRow>
                      <td><strong>Chassis Model:</strong></td>
                      <td align="left">{this.selectedChassis.ChassisModel}</td>                      
                    </TableRow>
                    <TableRow>
                      <td><strong>Chassis Firmware:</strong></td>
                      <td align="left">{this.selectedChassis.ChassisFirmware}</td>                      
                    </TableRow>
                    <TableRow>
                      <td><strong>CPLD:</strong></td>
                      <td align="left">{this.selectedChassis.ChassisPLD}</td>
                    </TableRow>
                    </tbody>
                  </Table>
                </Tab>
                <Tab title='Thermal' onClick={this._onClickThermalTab} >
                  <Heading tag='h3'><strong>Thermal graph</strong></Heading>                            
                    {this.state.thermalDataLoaded == false && this.state.thermalError == undefined ? (
                      <Box justify='center'
                      align='center'
                      wrap={true}
                      pad='none'
                      margin='none'
                      colorIndex='light-1'>
                        <Spinning size='small' /><Label size='medium'>Loading ...</Label>
                      </Box>
                    ) : ("")}
            <Section >
            <Chart><LineChart data={this.data}  width="850"  height="300"/></Chart>
             </Section>
                  <Heading tag='h3'><strong>Sensor data</strong></Heading>
                  <Table selectable={true}  >
                    <TableRow>
                      <th><strong>Sensor</strong></th>
                      <th><strong>Location</strong></th>
                      <th><strong>X</strong></th>
                      <th><strong>Y</strong></th>
                      <th><strong>Status</strong></th>
                      <th><strong>Reading</strong></th>
                      <th><strong>Threashold</strong></th>
                    </TableRow>
                    {sensors}
                  </Table>
                </Tab>
                <Tab title='Power meter' onClick={this._onClickPowerTab} >
                  <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                    <Section>
                      <Heading tag='h3'><strong>Power supplies</strong></Heading>
                      {this.state.powerDataLoaded == false && this.state.powerError == undefined ? (
                      <Box justify='center'
                      align='center'
                      wrap={true}
                      pad='none'
                      margin='none'
                      colorIndex='light-1'>
                        <Spinning size='small' /><Label size='medium'>Loading ...</Label>
                      </Box>
                    ) : ("")}
                      <Table selectable={true}  width="70%">
                        <TableRow>
                          <th><strong>Bay</strong></th>
                          <th><strong>Name</strong></th>
                          <th><strong>Model</strong></th>
                          <th><strong>Status</strong></th>                          
                          <th><strong>Serial</strong></th>
                          <th><strong>Spare</strong></th>
                          <th><strong>Type</strong></th>
                          <th><strong>Firmware</strong></th>
                          <th><strong>Capacity</strong></th>
                          <th><strong>Present Power Reading</strong></th>
                        </TableRow>
                        {powerReadings}
                      </Table>
                    </Section>
                  </Box>
                </Tab>
                <Tab title='Fans' onClick={this._onClickFanTab}>
                <Section>
                  {this.state.thermalDataLoaded == false && this.state.thermalError == undefined ? (
                      <Box justify='center'
                      align='center'
                      wrap={true}
                      pad='none'
                      margin='none'
                      colorIndex='light-1'>
                        <Spinning size='small' /><Label size='medium'>Loading ...</Label>
                      </Box>
                    ) : ("")}
                    <Table selectable={true}  width="70%">
                      <TableRow>
                        <th><strong>Fan Name</strong></th>
                        <th><strong>Health</strong></th>
                        <th><strong>Current Reading</strong></th>
                        <th><strong>Location</strong></th>
                      </TableRow>
                      {fans}
                    </Table>
                  </ Section>
                </Tab>
              </Tabs>
      </DocsArticle>
    );
  }
};


const select = state => ({ ...state.moniteringtarget });
export default connect(select)(MonitoringReporting);