// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Label from 'grommet/components/Label';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Section from 'grommet/components/Section';
import Button from 'grommet/components/Button';
import Select from 'grommet/components/Select';
import { GetFWBundleList, UploadConfigFile, GetFWProfile, DeleteProfile } from '../actions/fwupdate';
import Notification from 'grommet/components/Notification';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import CheckBox from 'grommet/components/CheckBox';
import Layer from 'grommet/components/Layer';
import LayerForm from 'grommet-templates/components/LayerForm';
import FormFields from 'grommet/components/FormFields';
import Paragraph from 'grommet/components/Paragraph';
import { setInterval, clearInterval } from 'timers';

Label.displayName = 'Firmware Configuration Upload';

class FWConfigUpload extends Component {

  constructor () {
    super();
    this.state = {
      val: undefined,
      config_required: undefined,
      config_file: undefined,
      showNotification: false,
      showDeleteNotification: false,
      list: undefined,
      bundlelist: [],
      updateprofilelist: [],
      DeleteLayerActive: false,
      consoleLogin: false,
      FileType: undefined
    };
    
    this._onChange = this._onChange.bind(this);
    this._UploadFile = this._UploadFile.bind(this);
    this._onConfigChange = this._onConfigChange.bind(this);
    this._DeleteConfig = this._DeleteConfig.bind(this);
    this._getData = this._getData.bind(this);
    this._onSelectProfile = this._onSelectProfile.bind(this);
    this._onClose = this._onClose.bind(this);
    this._deleteProfile = this._deleteProfile.bind(this);
  }

  //After Page load perform actions
	componentDidMount() {
    var me = this;
    this.props.dispatch(GetFWBundleList());
    this.props.dispatch(GetFWProfile());
    var interval = setInterval( () => {
      this.props.dispatch(GetFWBundleList());
      this.props.dispatch(GetFWProfile())}, 120000);
			this.setState({refreshInterval: interval}); 
	}
	 
	//If redirecting to some other page stop Backend calls
	componentWillUnmount() {
		clearInterval(this.state.refreshInterval);
	}

  // Update Edit Form on Click
	componentWillReceiveProps(){
  var list = undefined;
	list = this.props.ProfileList;
  let array=[];
    if(list != undefined && list != 'Malformed Syntax' && list != 'Internal Server Error' && list != 'Unable to get Profile list' && list.bundles != undefined){
      Object.keys(list.bundles).map(function (key) {
        array.push(key);
      });      
      this.setState({ bundlelist: array});
      clearInterval(this.state.refreshInterval);
    }
	}

  // On drop down menu list
  _onChange(event) {
    this.setState({ val: event.value });
  }

  _UploadFile(){
    this.setState({showNotification: false});
    this.setState({showDeleteNotification: false});
    let file = undefined;
    file = this.refs.file.files[0];
    if(file == undefined){
      this.setState({ config_required: "configuration file is required" });
    } else if(this.state.FileType != 'text/plain'){
      this.setState({ config_required: "file is not valid one" });
    } else{
      this.props.dispatch(UploadConfigFile(file, this.state.val));
      this.setState({showDeleteNotification: false});
      this.setState({showNotification: true});
    }
  }

  _DeleteConfig(){
    this.setState({ DeleteLayerActive: true });
  }

  _deleteProfile(){
    if(this.state.updateprofilelist.length != 0){
      var profilelist= this.state.updateprofilelist;
      this.props.dispatch(DeleteProfile(profilelist));
      this.setState({updateprofilelist: []});
      this.setState({ showNotification: false});
      this.setState({showDeleteNotification: true});
      this.setState({ DeleteLayerActive: false });
    }else{
      this.setState({updateprofilelist: []});
    }
  }

  _getData(){
    var me = this;
    var tabData = [];
    var data = undefined;
    data = this.props.BundleInfo;
    if(data != undefined){
      var tab = Object.keys(data).map(function (key) {
        if(data[key] != undefined){
          return <TableRow>
            <td><CheckBox id={data[key]} onChange={me._onSelectProfile.bind(this,data[key])}/></td>
            <td>{data[key]}</td>
          </TableRow>
          }
        });
      if(tab != undefined){tabData = tabData.concat(tab)};
    }
    if(tabData[0] == undefined){
      return tabData = "No configuration files found";
    }else{
      return tabData;
    }
  }

  _onSelectProfile(profile, event) {
    let array = undefined;
    if(event.target.checked == false){
      array = this.state.updateprofilelist;
      let index = array.indexOf(profile)
      array.splice(index,1)
      this.setState({ updateprofilelist: array})
    }else{
      array = this.state.updateprofilelist;
      array.push(profile)
      this.setState({ updateprofilelist: array})
    }
    this.setState({showNotification: false});
    this.setState({showDeleteNotification: false});
  }

  _onConfigChange(event){
    this.setState({ FileType: event.target.files[0].type });
    this.setState({ config_required: undefined });
    this.setState({ showNotification: false });
    this.setState({ showDeleteNotification: false });
    this.setState({ myFileName: event.target.files[0].name });
    this.setState({ myFileHandle: event.target.files[0] });
    this.setState({ json_config_file:event.target.files[0] });
  }

  _onClose(){
    this.setState({ showNotification: false});
    this.setState({ DeleteLayerActive: false });
    this.setState({showDeleteNotification: false});
  }


  render () {
    const { ProfileList } = this.props;
    const { UploadStatus } = this.props;
    const { BundleInfo } = this.props;
    const { ProfileInfo } = this.props;
    let consoleMessage = undefined;

    var tableinfo = this._getData(); //Fetch Profile Table data

    let notification;
    if (this.state.showNotification){
      if(UploadStatus != undefined){
        if(UploadStatus == undefined){
          notification = <Notification onClose={this._onClose} size='medium' status='critical' message={"Failed to Upload File"}/>
        }
        else if((UploadStatus != 'Unable to Upload Config File') && (UploadStatus != 'Internal Server Error') && (UploadStatus != 'File already exists') && (UploadStatus != 'Malformed Syntax')){
          notification = <Notification onClose={this._onClose} size='medium' status='ok' message={'File successfully uploaded'}/>
        }
        else{
          notification = <Notification onClose={this._onClose} size='medium' status='critical' message={UploadStatus}/>
        }
      }
    }

    if(window.location.host == '127.0.0.1'){
      this.state.consoleLogin = true;
      consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
    }

    let DeleteNotification;
    if (this.state.showDeleteNotification){
      if(ProfileInfo != undefined){
        if(ProfileInfo.success != undefined){
          notification = <Notification onClose={this._onClose} size='medium' status='ok' message={'Profile Successfully Deleted'}/>
        }else{
          notification = <Notification onClose={this._onClose} size='medium' status='critical' message={'Failed to delete profile'}/>
        }
      }
    }
     
     let DeleteProfile;
		if(this.state.DeleteLayerActive){
      var list = JSON.stringify(this.state.updateprofilelist);//Create list
      DeleteProfile=
        (
          <LayerForm align='center' title="Update Firmware" submitLabel="Yes, Delete" overlayClose={true} 
            onClose={this._onClose} onSubmit={this._deleteProfile}>
            <fieldset>
						  <Box>
					 			<FormFields>
					 				<fieldset>
					 					<Paragraph>Are you sure you want to Delete {list} Profile(s)?</Paragraph>
					 				</fieldset>
					 			</FormFields>
					 		</Box>		
            </fieldset>
          </LayerForm>
				);
      }

    return (
      <Section pad='none'>
      <Box pad={{ vertical: 'small', between:'small' }}>
        {consoleMessage}
        {notification}
        {DeleteNotification}
      </Box>
      <Form>
        <FormField label='Configuration file' htmlFor='input-id' error={this.state.config_required}>
          <input disabled={this.state.consoleLogin} type="file" id="file" ref="file" accept=".txt"  name="json_config_file" key='json_config_file' onChange={this._onConfigChange}/>
        </FormField>
        <br/>
        <FormField label='Select Firmware Bundle'>
          <Select disabled={this.state.consoleLogin} placeHolder='-- Choose The Configuration File --' options={this.state.bundlelist} value={this.state.val} onChange={this._onChange} />
        </FormField>
        <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
          <Button label='Upload' primary={true} onClick={(this.state.consoleLogin) ? null : this._UploadFile} />
        </Box>
        <Table scrollable={false}>
          <thead>
            <tr>
              <th><strong>Select</strong></th>
              <th><strong>Profile Name</strong></th>
            </tr>
          </thead>
          <tbody>
            {tableinfo}
          </tbody>
	      </Table>
        <Box direction='row'>
          <Button label='Delete' primary={true} onClick={this._DeleteConfig}/>  
        </Box>   
        <Box>
				  {DeleteProfile}
				</Box>           
      </Form>
      </Section>
    );
  }
};

const select = state => ({ ...state.FWProfile, ...state.FWConfigUpload, ...state.firmwareupdate });

export default connect(select)(FWConfigUpload);
