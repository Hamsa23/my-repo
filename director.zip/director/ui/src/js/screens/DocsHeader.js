// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { navActivate } from '../actions/nav';
import PropTypes from 'prop-types';
import Header from 'grommet/components/Header';
import Box from 'grommet/components/Box';
import Paragraph from 'grommet/components/Paragraph';
import Anchor from 'grommet/components/Anchor';
import CircleInformationIcon from 'grommet/components/icons/base/CircleInformation';
import HelpIcon from 'grommet/components/icons/base/Help';
import SessionMenu from '../components/SessionMenu';
import { EIMTime } from './urls';
import { sendRedfishActionRequest } from '../actions/redfishActionUtil';



class DocsHeader extends Component {
  constructor() {
    super();
    this._onClose = this._onClose.bind(this);
     this._onHelp = this._onHelp.bind(this);
    this.state = {
      date: undefined,
      eimDateTime: undefined,
      refreshInterval: undefined
     
    }
  }
    
  componentDidMount() {
    this.props.dispatch(sendRedfishActionRequest( 'GET', EIMTime));
    //reload the page with a time interval of 30 secs
    var interval = setInterval( () => {
		this.props.dispatch(sendRedfishActionRequest( 'GET', EIMTime))}, 60000);
		this.setState({refreshInterval: interval}); 
  }


  componentWillReceiveProps(nextProps){
    var data = nextProps.successResponse;
    if(data.hasOwnProperty("DateAndTime")){
      var dt = data.DateAndTime;
      var EIMDateandTime=  dt.EIMDateAndTime.slice(0,16)+dt.EIMDateAndTime.slice(19,28);
      this.setState({"eimDateTime": EIMDateandTime});
    } 
  }
  
  _onClose() {
    this.props.dispatch(navActivate(true));
  }

   _onHelp() {

    //console.log('url ', window.location.href);
     var expectedpage = window.location.href.substr(window.location.href.lastIndexOf('/') + 1).replace('#','');
    // console.log(' first login ', "./help/" + expectedpage +  ".html");
      let hLastOpenedWindow = window.open("./help/" + expectedpage +  ".html", "blank", "toolbar=no,type=fullscreen");
    if (hLastOpenedWindow !== null) {
            hLastOpenedWindow.focus();
                                }
              }

  render () {
    return (
      <Header colorIndex='neutral-1' fixed={true} size='small' splash={false} float={false}>
      <Paragraph pad='none' onClick={this._onClose}>{this.state.eimDateTime}</Paragraph>
      <Box flex={true}
        justify='end'
        direction='row'
        responsive={false}>

        <SessionMenu />
        <Anchor name="Help" icon={<HelpIcon />}  href={'#'} onClick={this._onHelp} />

        <Anchor name="About"  />

      </Box>
      </Header>

          );
        }
      };

DocsHeader.propTypes = {
  centered: PropTypes.bool,
  colorIndex: PropTypes.string
};

DocsHeader.defaultProps = {
  centered: false
};
const select = state => ({ ...state.redfishReducers });
export default connect(select)(DocsHeader);
