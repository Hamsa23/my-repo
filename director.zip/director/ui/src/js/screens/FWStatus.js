// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Label from 'grommet/components/Label';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Section from 'grommet/components/Section';
import { GetFWID } from '../actions/fwupdate';
import { setInterval, clearInterval } from 'timers';
import Meter from 'grommet/components/Meter';
import Value from 'grommet/components/Value';
import Accordion from 'grommet/components/Accordion';
import AccordionPanel from 'grommet/components/AccordionPanel';
import Status from 'grommet/components/icons/Status';
import Spinning from 'grommet/components/icons/Spinning';
Label.displayName = 'Firmware Status';

class FWStatus extends Component {

  constructor() {
    super();
    this.state = {
      IDList: undefined
    };
    this._getData = this._getData.bind(this);

  }

  componentDidMount() {
    this.props.dispatch(GetFWID());
    var interval = setInterval(() => {
      this.props.dispatch(GetFWID())
    }, 5000);
    this.setState({ refreshInterval: interval });
  }

  componentWillUnmount() {
    clearInterval(this.state.refreshInterval);
  }

  _getData() {
    var tabData = [];
    var percent = 0;
    var accordion = [];
    if (this.props.FWIDInfo != undefined) {
      var statusinfo = this.props.FWIDInfo;
      for (let i = 0; i < statusinfo.length; i++) {
        if (statusinfo[i].type == "firmware_task_manager" ) {
          var info = statusinfo[i].result;
              var percentage = statusinfo[i].percentage;
              var header = ("Firmware flash is " + percentage + '%' + " completed, with the status reported as " + statusinfo[i].state );
              var tab = Object.keys(info).map(function (key) {
                tabData = [];
                var DeviceFWStatus = [];
                  if( typeof info[key] === 'object' && info[key].result != undefined ){
                  var verRow = Object.keys(info[key].result).map(function (key2) {//device    
                           
                    return <TableRow><td>{key2}</td>
                      <td>{info[key].result[key2]}</td></TableRow>
                  });
                  if (verRow.length != 0) 
                  { DeviceFWStatus = DeviceFWStatus.concat(verRow) }
                  else{
                  var status =(<td>"Device details are not available to display"</td>);
                  DeviceFWStatus = status;}
                  //Filter for all undefined percentage value and set it to zero
                  if (info[key].percentage != undefined) { percent = info[key].percentage; } else { percent = 0; }
                  var statusvalue;
                  if(info[key].task_state=='SUCCESS')
                  statusvalue=(<Status size='small' value='ok'></Status>);
                  else if(info[key].task_state=='ERROR')
                  statusvalue=(<Status size='small' value='critical'></Status>);
                  else if(info[key].task_state=='RUNNING')
                      statusvalue=(<Spinning size='small' />);
                  else
                  statusvalue=(<Status size='small' value='unknown'></Status>);
                  return <TableRow>
                    <td>{key}</td>
                    <td><Meter size='xsmall' value={percent} colorIndex={"brand"} /><Value value={percent + '%'} size='xsmall' align='start' /></td>
                    <td>{statusvalue}</td>
                    <td>{DeviceFWStatus}</td>
                  </TableRow>
                }
              });
              if (tab != undefined) { tabData = tabData.concat(tab) };
              var acc = <Accordion  openMulti={true}>
                <AccordionPanel heading={header}>
                  <Table selectable={true}>
                      <tr>
                        <th><strong>Server IP</strong></th>
                        <th><strong>Percentage completed</strong></th>
                        <th><strong>State</strong></th>
                        <th><strong> Types of server firmware  and it's update status </strong></th>
                      </tr>
                    <tbody>
                      {tabData}
                    </tbody>
                  </Table>
                </AccordionPanel>
              </Accordion>
              if (tabData.length != 0) { accordion = accordion.concat(acc) }          
          
        } else if (statusinfo[i].type == "dry_run_task_manager" || statusinfo[i].type == "DryRun") {
          var info = statusinfo[i].result;
          var percentage = 'N/A'
          if(statusinfo[i].percentage != undefined){
           percentage = statusinfo[i].percentage;
          }
          var header = ("Dry run is " + percentage + '%' + " completed, with the status reported as " + statusinfo[i].state);
          var tab = Object.keys(info).map(function (key) {
            tabData = [];
            if (typeof info[key] === 'object') {
              if (info[key].hasOwnProperty('error')) {
                return <TableRow>
                  <td>{key}</td>
                  <td><Status size='small' value='critical'></Status></td>
                  <td>{info[key].error}</td>
                </TableRow>
              } else {
                var deviceFW = [];
                if(info[key].result != undefined){
                var verRow = Object.keys(info[key].result).map(function (key2) {//device                  
                  return <TableRow>
                    <td>{key2}</td>
                    <td>{info[key].result[key2].installed}</td>
                    <td>{info[key].result[key2].to_be_installed}</td>
                    <td>{info[key].result[key2].is_update_require ? 'true' : 'false'}</td></TableRow>
                });
                if (verRow.length != 0) { deviceFW = deviceFW.concat(verRow) }
              }
                else { deviceFW = '* Device details are not available to display *' };
                var statusvalue;
                if (info[key].task_state == 'SUCCESS')
                  statusvalue = (<Status size='small' value='ok'></Status>);
                else if (info[key].task_state == 'ERROR')
                  statusvalue = (<Status size='small' value='critical'></Status>);
                else if (info[key].task_state == 'RUNNING')
                  statusvalue = (<Spinning size='small' />);
                else
                  statusvalue = (<Status size='small' value='unknown'></Status>);
                return <TableRow>
                  <td>{key}</td>
                  <td>{statusvalue}</td>
                  <td>
                      <td><strong>Device</strong></td>
                      <td><strong>Installed version </strong></td>
                      <td><strong>Available version</strong></td>
                      <td><strong>Update required</strong></td>
                    {deviceFW}
                  </td>
                </TableRow>
              }
            }
          });
          if (tab != undefined) { tabData = tabData.concat(tab) };
          var acc = <Accordion openMulti={true}>
            <AccordionPanel heading={header}>
              <Table selectable={true}>
                  <tr>
                    <th><strong>Server IP</strong></th>
                    <th><strong>State</strong></th>
                    <th><strong>Firmware version details</strong></th>
                  </tr>
                <tbody>
                  {tabData}
                </tbody>
              </Table>
            </AccordionPanel>
          </Accordion>
          if (tabData.length != 0) { accordion = accordion.concat(acc) }
        }
      }
    }
    return accordion;
  }


  render() {
    const { FWIDInfo } = this.props;
    var tableinfo = this._getData(); //Fetch User Table data
    return (
      <Section>
          {tableinfo}
      </Section>
    );
  }
};

const select = state => ({ ...state.FWStatus });

export default connect(select)(FWStatus);
