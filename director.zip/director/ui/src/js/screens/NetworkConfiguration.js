// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import DocsArticle from './DocsArticle';
import Tab from 'grommet/components/Tab';
import Tabs from 'grommet/components/Tabs';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Paragraph from 'grommet/components/Paragraph';
import Article from 'grommet/components/Article';
import FormFields from 'grommet/components/FormFields';
import Label from 'grommet/components/Label';
import Layer from 'grommet/components/Layer';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import RadioButton from 'grommet/components/RadioButton';
import Notification from 'grommet/components/Notification';
import Spinning from 'grommet/components/icons/Spinning';
import NTPSettings from './NTPSettings';
import { loadNetwork, changeNetworkSettings, unloadNetwork } from '../actions/network';
import { ResetEIMConfig } from '../actions/resetEIM';
import { pageLoaded } from './utils';

FormField.displayName = 'FormField';
Form.displayName = 'Form';

class NetworkConfiguration extends Component {

  constructor () {
    super();
    this._onChange = this._onChange.bind(this);
    this._onChange1 = this._onChange1.bind(this);
    this._onChange2 = this._onChange2.bind(this);
    this._onApply = this._onApply.bind(this);
    this._onReset = this._onReset.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._onResetEIM = this._onResetEIM.bind(this);
    this._validateInput = this._validateInput.bind(this);
    this._layerClose = this._layerClose.bind(this);
    this._clearNotifications = this._clearNotifications.bind(this);
    this.state = {
      hostname: undefined,
      dns1: undefined,
      dns2: undefined,
      gateway: undefined,
      ipAddr: undefined,
      ipv6Addr: undefined,
      netmask: undefined,
      manualIpv4: undefined,
      manualIpv6: undefined,
      errors: {
        "ipAddr": "",
        "netmask": "",
        "gateway": "",
        "dns1": "",
        "dns2": "",
        "ipv6Addr": ""
      },
      pageDisabled: true,
      ipv4Disabled: true,
      ipv6Disabled: true,
      isValid: undefined,
      applyLayerOpen: undefined,
      resetLayerOpen: undefined,
      showNotification: false
    };
    this.warningNotification = undefined;
    this.errNotification = undefined;
    this.ipAddr = undefined;
    this.netmask = undefined;
    this.gateway = undefined;
    this.ipv6Addr = undefined;
  }

  _validateInput(event) {
    let err = {};
    var errMsg;
    var value = event.target.value;
    switch(event.target.accept) {
      case "ip":
        if (value != "0.0.0.0"){
          this.state.isValid = value.match(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid IP address";
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      case "netmask":
        this.state.isValid = value.match(/^(255.255.255.(25[542]|24[80]|224|192|128|0)|255.255.(25[42]|24[80]|224|192|128|0).0|255.(25[42]|24[80]|224|192|128|0).0.0|(25[42]|24[80]|224|192|128|0).0.0.0)$/);
        errMsg = (this.state.isValid) ? "" : "enter a valid subnet mask";
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      case "ipv6":
        this.state.isValid = value.match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$|^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/)
        errMsg = (this.state.isValid) ? "" : "enter a valid IPv6 address";
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      default:
        break;
    }
  };

  _onChange (event) {
    this.setState({ [event.target.name]: event.target.value });
    this._validateInput(event);
  }

  _onChange1 (event) {
    this.setState({
      [event[0]]: event[1],
      ipAddr: this.ipAddr,
      gateway: this.gateway,
      netmask: this.netmask,
    })
    this.state.errors["ipAddr"] = "";
    this.state.errors["gateway"] = "";
    this.state.errors["netmask"] = "";
  }

  _onChange2 (event) {
    this.setState({
      [event[0]]: event[1],
      ipv6Addr: this.ipv6Addr
    });
    this.state.errors["ipv6Addr"] = "";
  }

  componentDidMount() {
    pageLoaded("Network Configuration");
    this.props.dispatch(loadNetwork());
    this.setState({ showNotification: true });
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch(unloadNetwork());
  }

  _onApply() {
    this.warningNotification = undefined;
    this.errNotification = undefined;
    var reqErr = "required";
    let err = Object.assign({}, this.state.errors);
    this.state.isValid = undefined;

    if (this.state.manualIpv4 == "static") {
      if (ipAddr.value == "") {
        err["ipAddr"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
      if (netmask.value == "") {
        err["netmask"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
      if (gateway.value == "") {
        err["gateway"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
    } else {
      this.state.isValid = true;
    }

    if (this.state.manualIpv6 == "yes") {
      if(ipv6Addr.value == "") {
        err["ipv6Addr"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
    } else {
      this.state.isValid = true;
    }

    if ((this.state.errors["ipAddr"] != "") || (this.state.errors["netmask"] != "") || (this.state.errors["gateway"] != "")
    || (this.state.errors["dns1"] != "") || (this.state.errors["dns2"] != "" || this.state.errors["ipv6Addr"] != "" || this.state.isValid == false)) {
      return false;
    }
    this.setState({ applyLayerOpen: true });
  }

  _onReset() {
    this.setState({ resetLayerOpen: true});
  }

  _onResetEIM() {
    this.setState({ resetLayerOpen: false});
    this._clearNotifications();
    var resetData = {"restart_required":"True"};
	window.localStorage.timeoutRebootMsg = "Reboot is in progress. Please wait...";
    this.props.dispatch(ResetEIMConfig(resetData));
    setTimeout(function() {
       window.location.href = '/Login';
      }, 5000);
  }

  _clearNotifications() {
    this.warningNotification = undefined;
    this.errNotification = undefined;
  }

  _onSubmit() {
    this.setState({ applyLayerOpen: false });
    let patchdata = {
      "HOSTNAME": this.state.hostname,
      "DNS1": this.state.dns1,
      "DNS2": this.state.dns2,
      "GATEWAY": this.state.gateway,
      "IPADDR": this.state.ipAddr,
      "IPV6ADDR": this.state.ipv6Addr,
      "NETMASK":this.state.netmask,
      "dhcpv4": (this.state.manualIpv4 == "dhcp") ? "yes" : "no",
      "dhcpv6": (this.state.manualIpv6 == "yes") ? "no" : "yes",
      "manual_ipv4": (this.state.manualIpv4 == "dhcp") ? "no" : "yes",
      "manual_ipv6": this.state.manualIpv6
    };
    this.props.dispatch(changeNetworkSettings(patchdata));
    this.setState({ showNotification: true });
  }

  _layerClose(event) {
    this.setState({ [event]: false });
  }

  render () {
    var message = undefined;
    var errMessage = this.props.sessionError;
    let applyLayer = null;
    if(this.state.hostname === undefined && this.props.hostname != undefined){
      this.state.hostname = this.props.hostname;
      this.state.dns1 = this.props.dns1;
      this.state.dns2 = this.props.dns2;
      this.state.gateway = this.gateway = this.props.gateway;
      this.state.ipAddr = this.ipAddr = this.props.ipAddr;
      this.state.ipv6Addr = this.ipv6Addr = this.props.ipv6Addr;
      this.state.netmask = this.netmask = this.props.netmask;
      this.state.manualIpv4 = this.props.bootProto;
      this.state.manualIpv6 = this.props.manualIpv6;
      this.state.pageDisabled = false;
    }

    if(this.state.manualIpv4 === "static") {
      this.state.ipv4Disabled = false;
    } else {
      this.state.ipv4Disabled = true;
    }

    if (this.state.manualIpv6 === "yes") {
      this.state.ipv6Disabled = false;
    } else {
      this.state.ipv6Disabled = true;
    }

    if (this.props.networkSettingsUpdated == "True" && this.props.restartRequired == "True") {
      message = "Network settings are saved. Please reboot the system to reflect the applied changes";
    }

    {(message != undefined) ? (
      this.warningNotification=(
        <Notification onClose={this._onCloseMsg} pad="medium" status='unknown' size='medium' closer='true'
        message={message}/>
      )
    ) : ("")};
    {(errMessage != undefined) ? (
      this.state.error = true,
      this.errNotification=(
        <Notification onClose={this._onCloseMsg} pad="medium" status='critical' size='medium' closer='true'
        message={errMessage}/>
      )
    ) : ("")};

    if (this.state.applyLayerOpen == true) {
      applyLayer = <Layer align="right" closer={true} onClose={this._layerClose.bind(this, "applyLayerOpen")} overlayClose={true}>
      <Article align='start' >
      <Form submitLabel="Apply" onSubmit={this._onSubmit}>
      <Header><Heading tag='h2'>Apply settings</Heading></Header>
      <Paragraph>Applying new settings requires a reboot. Please obtain the new IP from console.</Paragraph>
      <Paragraph>Are you sure you want to apply settings?</Paragraph>
      <Button label='Yes, Apply' type='submit' primary={true} onClick={this._onSubmit} />
    </Form>
    </Article>
    </Layer>
    }

    if (this.state.resetLayerOpen == true) {
      applyLayer = <Layer align="right" closer={true} onClose={this._layerClose.bind(this, "resetLayerOpen")} overlayClose={true}>
      <Article align='start' >
      <Form submitLabel="Apply" onSubmit={this._onSubmit}>
      <Header><Heading tag='h2'>Reset EIM</Heading></Header>
      <Paragraph>Resetting EIM might change the IP. Please obtain the new IP from console.</Paragraph>
      <Paragraph>Are you sure you want to reset EIM?</Paragraph>
      <Button label='Yes, Reset' type='submit' primary={true} onClick={this._onResetEIM} />
    </Form>
    </Article>
    </Layer>
    }

    return (

      <DocsArticle title='Network Configuration'>
      <Tabs justify='start'>
      <Tab title='Network Configuration'>
      {this.warningNotification}
      {this.errNotification}
      {this.state.hostname == undefined && this.state.error == undefined ? (
            <Box justify='center'
            align='center'
            wrap={true}
            pad='none'
            margin='none'
            colorIndex='light-1'>
              <Spinning size='small' /><Label size='medium'>Loading please wait ...</Label>
            </Box>
          ) : ("")}
        <Form>
            <Header>
              <Heading tag='h3'><strong>General</strong></Heading>
            </Header>

            <FormFields>
                <FormField label='Application hostname' htmlFor='hostname' error={this.state.errors["hostname"]}>
                  <input disabled={this.state.pageDisabled} id='hostname' name='hostname' accept="string" required={true}
                  type='text' value={this.state.hostname} onChange={this._onChange}  />
                </FormField>
            </FormFields>

            <Header>
              <Heading tag='h3'><strong>IPv4</strong></Heading>
            </Header>

            <FormFields>
                <FormField label='Address assignment' htmlFor='input-id'>
                  <RadioButton
                  disabled={this.state.pageDisabled}
                  id='ipv4_manual'
                  name='Manual_IPv4'
                  label='Manual'
                  checked={"static"===this.state.manualIpv4}
                  onChange={this._onChange1.bind(this, ["manualIpv4", "static"])}
                  />
                  <RadioButton
                  disabled={this.state.pageDisabled}
                  id='ipv4_dhcp'
                  name='DHCPv4'
                  label='DHCPv4'
                  checked={"dhcp"===this.state.manualIpv4}
                  onChange={this._onChange1.bind(this, ["manualIpv4", "dhcp"])}
                  />
                </FormField>
                <FormField label='IP address' error={this.state.errors["ipAddr"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv4Disabled} id='ipAddr' name='ipAddr' type='text' accept="ip" required={false} value={this.state.ipAddr}
                     onChange={this._onChange} />
                </FormField>
                <FormField label='Subnet mask or CIDR' error={this.state.errors["netmask"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv4Disabled} id='netmask' name='netmask' type='text' accept="netmask" required={false} value={this.state.netmask}
                     onChange={this._onChange} />
                </FormField>
                <FormField label='Gateway address' error={this.state.errors["gateway"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv4Disabled} id='gateway' name='gateway' type='text' accept="ip" required={false} value={this.state.gateway}
                     onChange={this._onChange} />
                </FormField>
            </FormFields>

            <Header>
              <Heading tag='h3'><strong>DNS</strong></Heading>
            </Header>

            <FormFields>
                <FormField label='Preferred DNS server' error={this.state.errors["dns1"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv4Disabled} id='dns1' name='dns1' type='text' accept="" isRequired={false} error="" value={this.state.dns1}
                     onChange={this._onChange} />
                </FormField>
                <FormField label='Alternate DNS server' error={this.state.errors["dns2"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv4Disabled} id='dns2' name='dns2' type='text' accept="" isRequired={false} error="" value={this.state.dns2}
                     onChange={this._onChange} />
                </FormField>
            </FormFields>

            <Header>
              <Heading tag='h3'><strong>IPv6</strong></Heading>
            </Header>
            <FormFields>
                <FormField label='Address assignment' >
                  <RadioButton
                  disabled={this.state.pageDisabled}
                  id='ipv6_manual'
                  name='Manual_IPv6'
                  label='Manual'
                  checked={"yes" == this.state.manualIpv6}
                  onChange={this._onChange2.bind(this, ["manualIpv6", "yes"])}
                  />
                  <RadioButton
                  disabled={this.state.pageDisabled}
                  id='ipv6_dhcp'
                  name='DHCPv6'
                  label='DHCPv6'
                  checked={"no" == this.state.manualIpv6}
                  onChange={this._onChange2.bind(this, ["manualIpv6", "no"])}
                  />
                </FormField>
                <FormField label='IPv6 address' error={this.state.errors["ipv6Addr"]}>
                  <input disabled={this.state.pageDisabled || this.state.ipv6Disabled} id='ipv6Addr' name='ipv6Addr' type='text' accept="ipv6" isRequired={false} value={this.state.ipv6Addr}
                     onChange={this._onChange} />
                </FormField>
            </FormFields>

            <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
              <Button disabled={this.state.pageDisabled} label='Reset EIM' href='#' type='reset' onClick={this._onReset} />
              <Box pad={{horizontal: 'small',vertical:'none'}}>
                <Button disabled={this.state.pageDisabled} label='Apply' primary={true} onClick={this._onApply} />
              </Box>
            </Box>
        </Form>
      </Tab>
      <Tab title='NTP Servers Settings'>
        <NTPSettings />
      </Tab>
      </Tabs>
      {applyLayer}

    </DocsArticle>

    );
  }
};

NetworkConfiguration.propTypes = {
  onClose: PropTypes.func,
};



const select = state => ({ ...state.networkInfo });

export default connect(select)(NetworkConfiguration);