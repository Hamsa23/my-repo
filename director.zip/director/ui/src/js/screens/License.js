// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import DocsArticle from './DocsArticle';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Label from 'grommet/components/Label';
import Table from 'grommet/components/Table';
import Layer from 'grommet/components/Layer';
import Article from 'grommet/components/Article';
import Paragraph from 'grommet/components/Paragraph';
import Section from 'grommet/components/Section';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import Notification from 'grommet/components/Notification';
import CheckBox from 'grommet/components/CheckBox';
import {LoadLicense, UploadLicense, DeleteLicense, UnloadLicense, LoadSysUuid} from '../actions/license';
import TableRow from 'grommet/components/TableRow';


class License extends Component {

 constructor () {
    super();
    this._uploadLicense = this._uploadLicense.bind(this);
    this._getFileExtension = this._getFileExtension.bind(this);
    this._getLicenseData = this._getLicenseData.bind(this);
    this._deleteLicense = this._deleteLicense.bind(this);
    this._closeNotification = this._closeNotification.bind(this);
    this._onDeleteLicense = this._onDeleteLicense.bind(this);
    this._onSelectLicense = this._onSelectLicense.bind(this);
    this._onSelectAll = this._onSelectAll.bind(this);

    this.state = {
        successMsg: false,
        errMsg: false,
        uploadErr: undefined,
        showNotification: false,
        delLicenseLayerOpen: false,
        hasLicense: undefined,
        delErr: undefined,
        consoleLogin: false,
        SelectionId: undefined,
        selectAll: false,
        selectAllused: false,
        notSelected : undefined
    };
    this.licenseData = undefined;

}

componentDidMount() {
    this.props.dispatch(LoadSysUuid());
    this.props.dispatch(LoadLicense());
}

componentWillReceiveProps(nextProps) {
    this.data = nextProps.licenseResp;
    if (nextProps.licenseResp != undefined) {
        this.setState({
            successMsg: true,
            errMsg: false,
            showNotification: true });
    } else if (nextProps.licenseErr != undefined) {
        this.setState({ 
            errMsg: true,
            successMsg: false,
            showNotification: true
        })
    }
}

componentWillUnmount() {
    this.props.dispatch(UnloadLicense());
}

_getFileExtension(filename)
{
    var ext = /^.+\.([^.]+)$/.exec(filename);
    return ext == null ? "" : ext[1];
}

_getLicenseData() {
    var IsAllSelected = this.state.selectAll;
    var licensetabInfo;
    var licensedata = this.props.licenselist;
    if ( licensedata!= undefined && licensedata.length != 0) {
        licensetabInfo = this.props.licenselist.map((LicenseInfo) =>
        <TableRow>
            <td>{this.state.selectAllused ? (<CheckBox  id={LicenseInfo.licenseId} onChange={this._onSelectLicense.bind(this, LicenseInfo.licenseId)}  checked={IsAllSelected}/>) : (<CheckBox  id={LicenseInfo.licenseId} onChange={this._onSelectLicense.bind(this, LicenseInfo.licenseId)}/>)}</td>
            <td>{LicenseInfo.deviceID}</td>
            <td>{LicenseInfo.startDate}</td>
            <td>{LicenseInfo.expirationDate}</td>
            <td>{LicenseInfo.availableCapacity}</td>
            <td>{LicenseInfo.licenseId}</td>
        </TableRow>
    );
        this.state.hasLicense = true;
        this.state.delErr = undefined;
    } else {
        licensetabInfo = <TableRow>
            <td></td><td>No license installed</td><td></td><td></td><td></td><td></td>
        </TableRow>
        this.state.hasLicense = false;
    }
    return licensetabInfo;
}

_uploadLicense() {
    let licenseFile = this.refs.license_file.files[0];
    if (licenseFile == undefined) {
        this.setState({ license_err: "license required" });
    }
    if (this.state.license_err != undefined || licenseFile == undefined) {
        return false;
    } else {
        let licenseFile = this.refs.license_file.files[0];
        this.props.dispatch(UploadLicense(licenseFile));
    }
}

_deleteLicense() {
    if( this.state.SelectionId == undefined && this.state.selectAll == false) {
        this.setState({ notSelected: "Select one or more Licenses to delete",  delLicenseLayerOpen: false, showNotification: true});
    }
    else if (this.state.hasLicense == true) {
        this.setState({
            delLicenseLayerOpen: true,
            showNotification: false
        });
    } else {
        this.setState({ delErr: "No license to delete" });
    }
}

_onSelectLicense (selectid, e) {
    let id = selectid;
    if(e.target.checked) {
        this.setState({ SelectionId: id, selectAllused: false });
    }
    else {
        this.setState({ SelectionId: undefined, selectAllused: false });
    }
}

_onSelectAll(e) {
    this.setState({ selectAllused: true });
    if (e.target.checked) {
        this.setState({selectAll: true});
    } else {
            this.setState({selectAll: false});
    }
}

_onDeleteLicense() {
    let license_id;
    if(this.state.selectAll == true) {
        license_id = undefined;
    }
    else {
        license_id = this.state.SelectionId;
    }
    this.setState({ delLicenseLayerOpen: false });
    this.props.dispatch(DeleteLicense(license_id));
}

_closeDelLayer(event) {
    this.setState({ delLicenseLayerOpen: event });
}

_closeNotification() {
    this.setState({ showNotification: false })
}

render () {
    var deleteLayer = undefined;
    let notification = "";
    let consoleMessage = undefined;
    var tableData = this._getLicenseData();
    this.state.sysUuid = "Licensing System UUID: " + this.props.sysUuid;

    if(window.location.host == '127.0.0.1'){
        this.state.consoleLogin = true;
        consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
    }

    if (this.state.showNotification == true) {
        if (this.state.successMsg == true) {
            notification =
            <Notification onClose={this._closeNotification} pad='medium' size='medium'
            closer='true' status='ok'
            message={this.props.licenseResp} />
        } else if (this.state.errMsg == true) {
            notification =
            <Notification onClose={this._closeNotification} pad='medium' size='medium'
            closer='true' status='critical'
            message={this.props.licenseErr} />
        }
    }
    if (this.state.delLicenseLayerOpen == true) {
        deleteLayer = <Layer align="right" closer={true} onClose={this._closeDelLayer.bind(this, false)} overlayClose={true}>
        <Article align='start' >
        <Form>
        <Header><Heading tag='h2'>Delete License</Heading></Header>
        {this.state.selectAll != false  ? (<Paragraph>Are you sure you want to delete all licenses?</Paragraph>) : (<Paragraph>Are you sure you want to delete license with LicenseID {this.state.SelectionId}?</Paragraph>)}
        <Button label='Yes, Delete' type='submit' primary={true} onClick={this._onDeleteLicense} />
        </Form>
      </Article>
      </Layer>
    }

    return (
      <DocsArticle title='Licensing'>
        <Box>
            <Box><Paragraph><strong>{this.state.sysUuid}</strong></Paragraph></Box>
            <Box pad={{ vertical: 'small', between:'small'}}>
                {consoleMessage}
                {notification}
            </Box>
            <Form>
                <FormField label='License Upload' htmlFor='input-id'  error={this.state.license_err}>
                  <input disabled={this.state.consoleLogin} type="file" id="license_file" name="license_file" key='license_file' ref="license_file" />
                </FormField>
                <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                  <Button label='Upload' primary={true} onClick={(this.state.consoleLogin) ? null : this._uploadLicense}/>
                </Box>
            </Form>
            <Section>
                <Heading tag='h3'><strong>Current Licenses</strong></Heading>
                <Table>
                    <thead>
                    <tr>
                        <th><CheckBox disabled={!this.state.hasLicense} checked={this.state.selectAll} onChange={this._onSelectAll}/></th>
                        <th><strong>Device ID</strong></th>
                        <th><strong>License Start Date</strong></th>
                        <th><strong>Expiration Date</strong></th>
                        <th><strong>Available Capacity</strong></th>
                        <th><strong>License ID</strong></th>
                    </tr>
                    </thead>
                    <tbody>
                        {tableData}
                    </tbody>
                </Table>
                {this.state.delErr != undefined ? (<Paragraph>{this.state.delErr}</Paragraph>) : (<Paragraph>{this.state.notSelected}</Paragraph>)}
                <Box direction='row' pad={{vertical: 'none'}}>
                    <Button label='Delete' primary={true} onClick={this._deleteLicense}/>
                </Box>
            </Section>
        </Box>
        {deleteLayer}
      </DocsArticle>
    );
  }
};

const select = state => ({ ...state.licenseInfo });

export default connect(select)(License);


