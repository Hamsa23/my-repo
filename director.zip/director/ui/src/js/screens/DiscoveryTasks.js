// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Button from 'grommet/components/Button';
import Article from 'grommet/components/Article';
import Label from 'grommet/components/Label';
import Paragraph from 'grommet/components/Paragraph';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import Section from 'grommet/components/Section';
import CheckBox from 'grommet/components/CheckBox';
import Layer from 'grommet/components/Layer';
import Box from 'grommet/components/Box';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Spinning from 'grommet/components/icons/Spinning';
import {loadDiscoveryTasks, deleteTasks, unloadTasks} from '../actions/discoveryTasks';
import Notification from 'grommet/components/Notification';


//Update Document Title
FormField.displayName = 'FormField';
Form.displayName = 'Form';

 class DiscoveryTasks extends Component {
    constructor () {
        super();
        this._getData = this._getData.bind(this);
        this._onClickDelete = this._onClickDelete.bind(this);
        this._delLayerOpen = this._delLayerOpen.bind(this);
        this._onDelete = this._onDelete.bind(this);
        this._onSelect = this._onSelect.bind(this);
        this._onSelectAll = this._onSelectAll.bind(this);
        this._closeNotification = this._closeNotification.bind(this);
        this.state = {
            selectedTasks: [],
            selectAll: undefined,
            delTaskLayerOpen: false,
            showNotification: false,
            showDelNotification: false,
            refreshInterval: undefined,
            data:undefined,
            sessionErr: undefined,
            taskErr: undefined,
            disableSelectAll: true,
            pageLoading: true,
            delProcessing: false
        };
        this.delResponse = undefined
    }

    componentDidMount() {
        this.props.dispatch(loadDiscoveryTasks());
        
        //reload the page with a time interval of 10 secs
        var interval = setInterval( () => {
        this.props.dispatch(loadDiscoveryTasks())}, 10000);
        this.setState({refreshInterval: interval}); 
    }

    // If redirecting to some other page stop Backend calls
    componentWillUnmount() {
        clearInterval(this.state.refreshInterval);
        this.props.dispatch(unloadTasks());
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.discoveryTasks
        })
        if (nextProps.discoveryTasks != undefined) {
            this.setState({
                pageLoading: false,
                showNotification: false,
            });
        } else if (nextProps.discoveryTasksErr != undefined) {
            this.setState({
                pageLoading: false,
                showNotification: true
            })
        }
        if (nextProps.delTaskResp != undefined || nextProps.delTaskErr != undefined) {
            this.setState({
                delProcessing: false
            });
        }
    }

    //load the table data
    _getData() {
        var me = this;
        var tasks = [];
        var tasksData = this.state.data;
        var tableData = [];
        if (tasksData != undefined) {
        tableData = Object.keys(tasksData).map(function (key) {
            tasks = Object.assign({}, me.state.selectedTasks);
            if (tasks[tasksData[key].URI] == undefined) {
                tasks[tasksData[key].URI] = false;
            }
            var ip = (tasksData[key].IP).split("/");
            me.state.selectedTasks = tasks;
            var user = (tasksData[key].UserName).replace(/["]/g, ""); //Remove extra tailing quotes in username
            return <TableRow>
                <td><CheckBox id={tasksData[key].URI} checked={me.state.selectedTasks[tasksData[key].URI]} onChange={me._onSelect} />
                    {ip[0]}</td>
                <td>{ip[1]}</td>
                <td>{tasksData[key].Frequency}</td>
                <td>{user}</td>
            </TableRow>
        });
        }
        if (tableData.length == 0) {
            this.state.disableSelectAll = true;
            this.state.selectAll = false;
        } else {
            this.state.disableSelectAll = false;
        }
        return tableData;
    }

    //on select/deselect task
    _onSelect(e) {
        const item = e.target.id;
        const isChecked = e.target.checked;
        var tasks = Object.assign({}, this.state.selectedTasks);
        tasks[item] = isChecked;
        this.setState({
            selectedTasks: tasks,
            selectAll: false
        });
    }

    //on select/deselect all tasks
    _onSelectAll(e) {
        var tasks = Object.assign({}, this.state.selectedTasks);
        if (e.target.checked) {
            Object.keys(tasks).map(function (key) {
                tasks[key] = true;
            });
        } else {
            Object.keys(tasks).map(function (key) {
                tasks[key] = false;
            });
        }
        // this.state.selectedTasks = tasks;
        this.setState({
            selectedTasks: tasks,
            selectAll: e.target.checked
        });
    }

    _onClickDelete() {
        var me = this;
        var hasSelectedTasks = false;
        var tasks = Object.assign({}, this.state.selectedTasks);
        Object.keys(tasks).map(function (key) {
            if (tasks[key] == true) {
                hasSelectedTasks = true;
            }
        })
        if (hasSelectedTasks == true) {
            this._delLayerOpen(true);
            this.setState({
                taskErr: "",
                showNotification: false
            });
        } else {
            this.setState({ taskErr: "Select one or more tasks to delete" });
        }
    }

    _delLayerOpen(e) {
        this.setState({
            delTaskLayerOpen: e
        });
    }

    //delete selected tasks
    _onDelete() {
        var me = this;
        var delTasks = this.state.selectedTasks;
        this.setState({
            delTaskLayerOpen: false,
            delProcessing: true,
            showDelNotification: true,
            selectedTasks: []
        });
        if (deleteTasks != undefined) {
            Object.keys(delTasks).map(function (key) {
                if (delTasks[key] == true) {
                    me.props.dispatch(deleteTasks(key));
                }
            });
        }
    }

    _closeNotification(event) {
        this.setState({ [event]: false })
    }

    render () {
        var deleteLayer = undefined;
        let notification = "";
        if (this.state.showNotification == true && this.state.pageLoading == false) {
            if(this.state.pageLoading == false) {
                if (this.props.discoveryTasksErr != undefined) {
                    notification =
                        <Notification onClose={this._closeNotification.bind(this, 'showNotification')} pad='medium' size='medium'
                            closer='true' status='critical'
                            message={this.props.discoveryTasksErr} />
                }
            }
        }
        if (this.state.showDelNotification == true && this.state.delProcessing == false) {
            if(this.state.delProcessing == false) {
                if (this.props.delTaskResp != undefined && this.props.delTaskResp.Task == "Deleted") {
                    notification =
                        <Notification onClose={this._closeNotification.bind(this, 'showDelNotification')} pad='medium' size='medium'
                            closer='true' status='ok'
                            message='Discovery task(s) deleted successfully' />
                } else if (this.props.delTaskErr != undefined) {
                    notification =
                        <Notification onClose={this._closeNotification.bind(this, 'showDelNotification')} pad='medium' size='medium'
                            closer='true' status='critical'
                            message={this.props.delTaskErr} />
                }
            }
        }
        if (this.state.delTaskLayerOpen == true) {
            deleteLayer = <Layer align="right" closer={true} onClose={this._delLayerOpen.bind(this, false)} overlayClose={true}>
                <Article align='start' >
                    <Form>
                        <Header><Heading tag='h2'>Delete Tasks</Heading></Header>
                        <Paragraph>Are you sure you want to delete the selected task(s)?</Paragraph>
                        <Button label='Yes, Delete' type='submit' primary={true} onClick={this._onDelete} />
                    </Form>
            </Article>
          </Layer>
        }
        var tableData = this._getData();
        var label = <strong>Select All</strong>;
        return (
            <Section>
                <Box >{notification}</Box>
                {this.state.pageLoading == true ? (
                    <Box justify='center'
                    align='center'
                    wrap={true}
                    pad='none'
                    margin='none'
                    colorIndex='light-1'>
                    <Spinning size='small' /><Label size='medium'>Loading please wait ...</Label>
                    </Box>
                ) : ("")}
                {this.state.delProcessing == true ? (
                    <Box justify='center'
                    align='center'
                    wrap={true}
                    pad='none'
                    margin='none'
                    colorIndex='light-1'>
                    <Spinning size='small' /><Label size='medium'>Processing please wait ...</Label>
                    </Box>
                ) : ("")}
                <Table>
                    <thead>
                        <tr>
                        <th><CheckBox disabled={this.state.disableSelectAll} checked={this.state.selectAll} onChange={this._onSelectAll} ></CheckBox>
                            <strong>IP Address</strong></th>
                        <th><strong>Subnet mask/CIDR</strong></th>
                        <th><strong>Frequency</strong></th>
                        <th><strong>User Name</strong></th>
                        </tr>
                    </thead>
                    <tbody>
                        {tableData}
                    </tbody>
                </Table>
                <Box direction='row' pad={{horizontal: 'small',vertical:'none'}}>
                    <Paragraph>{this.state.taskErr}</Paragraph>
                </Box>
                <Box direction='row' pad={{horizontal: 'small',vertical:'none'}}>
                    <Button label='Delete' primary={true} onClick={this._onClickDelete} />
                </Box>
                {deleteLayer}
            </Section>
          );
        }
      };
      
      const select = state => ({ ...state.discoveryTasksInfo });
      
      export default connect(select)(DiscoveryTasks);
