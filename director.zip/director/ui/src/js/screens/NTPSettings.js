// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import FormFields from 'grommet/components/FormFields';
import Button from 'grommet/components/Button';
import {Ntp} from '../actions/ntpsettings';
import {NtpConf} from '../actions/ntpsettings';
import {ResetEIMConfig} from '../actions/resetEIM';
import Notification from 'grommet/components/Notification';
import Layer from 'grommet/components/Layer';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import Paragraph from 'grommet/components/Paragraph';
import Section from 'grommet/components/Section';
import Select from 'grommet/components/Select';
import { NTPSetting, EIMTime } from './urls';
import { sendRedfishActionRequest } from '../actions/redfishActionUtil';



//Update Document Title
FormField.displayName = 'FormField';
Form.displayName = 'Form';

class NTPSettings extends Component {

  constructor () {
    super();
    this._onChange = this._onChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._Apply = this._Apply.bind(this);
    this._onConfirmationClose = this._onConfirmationClose.bind(this);
    this._onclose = this._onclose.bind(this);
    this._doSearch = this._doSearch.bind(this);
    this._onSearchTZ =this._onSearchTZ.bind(this);
    this._onSubmitTz = this._onSubmitTz.bind(this);
    this.state = {
      ntp1: undefined,
      ntp2: undefined,
      restart_required:false,
      LayerOpen: false,
      errors: {},
      resetLayerOpen:false,
      showNotification: false,
      errorMessage: undefined,
      Primary_required:undefined,
      secondary_required:undefined,
      errorms: undefined,
      availableTz:[],
      searchTz:[],
      currentTz:undefined,
      searchkey:'',
      timezoneselected: undefined
    };

  }

  componentDidMount() {
    this.props.dispatch(Ntp());
  }

  _onConfirmationClose() {
    this.setState({ LayerOpen: false })
  }
  
  componentWillReceiveProps(nextProps) {
    this.setState({ errorms: nextProps.error,
      ntp1: nextProps.ntp1,
      ntp2: nextProps.ntp2,
      availableTz: nextProps.tz,
      searchTz: nextProps.tz
    });
    var data = nextProps.successResponse;
    if(data != undefined){      
      var resetData = { "restart_required": "True" };
      this.props.dispatch(ResetEIMConfig(resetData));
    }
  }
  _onSearchTZ(value){
    this.setState({timezoneselected: value.option });
    this.setState({searchTz: this.state.availableTz });
  }
  _doSearch(event) {
    this.state.searchkey = event.target.value;
    var searchTxt = this.state.searchkey;
    var tzs = this.state.availableTz;
    var resultTz = [];
    Object.keys(tzs).map(function (key) {
      if (searchTxt == '' || (tzs[key].toLowerCase()).indexOf(searchTxt.toLowerCase()) >= 0) {
        resultTz.push(tzs[key]);
      }
    });
    this.setState({searchTz: resultTz });
  }

  _onSubmit() {
    if(this.state.errors["NTP1"]== undefined && this.state.errors["NTP2"]== undefined) {
      this.setState({ LayerOpen: true });
    }
  }
  _onSubmitTz(){
    var new_time_zone = this.state.timezoneselected ;
    const tz = JSON.stringify({ new_time_zone })
    this.props.dispatch(sendRedfishActionRequest( 'PATCH', NTPSetting, tz));
    
  }

  _validateInput(event) {
    let err = {};
    var errMsg;
    var value = event.target.value;
    this.state.isValid = "";
    switch(event.target.accept) {
      case "ntp1":
      case "ntp2":
        if (value != "" ){
          this.state.isValid = value.match(/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.){2,}([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9]){2,}$/);
          errMsg = (this.state.isValid) ? "" : "enter a valid IP address or domain name";
        }
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({errors: err});
        break;
      default:
        break;
    }
  };
  _onChange (event) {
    this.setState({ [event.target.name]: event.target.value });
    this._validateInput(event);
  }

  _onclose() {
    this.setState({ notificatonMessage: false })
  }
  _Apply() {
    let ntpdata =
      {
        "NTP1": this.state.ntp1,
        "NTP2": this.state.ntp2
      };
    this.props.dispatch(NtpConf(ntpdata));
    this.setState({ LayerOpen: false })
    this.setState({ showNotification: true });
  }
  render ()
  {
    const { error } = this.props;
    const { ntpUpdate } = this.props;
    let notification;
    if (this.state.showNotification === true) {
      if (this.props.ntpUpdate != undefined && this.props.ntpUpdate.statusCode != undefined){
        if(this.props.ntpUpdate.statusCode.restart_required != undefined) {//update successfully
          if(this.props.ntpUpdate.statusCode.restart_required == 'True') {//reqired reboot EIM
            //reboot the eim
            this.setState({ showNotification: false });
          } else { //update successfully, rebbot not required
            notification =
              <Notification onClose={this._onClose} pad='medium' size='large' closer='true' status='ok'  message='NTP Server Settings are applied successfully.'/>
            this.setState({ showNotification: false });
          }
        }
        else {//failed to update.
          this.setState({ showNotification: false });
          notification =
            <Notification onClose={this._onClose} pad='medium' size='medium' closer='true' status='critical' message='NTP Server Settings failed to update.' />
        }
      }
    }
    const message = this.props.errorMessage;
    if(this.state.ntp1 === undefined){
      this.state.ntp1 = this.props.ntp1;
      this.state.ntp2 = this.props.ntp2;
      this.state.restart_required = this.props.restart_required;

    }
    let layer;
    if (this.state.LayerOpen) {
      layer =
        (

          <Layer align="right" closer={true}  overlayClose={true}
                 onClose={this._onConfirmationClose} compact={true} >
            <Form submitLabel="Apply NTP settings.">
              <Header><Heading tag='h2'>Apply NTP settings.</Heading></Header>
              <Paragraph>NTP Server settings changes EIM Time setting,  Are you sure you want to apply NTP Server settings?
              </Paragraph>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='Apply' primary={true} onClick={this._Apply} />
              </Box>
            </Form>
          </Layer>
        );
    }
    return (
      <Section>

        <Heading tag='h3' strong={true}>NTP settings </Heading>
        <div> {notification} </div>
        <Form>

          <FormFields>
            <fieldset>
              <FormField label='Primary time server' htmlFor='input-id' error={this.state.errors["NTP1"]}>
                <input id='NTP1' name='ntp1' type='text' required={true} onChange={this._onChange}
                       value={this.state.ntp1} accept="ntp1"
                />
              </FormField>
              <br/>
            </fieldset>

          </FormFields>
          <FormFields>
            <fieldset>
              <FormField label='Secondary time server' htmlFor='input-id'  error={this.state.errors["NTP2"]}>
                <input id='NTP2' name='ntp2' type='text' required={true} onChange={this._onChange}
                       value={this.state.ntp2} accept="ntp2"/>
              </FormField>
            </fieldset>
          </FormFields>
          <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
            <Box pad={{horizontal: 'small',vertical:'none'}}>
              <Button label='Apply' primary={true}
                      onClick={this._onSubmit} />
            </Box>
          </Box>
          <br/>
          <FormFields>
          <fieldset>
              <FormField label='Time zones' htmlFor='input-id'>
              <Select placeHolder='Time zones'  onSearch={this._doSearch} value={this.state.timezoneselected}
              options={this.state.searchTz} onChange={this._onSearchTZ}/>
              </FormField>
            </fieldset>
          </FormFields>
          <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
            <Box pad={{horizontal: 'small',vertical:'none'}}>
              <Button label='Set Timezone' primary={true}
                      onClick={this._onSubmitTz} />
            </Box>
          </Box>
          {layer}
        </Form>
      </Section>
    );
  }
};
const select = state => ({
  ...state.ntpsettings
});
export default connect(select)(NTPSettings);
