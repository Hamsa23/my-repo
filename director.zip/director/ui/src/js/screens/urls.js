// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

export const v1 = 'redfish/v1';
export const systemSummary  = '/eim/v1/ui/dashboard/system_summary';
export const EIMTime  = '/eim/v1/current_time';
export const NTPSetting  = '/eim/v1/NtpConf';
export const DryRun  = '/eim/v1/dry_run';
