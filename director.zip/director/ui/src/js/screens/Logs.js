// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Box from 'grommet/components/Box';
import Tabs from 'grommet/components/Tabs';
import Tab from 'grommet/components/Tab';
import Label from 'grommet/components/Label';
import Section from 'grommet/components/Section';
import Status from 'grommet/components/icons/Status';
import Table from 'grommet/components/Table';
import Select from 'grommet/components/Select';
import Button from 'grommet/components/Button';
import TableRow from 'grommet/components/TableRow';
import Notification from 'grommet/components/Notification';
import Spinning from 'grommet/components/icons/Spinning';
import FormTrashIcon from 'grommet/components/icons/base/FormTrash';
import DocsArticle from './DocsArticle';
import { loadDashboard } from '../actions/dashboard';
import { loadIELData, loadIMLData, del_IELData, del_IMLData } from '../actions/logs';
import Search from 'grommet/components/Search';
import DocumentCsvIcon from 'grommet/components/icons/base/DocumentCsv';


//Update Document Title
FormField.displayName = 'FormField';
Form.displayName = 'Form';

class Logs extends Component {
  constructor() {
    super();
    this._getSelectData = this._getSelectData.bind(this);
    this._onSelect = this._onSelect.bind(this);
    this._onCloseNotification = this._onCloseNotification.bind(this);
    this._onClear = this._onClear.bind(this);
    this._onClickIELTab = this._onClickIELTab.bind(this);
    this._onClickIMLTab = this._onClickIMLTab.bind(this);
    this._closeNotification = this._closeNotification.bind(this);
    this._doSearch = this._doSearch.bind(this);
    this._doSearchIml = this._doSearchIml.bind(this);
    this._onDownload = this._onDownload.bind(this);
    this._getNextPage = this._getNextPage.bind(this);
    
    this.state = {
      selectInfo: [],
      pageLoaded: false,
      clearingLog: false,
      ielLoaded: undefined,
      imlLoaded: undefined,
      error: undefined,
      showNotification: true,
      ielError: undefined,
      imlError: undefined,
      selected: undefined,
      notification: undefined,
      ielNotification: undefined,
      imlNotification: undefined,
      notification1: undefined,
      notification2: undefined,
      showlogNotification: undefined,
      iellogError: undefined,
      imllogError: undefined,
      searchkey: '',
      imlsearchkey: '',
      activeTabIndex: 0,
      consoleLogin: false,
      ielpageNum: undefined,
      imlpageNum: undefined,
      targetServer: undefined,
      ielPageUpdated: false,
      imlPageUpdated: false
    };
    this.data = undefined,
      this.eventItems = [],
      this.imlItems = [],
      this.ielClearData = false,
      this.imlClearData = undefined
  }

  componentDidMount() {
    this.props.dispatch(loadDashboard());
  }

  componentWillReceiveProps(nextProps) {

    this.data = nextProps.dashboardData;

    //IEL Processing
    if (nextProps.eventLogData != undefined) {
      if( nextProps.eventLogData.hasOwnProperty("Items")) {     
        // If Page processing required
        if(nextProps.eventLogData.links.hasOwnProperty("NextPage")) {
          if(this.state.ielpageNum != nextProps.eventLogData.links.NextPage.page) {
            this.setState({ielpageNum: nextProps.eventLogData.links.NextPage.page, ielPageUpdated: true});
            this.eventItems = this.eventItems.concat(nextProps.eventLogData.Items);
          }
          else{
            this.setState({ielPageUpdated: false});
          }
        }
        else {
          this.setState({ielpageNum: undefined});
          this.eventItems = this.eventItems.concat(nextProps.eventLogData.Items);
        }
      }else {
         this.eventItems = [];
        this.eventItems = nextProps.eventLogData.Members;   //EL300
      }    
      this.setState({ ielLoaded: true, clearingLog: false });
    }

    //IML Processing
    if (nextProps.imlData != undefined) {
      if(nextProps.imlData.hasOwnProperty("Items")) {
         // If Page processing required
         if(nextProps.imlData.links.hasOwnProperty("NextPage")) {
          if(this.state.imlpageNum != nextProps.imlData.links.NextPage.page) {
            this.setState({imlpageNum: nextProps.imlData.links.NextPage.page,   imlPageUpdated: true});
            this.imlItems = this.imlItems.concat(nextProps.imlData.Items);
          }
          else{
            this.setState({imlPageUpdated: false});
          }
        }
        else {
          this.setState({imlpageNum: undefined});
          this.imlItems = this.imlItems.concat(nextProps.imlData.Items);
        }
      
      }else {
        this.imlItems = [];
        this.imlItems = nextProps.imlData.Members;
      }
      this.setState({ imlLoaded: true, clearingLog: false });
    }
   
    this.setState({
      error: nextProps.sessionError,
      ielError: nextProps.ielError,
      imlError: nextProps.imlError,
      iellogError: nextProps.iellogError,
      imllogError: nextProps.imllogError
    });
  }

  _getNextPage() {

    if( this.state.ielpageNum != undefined && this.state.ielPageUpdated == true ) {
      this.props.dispatch(loadIELData(this.state.targetServer, this.state.ielpageNum));

    }
    if( this.state.imlpageNum != undefined && this.state.imlPageUpdated == true) {
      this.props.dispatch(loadIMLData(this.state.targetServer, this.state.imlpageNum));
    }
  }

  _getSelectData() {
    var me = this;
    var serverData = [];
    var data = this.data;
    var status = ["OK", "Warning", "Error"];
    var chassis_model = "";
    var isEL300 = false;
    if (data != undefined) {
      Object.keys(data).map(function (status) {
        if (data[status] != undefined) {
          Object.keys(data[status]).map(function (key1) {
            var x = Object.keys(data[status][key1]).map(function (key2) {
              if (typeof (data[status][key1][key2]) == "object") {
                var ip = [data[status][key1][key2].ManagerIP];
                var chassis_id = data[status][key1][key2].ChassisID;
                
                chassis_model = data[status][key1][key2].ChassisModel;
                isEL300 = (chassis_model.includes("EL300")) ? true : false;
                
                var server_id = data[status][key1][key2].SystemID;
                var info = Object.assign({}, me.state.selectInfo);
                info[ip] = 'CH' + chassis_id + 'N' + server_id + ':' +  isEL300;
                me.state.selectInfo = info;
                return ip;
              }
            });
            x = x.filter(function (element) {
              return element !== undefined;
            });
            if (x != undefined) { serverData = serverData.concat(x) };
          });
        }
      });
    }
    if (this.state.pageLoaded != true && serverData[0] != undefined) {
      this.eventItems = [];
      this.imlItems = [];
      this.props.dispatch(loadIELData(this.state.selectInfo[serverData[0]]));
      this.props.dispatch(loadIMLData(this.state.selectInfo[serverData[0]]));
      this.setState({
        targetServer: this.state.selectInfo[serverData[0]],
        selected: serverData[0][0],
        pageLoaded: true,
        ielLoaded: false,
        imlLoaded: false
      });
    }
    return serverData;
  }

  _onSelect(event) {
    this.setState({
      selected: event.value,
      targetServer: this.state.selectInfo[event.value],
      ielLoaded: false,
      imlLoaded: false,
      ielError: undefined,
      imlError: undefined,
      showNotification: true,
      showlogNotification: false,
      searchkey: '',
      imlsearchkey: ''
    });
    this.eventItems = [];
    this.imlItems = [];
    this.props.dispatch(loadIELData(this.state.selectInfo[event.value]));
    this.props.dispatch(loadIMLData(this.state.selectInfo[event.value]));
  }

  //Function for clearing the data in the table
  _onClear() {
    this.setState({
      iellogError: undefined,
      imllogError: undefined
    });
    let selected1 = BTNClear.value;
    var body = {
      "Action": "ClearLog"
    }
    if (this.state.activeTabIndex == 0) {
      this.props.dispatch(del_IELData(this.state.selectInfo[selected1], body));
      this.ielClearData = true;
    } else {
      this.props.dispatch(del_IMLData(this.state.selectInfo[selected1], body));
    }
    this.setState({ showlogNotification: true, clearingLog: true });
  }

  _onClickIELTab() {
    this.setState({ activeTabIndex: 0, searchkey: '', imlError: undefined });
    this.searchkey = '';
  }

  _onClickIMLTab() {
    this.setState({ activeTabIndex: 1, imlsearchkey: '', ielError: undefined });
  }

  _onCloseNotification() {
        this.setState({ showNotification: false });
  }
  _closeNotification() {
    this.setState({ showlogNotification: false });
  }

  _doSearch(event) {
    this.setState({ searchkey: event.target.value });
  }
   
  _doSearchIml(event) {
    this.setState({ imlsearchkey: event.target.value });
  }

  _onDownload() {

    var data = undefined;
    var exportedFilename = undefined;
    if (this.state.activeTabIndex == 0) {
      data = this.eventItems;
      var ip = this.state.selected;
      exportedFilename = ip.concat("_Eventlog.csv");
    } else if (this.state.activeTabIndex == 1) {
      data = "";
      data = this.imlItems;
      var ip = this.state.selected;
      exportedFilename = ip.concat("_Imllog.csv");
    }
    var csv = this._convertToCSV(data);
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = exportedFilename;
    link.click();
  }

  _convertToCSV(Data) {
      let strLog = undefined;
      var header = 'Id';
      header = header.concat(',', 'Severity', ',', 'Description', ',', 'Last Update', '\r\n');
      if (Data != undefined) {
        strLog = Object.keys(Data).map(function (key1) {
          var line = '';
          line = (Data[key1].RecordId != undefined) ? (Data[key1].RecordId.toString()) : (Data[key1].Id.toString());

          var date;
          date = (Data[key1].Oem != undefined) ? (Data[key1].Oem.Hp.Updated) : (Data[key1].Created);
          
          line = line.concat(',', Data[key1].Severity, ',',
            Data[key1].Message, ',', date, '\r\n');
          return line;
        });
      }
      strLog = strLog.join("");
      strLog = header.concat(strLog);
      return strLog;
    }

  render() {
    const { IELLogData } = this.props; //Catch response from reducer
    const { IMLLogData } = this.props; //Catch response from reducer
    this.state.notification1 = '';
    this.state.notification2 = '';
    let consoleMessage = undefined;
    if (this.state.showlogNotification === true) {
      if (this.state.activeTabIndex == 0 && IELLogData != undefined) {
        if(IELLogData.includes("EventLogCleared")) {
          this.state.notification1 = <Notification onClose={this._closeNotification} pad='medium' size='medium' closer='true' status='ok'
            message='IEL Logs cleared successfully' />
        }
      }
      if (this.state.activeTabIndex == 1 && IMLLogData != undefined) {
        if (IMLLogData.includes("EventLogCleared")) {
          this.state.notification1 = <Notification onClose={this._closeNotification} pad='medium' size='medium' closer='true' status='ok'
            message='IML Logs cleared successfully' />
        }

      }

      if (this.state.activeTabIndex == 0) {
        {
          this.state.notification2 = (this.state.iellogError != undefined) ? (this.state.notification1 = '',
            <Notification onClose={this._closeNotification} pad="medium" status='critical' size='medium' closer='true'
              message={this.state.iellogError} />
          ) : ("");
        }
      }
      if (this.state.activeTabIndex == 1) {
        {
          this.state.notification2 = (this.state.imllogError != undefined) ? (this.state.notification1 = '',
            <Notification onClose={this._closeNotification} pad="medium" status='critical' size='medium' closer='true'
              message={this.state.imllogError} />
          ) : ("");
        }
      }
    }
    var selectInfo = this._getSelectData();
    var optionsData = [];
    var ielData, imlData, notification, ielNotification ,imlNotification;
    var searchText = this.state.searchkey;
    var imlsearchText = this.state.imlsearchkey;
    var eventsData = this.eventItems;

    var logsData = this.imlItems;
    Object.keys(selectInfo).map(function (key) {
      optionsData = optionsData.concat(selectInfo[key]);
    });
    if (eventsData != undefined) {
      ielData = Object.keys(eventsData).map(function (key1) {

        var recId;
        recId = (eventsData[key1].RecordId != undefined) ? (eventsData[key1].RecordId) : (eventsData[key1].Id);

        var message = eventsData[key1].Message;

        var date;
        date = (eventsData[key1].Oem != undefined) ? (eventsData[key1].Oem.Hp.Updated) : (eventsData[key1].Created);

        var severity;
        if(eventsData[key1].Severity.toLowerCase() == "info") {
          severity = "ok";
        }
        else if (eventsData[key1].Severity.toLowerCase() == "caution") {
          severity = "warning";
        }
        else {
          severity = eventsData[key1].Severity;
        }
        
        if (searchText == '' ||
          (recId != undefined && recId.toString().indexOf(searchText) >= 0) ||
          (date != undefined && date.indexOf(searchText) >= 0) ||
          (severity != undefined && severity.indexOf(searchText) >= 0) ||
          (message != undefined && (message.toLowerCase()).indexOf(searchText.toLowerCase()) >= 0)) {
          return <TableRow>
            <td>{recId}</td>
            <td><Status size='small' value={severity} /></td>
            <td>{message}</td>
            <td>{date}</td>
          </TableRow>
        }
      });
    }
    if (logsData != undefined) {
      imlData = Object.keys(logsData).map(function (key2) {
        var imlId;
        imlId = (logsData[key2].RecordId != undefined) ? (logsData[key2].RecordId) : (logsData[key2].Id);

        var imlmessage = logsData[key2].Message;

        var imldate;
        imldate = (logsData[key2].Oem != undefined) ? (logsData[key2].Oem.Hp.Updated) : (logsData[key2].Created);

        var imlseverity;
        if(logsData[key2].Severity.toLowerCase() == "info") {
          imlseverity = "unknown";
        }
        else if (logsData[key2].Severity.toLowerCase() == "caution") {
          imlseverity = "warning";
        }
        else{
          imlseverity = logsData[key2].Severity;
        }

        if (imlsearchText == '' ||
          (imlId != undefined && imlId.toString().indexOf(imlsearchText) >= 0) ||
          (imldate != undefined && imldate.indexOf(imlsearchText) >= 0) ||
          (imlseverity != undefined && imlseverity.indexOf(imlsearchText) >= 0) ||
          (imlmessage != undefined && (imlmessage.toLowerCase()).indexOf(imlsearchText.toLowerCase()) >= 0)) {
          return <TableRow>
            <td>{imlId}</td>
            <td><Status size='small' value={imlseverity} /></td>
            <td>{imlmessage}</td>
            <td>{imldate}</td>
          </TableRow>
        }
      });
    }

        if (this.state.showNotification == true) {
            { notification = (this.state.error != undefined) ? (
                    <Notification onClose={this._onCloseNotification} pad="medium" status='critical' size='medium' closer='true'
                    message={this.state.error}/>
                ) : ("");
            }
            { ielNotification = (this.state.ielError != undefined) ? (
                    <Notification onClose={this._onCloseNotification} pad="medium" status='critical' size='medium' closer='true'
                    message={this.state.ielError}/>
                ) : ("");
            }
            { imlNotification = (this.state.imlError != undefined) ? (
                    <Notification onClose={this._onCloseNotification} pad="medium" status='critical' size='medium' closer='true'
                    message={this.state.imlError}/>
                ) : ("");
            }
        }

        if(window.location.host == '127.0.0.1'){
          this.state.consoleLogin = true;
          consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
        }
    return (
      <DocsArticle title="Alerts & Event Logs">
        {notification}
        {this.state.pageLoaded == false && this.state.error == undefined && this.props.dashboardData == undefined ? (
          <Box justify='center'
            align='center'
            wrap={true}
            pad='none'
            margin='none'
            colorIndex='light-1'>
            <Spinning size='small' /><Label size='medium'>Loading please wait ...</Label>
          </Box>
        ) : ("")}

        <Box pad='medium' direction='row'>
          <Box width='950px'>
            <FormField label='Registered Servers'>
              <Select options={optionsData} value={this.state.selected} onChange={this._onSelect} />
            </FormField>
          </Box>
        </Box>
        <Tabs justify='start'>
          <Tab title="iLO/iSM Event Log" onClick={this._onClickIELTab} >
            {consoleMessage}
            <Search placeHolder='Search' size='medium' inline={true} value={this.state.searchkey} onDOMChange={this._doSearch} />

            <Button icon={<FormTrashIcon size='medium' />} id="BTNClear" value={this.state.selected} onClick={this._onClear} />
            <Button icon={<DocumentCsvIcon size='medium' />} onClick={(this.state.consoleLogin) ? null : this._onDownload}/>
            <Section>
              {ielNotification}
              {this.state.notification2}
              {/*display message here*/}
              <div>{this.state.notification1}</div>
              {this.state.clearingLog == true || (this.state.ielLoaded == false && this.state.ielError == undefined) ? (
                <Box justify='center'
                  align='center'
                  wrap={true}
                  pad='none'
                  margin='none'
                  colorIndex='light-1'>
                  <Spinning size='small' /><Label size='medium'>Loading ...</Label>
                </Box>
              ) : (
                  <Table onMore={this._getNextPage()}>
                    <thead>
                      <tr>
                        <th><strong>ID</strong></th>
                        <th><strong>Severity</strong></th>
                        <th><strong>Description</strong></th>
                        <th><strong>Last Updated</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                      {ielData}
                    </tbody>
                  </Table>)}
            </Section>
          </Tab>
          <Tab title="Integrated Management & Health Log" onClick={this._onClickIMLTab} >
            {consoleMessage}
            <Search placeHolder='Search' size='medium' inline={true} value={this.state.imlsearchkey} onDOMChange={this._doSearchIml} />
            <Button icon={<FormTrashIcon size='medium' />} id="BTNClear" value={this.state.selected} onClick={this._onClear} />
            <Button icon={<DocumentCsvIcon size='medium' />} onClick={(this.state.consoleLogin) ? null : this._onDownload}/>
            <Section>
              {imlNotification}
              {this.state.notification2}
              <div>{this.state.notification1}</div>  {/*display message here*/}
              {this.state.clearingLog == true || (this.state.imlLoaded == false && this.state.imlError == undefined) ? (
                <Box justify='center'
                  align='center'
                  wrap={true}
                  pad='none'
                  margin='none'
                  colorIndex='light-1'>
                  <Spinning size='small' /><Label size='medium'>Loading ...</Label>
                </Box>
              ) : (
                  <Table>
                    <thead>
                      <tr>
                        <th><strong>ID</strong></th>
                        <th><strong>Severity</strong></th>
                        <th><strong>Description</strong></th>
                        <th><strong>Last Updated</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                      {imlData}
                    </tbody>
                  </Table>)}
            </Section>

          </Tab>
        </Tabs>
      </DocsArticle>
    );
  }
};


const select = state => ({ ...state.dashboardInfo, ...state.logInfo });

export default connect(select)(Logs);