// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import DocsArticle from './DocsArticle';
import Box from 'grommet/components/Box';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import TableHeader from 'grommet/components/TableHeader';
import Status from 'grommet/components/icons/Status';
import Label from 'grommet/components/Label';
import { loadEventLogs } from '../actions/eventlogs';

//Update Document Title
Label.displayName = 'Appliance Event Logs';

class EventLogs extends Component {
    constructor() {
        super();
        this.state = {
            IP: undefined,
            URI: undefined,
            MessageId: undefined,
            MessageArgs: undefined,
            TimeStamp: undefined
        };
        this._getData = this._getData.bind(this);
    }

    //Before Page load perform actions
    componentWillMount() {
    }

    //After Page load perform actions
    componentDidMount() {
        this.props.dispatch(loadEventLogs());
    }

    //If redirecting to some other page stop Backend calls
    componentWillUnmount() {

    }

    // On load below funtion will populate event log Table Dynamically
    _getData() {
        var eventlogdata = this.props.eventlog;
        if( eventlogdata.length == 0 ) {
            return <TableRow>
                        <td><strong>No Event Log records found.</strong></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </TableRow>
        }
        else {
        var LogTableData = eventlogdata.map((LogInfo) =>
            <TableRow>
                <td>{LogInfo.IP}</td>
                <td>{LogInfo.URI}</td>
                <td>{LogInfo.MessageId}</td>
                <td>{LogInfo.MessageArgs}</td>
                <td>{LogInfo.TimeStamp}</td>
            </TableRow>
        );
          return LogTableData;
        }
    }

    render() {

        const { err } = this.props; //Catch response from reducer
        let notification;
        var tableinfo = this._getData(); //Fetch log Table data

        return (
            <DocsArticle title='Appliance Event Logs'>
                <Box pad='small' flex='left' separator='none'>
                    <Table>
                        <thead>
                            <tr>
                                <th><strong>IP</strong></th>
                                <th><strong>URI</strong></th>
                                <th><strong>Event ID</strong></th>
                                <th><strong>Action</strong></th>
                                <th><strong>Created Date</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            {tableinfo}
                        </tbody>
                    </Table>
                </Box>
            </DocsArticle>
        );
    }
};

const select = state => ({ ...state.eventlogInfo });

export default connect(select)(EventLogs);