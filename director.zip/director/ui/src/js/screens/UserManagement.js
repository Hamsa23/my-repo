// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Label from 'grommet/components/Label';
import DocsArticle from './DocsArticle';
import Tabs from 'grommet/components/Tabs';
import Tab from 'grommet/components/Tab';
import Paragraph from 'grommet/components/Paragraph';
import Table from 'grommet/components/Table';
import TableRow from 'grommet/components/TableRow';
import Configure from 'grommet/components/icons/base/UserSettings';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Layer from 'grommet/components/Layer';
import LayerForm from 'grommet-templates/components/LayerForm';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import FormFields from 'grommet/components/FormFields';
import CheckBox from 'grommet/components/CheckBox';
import DirectoryGroups from './DirectoryGroups';
import Notification from 'grommet/components/Notification';
import { loadusermanagement, submitAddUser, loadSingleUser, submitEditUser, DeleteSingleUser } from '../actions/usermanagement';
import { setInterval, clearInterval } from 'timers';

//Update Document Title
Label.displayName = 'User Management';

class UserManagement extends Component {

  constructor () {
    super();
		this.state = {
			AddUserLayerActive: false,
			EditUserLayerActive: false,
			DeleteLayerActive: false,
			LoginName: undefined,
			Password: undefined,
			ConfirmPassword: undefined,
			FirstName: undefined,
			LastName: undefined,
			EmailID: undefined,
			EditUserID: undefined,
			EditLoginName: undefined,
			EditFirstName: undefined,
			EditLastName: undefined,
			EditEmailID: undefined,
			SelectionId: undefined,
			SelectionName: undefined,
			showNotification: false,
			refreshInterval: undefined,
			NewPassword: undefined,
			ReEnterPassword: undefined,
			errors: {}
		};
		this._onAddUser = this._onAddUser.bind(this);
		this._deleteUser = this._deleteUser.bind(this);
		this._onEditUser = this._onEditUser.bind(this);
		this._onDeleteUser = this._onDeleteUser.bind(this);
		this._onAddUserLayerClose = this._onAddUserLayerClose.bind(this);
		this._onEditUserLayerClose = this._onEditUserLayerClose.bind(this);
		this._onDeleteUserLayerClose = this._onDeleteUserLayerClose.bind(this);
		this._onChange = this._onChange.bind(this);
		this._onAddUserSubmit = this._onAddUserSubmit.bind(this);
		this._onEditUserSubmit = this._onEditUserSubmit.bind(this);
		this._onSelectUser = this._onSelectUser.bind(this);
		this._validateInput = this._validateInput.bind(this);
		this._validateEditInput = this._validateEditInput.bind(this);
		this._getData = this._getData.bind(this);
		this._CheckResetPassword = this._CheckResetPassword.bind(this);
		this._SubmitResetPassword = this._SubmitResetPassword.bind(this);
		this._validateEditPasswordInput = this._validateEditPasswordInput.bind(this);
	}
	
	//Before Page load perform actions
	componentWillMount() {
	}

	//After Page load perform actions
	componentDidMount() {
		this.props.dispatch(loadusermanagement());
		var interval = setInterval( () => {
			this.props.dispatch(loadusermanagement())}, 5000);
			this.setState({refreshInterval: interval}); 
	}
	 
	//If redirecting to some other page stop Backend calls
	componentWillUnmount() {
		clearInterval(this.state.refreshInterval);
	}

	_CheckResetPassword(event){
		this.setState({NewPassword : undefined});
		this.setState({ReEnterPassword: undefined});
		if(event.target.checked == true){
			this.setState({ResetPassword: true});
		} else{
			this.setState({ResetPassword: false});
		}
	}

	_SubmitResetPassword(){
		let id = undefined; // Reset id to undefinded everytime user clicks on edit user
		id = this.state.EditUserID;
		var reqErr = "required";
		var nomatch = "password fields do not match";
    let err = Object.assign({}, this.state.errors); 
		this.state.isValid = undefined;

		if(this.state.NewPassword == '' || this.state.NewPassword == undefined){
			err["NewPassword"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.ReEnterPassword == '' || this.state.ReEnterPassword == undefined || this.state.NewPassword != this.state.ReEnterPassword){
			err["ReEnterPassword"] = nomatch;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		// POST information if no error
		if(this.state.isValid == undefined){
			let body = {
				"Password": this.state.NewPassword
			}
			this.props.dispatch(submitEditUser(id, body));
			this._onEditUserLayerClose();
			this.setState({showNotification: true});
			this.setState({ EditUserLayerActive: false });
			this.setState({ ResetPassword: false });
		}
	}
	

	//Update Edit Form on Click
	componentWillReceiveProps(nextProps){
		nextProps.response.map((response) =>{
			let data = [];
			data.push(response);
			this.setState({ 
				EditUserID: data[0].Id,
				EditLoginName: data[0].UserName,
				EditFirstName: data[0].FirstName,
				EditLastName: data[0].LastName,
				EditEmailID: data[0].Email 
			})
		});
	}

	//Validate Add user Form inputs
	_validateInput(event) {
    let err = {};
    var errMsg;
		var value = event.target.value;
    switch(event.target.name) {
      case "LoginName": 
        if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid login name";
        err = Object.assign({}, this.state.errors); 
        err[event.target.name] = errMsg;
        this.setState({errors: err});
				break;

			case "Password": 
        if (value != "null" || value != "undefined"){
          this.state.isValid = value.match(/^[a-zA-Z0-9_.@ ]{1,30}$/);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid password";
        err = Object.assign({}, this.state.errors); 
        err[event.target.name] = errMsg;
        this.setState({errors: err});
				break;
			
			case "ConfirmPassword":
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(this.state.Password);
				}
				errMsg = (this.state.isValid) ? "" : "password fields do not match";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
			
			case "FirstName": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid first name";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
			
			case "LastName": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid last name";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
			
			case "EmailID": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@(([0-9a-zA-Z])+([-\w]*[0-9a-zA-Z])*\.)+[a-zA-Z]{2,9})$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid email id";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
        default:
        break;
    }  
	};
	
	//Validate Edit user Form inputs
	_validateEditInput(event) {
    let err = {};
    var errMsg;
		var value = event.target.value;
    switch(event.target.name) {
      case "EditLoginName": 
        if (value != "null" || value != "undefined"){
          this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid login name";
        err = Object.assign({}, this.state.errors); 
        err[event.target.name] = errMsg;
        this.setState({errors: err});
				break;
			
			case "EditFirstName": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid first name";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
			
			case "EditLastName": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9]{1,20})*$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid last name";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
			
			case "EditEmailID": 
				if (value != "null" || value != "undefined"){
					this.state.isValid = value.match(/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@(([0-9a-zA-Z])+([-\w]*[0-9a-zA-Z])*\.)+[a-zA-Z]{2,9})$/);
				}
				errMsg = (this.state.isValid) ? "" : "enter a valid email id";
				err = Object.assign({}, this.state.errors); 
				err[event.target.name] = errMsg;
				this.setState({errors: err});
				break;
      default:
        break;
    }  
	};

		//Validate Edit Password Form inputs
		_validateEditPasswordInput(event) {
			let err = {};
			var errMsg;
			var value = event.target.value;
			switch(event.target.name) {
				case "NewPassword": 
					if (value != "null" || value != "undefined"){
						this.state.isValid = value.match(/^[a-zA-Z0-9_.@ ]{1,30}$/);
					}
					errMsg = (this.state.isValid) ? "" : "enter a valid password";
					err = Object.assign({}, this.state.errors); 
					err[event.target.name] = errMsg;
					this.setState({errors: err});
					break;
				
				case "ReEnterPassword":
					if (value != "null" || value != "undefined"){
						this.state.isValid = value.match(this.state.NewPassword);
					}
					errMsg = (this.state.isValid) ? "" : "password fields do not match";
					err = Object.assign({}, this.state.errors); 
					err[event.target.name] = errMsg;
					this.setState({errors: err});
					break;
				default:
					break;
				}  
		};
	
	//On add user form fill perform actions
  _onChange (event) {
		this.setState({showNotification: false});
    this.setState({
			[event.target.name] : event.target.value
		});
		this._validateInput(event);  //Validate user input in add form
		this._validateEditInput(event);  //Validate user input in add form
		this._validateEditPasswordInput(event);  //Validate Password input edit form
	}

	//AddUserLayerActive close
	_onAddUserLayerClose () {
		this.setState({ 
			AddUserLayerActive: false,
			LoginName: undefined,
			Password: undefined,
			ConfirmPassword: undefined,
			FirstName: undefined,
			LastName: undefined,
			EmailID: undefined
	  });
	}
	
	//EditLayerActive close
	_onEditUserLayerClose () {
		this.setState({ EditUserLayerActive: false });
		this.setState({ ResetPassword: false });
		this.setState({ NewPassword: undefined});
		this.setState({ ReEnterPassword: undefined});
	}
	
	//DeleteLayerActive close
	_onDeleteUserLayerClose () {
		this.setState({ DeleteLayerActive: false });
  }

	//On click of adduser button perform action
  _onAddUser () {
		this.setState({showNotification: false});
		this.setState({ AddUserLayerActive: true });	
	}

	//On click of edituser button perform action
	_onEditUser (user) {
		this.setState({showNotification: false});
		let userid = undefined; //Reset variable value to reuse
		userid = user;
		this.props.dispatch(loadSingleUser(userid));	
		this.setState({ EditUserLayerActive: true});
	}

	//On Radio button click collect selection information
	_onSelectUser (selectid, selectname) {
		this.setState({showNotification: false});
		let id = undefined;
		let name = undefined;
		id = selectid;
		name = selectname;
		this.setState({
					SelectionId: id,
					SelectionName: name
				}
			)
		}

	//On click of deleteuser button perform action
	_onDeleteUser () {
		if(this.state.SelectionId != undefined)
		{
			this.setState({ DeleteLayerActive: true })
		}
	}

	//On click of adduser layer button (on form submit) validate inputs before posting
	_onAddUserSubmit () {
		var reqErr = "required";
		var nomatch = "password fields do not match";
    let err = Object.assign({}, this.state.errors); 
		this.state.isValid = undefined;

		// Set error message on empty text boxes before submit
		if(this.state.LoginName == '' || this.state.LoginName == undefined){
			err["LoginName"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.Password == '' || this.state.Password == undefined){
			err["Password"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.ConfirmPassword == '' || this.state.ConfirmPassword == undefined || this.state.Password != this.state.ConfirmPassword){
			err["ConfirmPassword"] = nomatch;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.FirstName == '' || this.state.FirstName == undefined){
			err["FirstName"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.LastName == '' || this.state.FirstName == undefined){
			err["LastName"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		if(this.state.EmailID == '' || this.state.EmailID == undefined){
			err["EmailID"] = reqErr;
			this.setState({errors: err});
			this.state.isValid = false;
		}
		//POST information if no error
		if(this.state.isValid == undefined){
				let body = {
					"UserName": this.state.LoginName,
					"FirstName": this.state.FirstName,
					"Email": this.state.EmailID,
					"LastName": this.state.LastName,
					"Password": this.state.Password
				}
				this.props.dispatch(submitAddUser(body));
				this._onAddUserLayerClose();
				this.setState({showNotification: true});
			}
		}

	//On click of adduser layer button (on form submit)
	_onEditUserSubmit () {
		let id = undefined; // Reset id to undefinded everytime user clicks on edit user
		id = this.state.EditUserID;
		if(!this.state.errors.EditLoginName && this.state.EditLoginName != undefined && this.state.EditLoginName != '')
			{
			if(!this.state.errors.EditFirstName && this.state.EditFirstName != undefined && this.state.EditFirstName != '')
				{
				if(!this.state.errors.EditEmailID && this.state.EditEmailID != undefined && this.state.EditEmailID != '')
					{
					if(!this.state.errors.EditLastName && this.state.EditLastName != undefined && this.state.EditLastName != '')
						{
							let body = {
								"UserName": this.state.EditLoginName,
								"FirstName": this.state.EditFirstName,
								"Email": this.state.EditEmailID,
								"LastName": this.state.EditLastName
							}
							this.props.dispatch(submitEditUser(id, body));
							this._onEditUserLayerClose();
							this.setState({showNotification: true});
							this.componentDidMount();
						}
					}
				}
			}
		}

	//On Click of delete user button perform action
	_deleteUser(){
		let id = undefined;
		id = this.state.SelectionId;
		this.props.dispatch(DeleteSingleUser(id));
		this._onDeleteUserLayerClose();
		this.setState({showNotification: true});
	}

	// On load below funtion will populate User Table Dynamically
	_getData () {
		var UserTableData = this.props.mngacct.map((SingleUserInfo) =>
		<TableRow>
			<td><CheckBox  id={SingleUserInfo.Id} onClick={this._onSelectUser.bind(this,SingleUserInfo.Id,SingleUserInfo.UserName)}/></td>
			<td>{SingleUserInfo.UserName}</td>
			<td>{SingleUserInfo.FirstName}</td>
			<td>{SingleUserInfo.LastName}</td>
			<td>{SingleUserInfo.Email}</td>
			<td><Configure id={SingleUserInfo.Id} onClick={this._onEditUser.bind(this,SingleUserInfo.Id)}/></td>
		</TableRow>
		);
		return UserTableData;
	}

  render () {
		const { err } = this.props; //Catch response from reducer
		let notification;
    if (this.state.showNotification == true){
      if(err == "New User Successfully Added" || err == "User Successfully Deleted" || err == "User Successfully Saved" || err == "User Successfully Modified" || err == "User password reset successfully" ){
        notification = <Notification size='medium' status='ok' message={err} closer={true} onClose={() => this.setState({ showNotification: false })}/>
       	}
      else{
        notification = <Notification size='medium' status='critical' message={err} closer={true} onClose={() => this.setState({ showNotification: false })}/>
			}
		 }

		var tableinfo = this._getData(); //Fetch User Table data

		let DeleteUser;
		if(this.state.DeleteLayerActive){
			let username = window.localStorage.getItem('name');
			if(this.state.SelectionName != username){
				DeleteUser=
					(
						<LayerForm align='center'  title="Delete User" submitLabel="Delete" overlayClose={true} 
							onClose={this._onDeleteUserLayerClose} onSubmit={this._deleteUser}>
							<fieldset>
								<Box>
										<FormFields>
											<fieldset>
												<Paragraph>Are you sure you want to delete the user named {this.state.SelectionName} ?</Paragraph> 
											</fieldset>
										</FormFields>
								</Box>												               
							</fieldset>
						</LayerForm>
					);
				}
				else{
					DeleteUser=
					(
						<LayerForm align='center'  title="Delete User" submitLabel="Delete" overlayClose={true} 
							onClose={this._onDeleteUserLayerClose} onSubmit={this._deleteUser}>
							<fieldset>
								<Box>
										<FormFields>
											<fieldset>
												<Paragraph>Are you sure you want to delete the user named {this.state.SelectionName} ? </Paragraph>
											</fieldset>
										</FormFields>
								</Box>												               
							</fieldset>
						</LayerForm>
					);
				}
			}

		let AddUserLayer;
    if(this.state.AddUserLayerActive){
      AddUserLayer=
        (
          <LayerForm align='center' title="Add User" submitLabel="Add" overlayClose={true} 
            onClose={this._onAddUserLayerClose} onSubmit={this._onAddUserSubmit}>
            <fieldset>
						<Form> 
						<FormFields>
              <fieldset>
                <FormField label='Login name' error={this.state.errors["LoginName"]}>
                  <input id='LoginName' type='text' name="LoginName" onChange={this._onChange} value={this.state.LoginName}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='Password' error={this.state.errors["Password"]}>
                  <input id='Password' type='Password' name="Password" onChange={this._onChange} value={this.state.Password}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='Confirm password' error={this.state.errors["ConfirmPassword"]}>
                  <input id='ConfirmPassword' type='Password' name="ConfirmPassword" onChange={this._onChange} value={this.state.ConfirmPassword}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='First name' error={this.state.errors["FirstName"]}>
                  <input id='FirstName' type='text' name="FirstName" onChange={this._onChange} value={this.state.FirstName}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='Last name' error={this.state.errors["LastName"]}>
                  <input id='LastName' type='text' name="LastName" onChange={this._onChange} value={this.state.LastName}/>
                </FormField>
              </fieldset>
              </FormFields>
							
							<FormFields>
              <fieldset>
                <FormField label='Email ID' error={this.state.errors["EmailID"]}>
                  <input id='EmailID' type='text' name="EmailID" onChange={this._onChange} value={this.state.EmailID}/>
                </FormField>
              </fieldset>
              </FormFields>
							
              </Form>
            </fieldset>
          </LayerForm>
				);
			}

		var resetPwdForm;
		if (this.state.ResetPassword) {
				resetPwdForm = <Form pad='medium'>
						<Box pad="small" id="ResetPassword">
								<FormFields>
								<fieldset>
									<FormField label='New Password' error={this.state.errors["NewPassword"]}>
										<input id='NewPassword' type='Password' name="NewPassword" onChange={this._onChange} value={this.state.NewPassword}/>
									</FormField>
								</fieldset>
								</FormFields>

								<FormFields>
								<fieldset>
									<FormField label='Re-Enter Password' error={this.state.errors["ReEnterPassword"]}>
										<input id='ReEnterPassword' type='Password' name="ReEnterPassword" onChange={this._onChange} value={this.state.ReEnterPassword}/>
									</FormField>
								</fieldset>
								</FormFields>
						</Box>
						<Box direction='row'>
								<Button label='Reset Password' primary={true} onClick={this._SubmitResetPassword} />
						</Box>
				</Form>
		}

		let EditUserLayer;
    if(this.state.EditUserLayerActive){
			clearInterval(this.state.refreshInterval);  //Stop backend calls when layer active
			//Fetched data from backend for edit table
      EditUserLayer=
        (
          <LayerForm title="Edit User" submitLabel="Save" overlayClose={true} 
			onClose={this._onEditUserLayerClose} onSubmit={this._onEditUserSubmit}>
            <fieldset>
						<Form> 
						<FormFields>
              <fieldset>
                <FormField label='Login name' error={this.state.errors["EditLoginName"]}>
                  <input id='LoginName' type='text' name="EditLoginName" onChange={this._onChange} value={this.state.EditLoginName}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='First name' error={this.state.errors["EditFirstName"]}>
                  <input id='FirstName' type='text' name="EditFirstName" onChange={this._onChange} value={this.state.EditFirstName}/>
                </FormField>
              </fieldset>
              </FormFields>

							<FormFields>
              <fieldset>
                <FormField label='Last name' error={this.state.errors["EditLastName"]}>
                  <input id='LastName' type='text' name="EditLastName" onChange={this._onChange} value={this.state.EditLastName}/>
                </FormField>
              </fieldset>
              </FormFields>
							
							<FormFields>
              <fieldset>
                <FormField label='Email ID' error={this.state.errors["EditEmailID"]}>
                  <input id='EmailID' type='text' name="EditEmailID" onChange={this._onChange} value={this.state.EditEmailID}/>
                </FormField>
              </fieldset>
              </FormFields>

							<Box pad="small">
								<CheckBox label="Reset Password" checked={this.ResetPassword} onChange={this._CheckResetPassword}/>
								<Box>{resetPwdForm}</Box>
							</Box>
              </Form>
            </fieldset>
          </LayerForm>
				);
			}

    return (
      <DocsArticle title='User Management'>
         <section>
	          <Tabs justify='start'>
	              <Tab title='User Administration'>
								<div>{notification}</div>
	              <Table scrollable={false}>
	                <thead>
	                  <tr>
											<th></th>
	                    <th><strong>Login Name</strong></th>
	                    <th><strong>First Name</strong></th>
	                    <th><strong>Last Name</strong></th>
	                    <th><strong>Email</strong></th>
                      <th><strong>Edit</strong></th>
	                  </tr>
	                </thead>
	                <tbody>
										{tableinfo}
	                </tbody>
	              </Table>
                <Box direction='row'>
                  <Button label='Add User' primary={true} onClick={this._onAddUser}/>
                  <Box pad={{horizontal: 'small',vertical:'none'}}>
                    <Button label='Delete User' primary={true} onClick={this._onDeleteUser}/>
                  </Box>
                </Box>
								<Box>
								{AddUserLayer}
								{DeleteUser}
								{EditUserLayer}
								</Box>
	              </Tab>
	              <Tab title='Directory Groups'>
									<DirectoryGroups />
	              </Tab>
	            </Tabs>
        </section>
      </DocsArticle>
    );
  }
};

const user = state => ({
	...state.usermanagement
});

export default connect(user)(UserManagement);
