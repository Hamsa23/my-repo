// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Chart from 'grommet/components/chart/Chart';
import DocsArticle from './DocsArticle';
import Section from 'grommet/components/Section';
import Heading from 'grommet/components/Heading';
import Label from 'grommet/components/Label';
import { loadGraph } from '../actions/graph';

var LineChart = require("react-chartjs").Line;
var BarChart = require("react-chartjs").Bar;

//Update Document Title
Label.displayName = 'Graph';

class Graph extends Component {

  constructor() {
      super();
      this.state = {
        refreshInterval: undefined,
        cpu_1: undefined,
        cpu_5: undefined,
        cpu_15:undefined,
        memAvailable: undefined,
        memFree: undefined,
        memTotal: undefined,
        ntwRecieve: undefined,
        ntwRecieveDropped: undefined,
        ntwRecieveErr: undefined,
        ntwTransmit: undefined,
        ntwTransmitDropped: undefined,
        ntwTransmitErr: undefined
      };
  }

  componentDidMount() {
    this.props.dispatch(loadGraph());
    //reload the page with a time interval of 2 sec
    var interval = setInterval( () => {
      this.props.dispatch(loadGraph())}, 2000);
    this.setState({refreshInterval: interval});
  }

  //If redirecting to some other page stop Backend calls
  componentWillUnmount() {
    clearInterval(this.state.refreshInterval);
  }

  componentWillReceiveProps(nextProps) {
    var data = nextProps;
    if((data.cpu != undefined) && (data.memory != undefined) && (data.network != undefined)) {
      this.setState({
        cpu_1: data.cpu["1"],
        cpu_5: data.cpu["5"],
        cpu_15: data.cpu["15"],
        memAvailable: (data.memory["MemAvailable"] / 1000),
        memFree: (data.memory["MemFree"] / 1000),
        memTotal: (data.memory["MemTotal"] / 1000),
        ntwRecieve: data.network["Receive"],
        ntwRecieveDropped: data.network["ReceiveDropped"],
        ntwRecieveErr: data.network["ReceiveError"],
        ntwTransmit: data.network["Transmit"],
        ntwTransmitDropped: data.network["TransmitDropped"],
        ntwTransmitErr: data.network["TransmitError"]
      })
    }
  }

  render () {

    var cpuChartData = {
      labels: ["15", "5", "1"],
      datasets: [
        {
            label: "CPU Utilization",
            fillColor: "rgba(95, 122,118, 0.5)",
            strokeColor: "rgba(95, 122, 118, 0.8)",
            highlightFill: "rgba(95, 122, 118, 0.75)",
            highlightStroke: "rgba(95, 122, 118, 1)",
            data: [this.state.cpu_15, this.state.cpu_5, this.state.cpu_1]
        }
      ]
    };
    var memChartData = {
      labels: ["Total Memory", "Memory Available", "Memory Free"],
      datasets: [
        {
            label: "Memory Utilization",
            fillColor: "rgba(95, 122,118, 0.5)",
            strokeColor: "rgba(95, 122, 118, 0.8)",
            highlightFill: "rgba(95, 122, 118, 0.75)",
            highlightStroke: "rgba(95, 122, 118, 1)",
            data: [this.state.memTotal, this.state.memAvailable, this.state.memFree]
        }
      ]
    };
    var networkChartData = {
      labels: ["Receive", "Receive Dropped", "Receive Error", "Transmit", "Transmit Dropped", "Transmit Error"],
      datasets: [
        {
            label: "Network Transmit",
            fillColor: "rgba(95, 122,118, 0.5)",
            strokeColor: "rgba(95, 122, 118, 0.8)",
            highlightFill: "rgba(95, 122, 118, 0.75)",
            highlightStroke: "rgba(95, 122, 118, 1)",
            data: [this.state.ntwRecieve, this.state.ntwRecieveDropped, this.state.ntwRecieveErr, this.state.ntwTransmit, this.state.ntwTransmitDropped, this.state.ntwTransmitErr]
        }
      ]
    };

    var cpuUtilChart = <LineChart data={cpuChartData} width="500" height="200"/>;
    var memUtilChart = <BarChart data={memChartData} width="500" height="200"/>;
    var networkChart = <BarChart data={networkChartData} width="500" height="250"/>;

    return (
      <DocsArticle title='Appliance Monitoring'>
        <Section>
          <Heading tag='h3'><strong>CPU Utilization</strong></Heading>
          <Chart>
            {cpuUtilChart}
          </Chart>
        </Section>

        <Section>
          <Heading tag='h3'><strong>Memory Utilization</strong></Heading>
          <Chart>
            {memUtilChart}
          </Chart>
        </Section>

        <Section>
          <Heading tag='h3'><strong>Network</strong></Heading>
          <Chart>
            {networkChart}
          </Chart>
        </Section>

      </DocsArticle>
    );
  }
};

const select = state => ({ ...state.graphInfo });

export default connect(select)(Graph);
