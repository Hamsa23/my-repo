// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Button from 'grommet/components/Button';
import FormFields from 'grommet/components/FormFields';
import Section from 'grommet/components/Section';
import TextInput from 'grommet/components/TextInput';
import Box from 'grommet/components/Box';
import Spinning from 'grommet/components/icons/Spinning';
import Label from 'grommet/components/Label';
import {RegServer} from '../actions/systemRegister';
import Notification from 'grommet/components/Notification';


//Update Document Title
FormField.displayName = 'FormField';
Form.displayName = 'Form';

 class SystemRegister extends Component {
  constructor () {
    super();
    this._onChange = this._onChange.bind(this);
    this._validateInput = this._validateInput.bind(this);
    this._onRegister = this._onRegister.bind(this);
    this._onCloseNotification = this._onCloseNotification.bind(this);
    this.state = {
        isValid: undefined,
        discoveryResp: undefined,
        errors: {
          "ip": "",
          "userName": "",
          "password": ""
        },
        error: undefined,
        disabled: false,
        showNotification: false,
      ShowRegIP: ''
      };
    }

    _onChange(event) {
      this._validateInput(event);
    }

    componentWillReceiveProps(nextProps) {
      this.setState({
        showNotification: true
      });
    }

    _validateInput(event){
      let err = Object.assign({}, this.state.errors);
      var errMsg;
      var value = event.target.value;
      switch(event.target.accept) {
        case "ip":
          var regex = RegExp('^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')
          if (value != "0.0.0.0"){
            this.state.isValid = regex.test(value);
          }
          errMsg = (this.state.isValid) ? "" : "enter a valid IP address";
          err[event.target.name] = errMsg;
          this.setState({errors: err});
          break;
        default:
          var regex = RegExp('^[0-9a-zA-Z]+$');
          this.state.isValid = regex.test(value);
          errMsg = (this.state.isValid) ? "" : "enter a valid string";
          err[event.target.name] = errMsg;
          this.setState({errors: err});
          break;
      }
    }
  
    _onRegister() {
      let reqErr = "required";
      let err = Object.assign({}, this.state.errors);
      this.state.isValid = true;
      this.state.discoveryResp = undefined;
      if (IP.value == "") {
        err["ip"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
      if (UserName.value == "") {
        err["userName"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
      if (Password.value == "") {
        err["password"] = reqErr;
        this.setState({errors: err});
        this.state.isValid = false;
      }
  
      if ((this.state.errors["ip"] != "") || (this.state.errors["userName"] != "") || (this.state.errors["password"] != "") || (this.state.isValid == false)) {
        return false;
      }
  
      let singleRegisterdata =
      {
        "IP": IP.value,
        "UserName": UserName.value,
        "Password": Password.value
      };
      this.props.dispatch(RegServer(singleRegisterdata));
      this.setState({
        showNotification: true
      });
      this.setState({ShowRegIP: IP.value});
      window.localStorage.registrationInProgress = "true";
    }

    _onCloseNotification() {
      this.setState({ showNotification: false });
    }

    render () {
        let notification, spinner = undefined;
        if (window.localStorage.registrationInProgress == "true") {
          spinner =
          <Box justify='center' align='center' wrap={true} pad='none' margin='none' colorIndex='light-1'>
            <Spinning size='small' /><Label size='medium'>Processing please wait ...</Label>
          </Box>
        }
        else if (this.state.showNotification === true) {
          if (this.props.systemRegResp != undefined) {
            notification =
              <Notification pad='medium' size='medium'
                closer='true' onClose={this._onCloseNotification} status='ok'
                message={"Target (" + this.state.ShowRegIP +") is registered successfully"} />
          } else if (this.props.systemRegErr != undefined) {
            notification =
              <Notification pad='medium' size='medium'
                closer='true' onClose={this._onCloseNotification} status='critical'
                message={this.props.systemRegErr} />
          }
        }
        return (
            <Section>
                  <Form>
                    {spinner}
                    <Box pad={{ vertical: 'small' }}>{notification}</Box>
                    <FormFields>
                      <FormField label='IP Address' error={this.state.errors["ip"]}>
                        <TextInput disabled={this.state.disabled} id='IP' name='ip' type='text' accept="ip" onDOMChange={this._onChange} />
                      </FormField>
                      <FormField label='Username' error={this.state.errors["userName"]}>
                        <TextInput disabled={this.state.disabled} id='UserName' name='userName' type='text' accept="" onDOMChange={this._onChange} />
                      </FormField>
                      <FormField label='Password' error={this.state.errors["password"]} >
                        <TextInput disabled={this.state.disabled} id='Password' name='password' type='password' accept="" onDOMChange={this._onChange} />
                      </FormField>
                    </FormFields>
                    <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
                        <Button label='Register' primary={true} onClick={this._onRegister} />
                    </Box>
                  </Form>
            </Section>
          );
        }
      };
      
      const select = state => ({ ...state.systemRegisterInfo });
      
      export default connect(select)(SystemRegister);
