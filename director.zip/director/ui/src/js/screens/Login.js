// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Split from 'grommet/components/Split';
import Sidebar from 'grommet/components/Sidebar';
import LoginForm from 'grommet/components/LoginForm';
import Article from 'grommet/components/Article';
import Section from 'grommet/components/Section';
import Heading from 'grommet/components/Heading';
import Footer from 'grommet/components/Footer';
import Label from 'grommet/components/Label';
import Box from 'grommet/components/Box';
import BrandHpeElementOutlineIcon from 'grommet/components/icons/base/BrandHpeElementOutline';
import Headline from 'grommet/components/Headline';
import Paragraph from 'grommet/components/Paragraph';
import { login, redfish } from '../actions/session';
import { navEnable } from '../actions/nav';
import { pageLoaded } from './utils';

//Update Document Title
Label.displayName = 'Login';

class Login extends Component {
  constructor() {
    super();
    this._onSubmit = this._onSubmit.bind(this);
  }

  componentWillMount(){
    this.props.dispatch(redfish()); //Get Redfish/v1 recursively
    var interval = setInterval( () => {
			this.props.dispatch(redfish())}, 5000);
			this.setState({refreshInterval: interval}); 
  }

  componentDidMount() {
    pageLoaded('Login');
    this.props.dispatch(navEnable(false));
  }

  componentWillReceiveProps(){
    if( this.props.redfish != undefined && this.props.redfish != 'Server Unreachable'){
      clearInterval(this.state.refreshInterval); //Stop recursive calling when get call on v1 success.
    }
  }

  componentWillUnmount() {
    this.props.dispatch(navEnable(true));
    clearInterval(this.state.refreshInterval); //Stop recursive calling when redirecting to other page.
  }

  _onSubmit(fields) {
    const { dispatch } = this.props;
    const { router } = this.context;
    dispatch(login(fields.username, fields.password, () => (
      router.history.push('/Dashboard')
    )));
  }

  render() {
    const { session: { error } } = this.props;
    const { redfish } = this.props; //Catch response from reducer

	var sessionTimeoutRebootMsg = window.localStorage.timeoutRebootMsg;
    if( sessionTimeoutRebootMsg != undefined ) {
      try {
        window.localStorage.removeItem('username');
        window.localStorage.removeItem('name');
        window.localStorage.removeItem('token');
        window.localStorage.removeItem('location');
        window.localStorage.removeItem('registrationInProgress');
        window.localStorage.removeItem('ldap');
      }
      catch (e) {
        // ignore
      } 
    }
	
    if(redfish == undefined || redfish == 'Server Unreachable'){
      return (
        <Box full={true} align='center' justify='center'>
          <BrandHpeElementOutlineIcon colorIndex='brand' size='xlarge' type='logo'/>
          <Headline strong={true}>EIM Loading ...</Headline>
          <Paragraph size='large' align='center'><strong>Please wait while the system is getting ready, It may take a while.</strong></Paragraph>
        </Box>
      );
    } else{
	  if( sessionTimeoutRebootMsg!= undefined && sessionTimeoutRebootMsg.startsWith('Reboot')) {
        window.localStorage.removeItem('timeoutRebootMsg');
      }
      return (
        <Split flex='left' separator={false}>
          <Article>
            <Section
              full={true}
              colorIndex='neutral-1'
              texture='url(img/splash.png)'
              pad='large'
              justify='center'
              align='center'
              style={{'background-size':'contain'}}>
            </Section>
          </Article>
          <Sidebar justify='between' align='center' pad='none' size='large'>
            <span />
            <LoginForm
              align='start'
              logo={<div><img src="img/mobile-app-icon.png" height="50px" width="120px" /><br/><br/></div>}
              title= {<Heading strong={true} tag='h3' align='start'> Edgeline Infrastructure Manager (EIM)</Heading>}
              secondaryText={<Label><strong>{"EIM Application Version : "+ this.props.redfish.Oem.Hp.Manager[0].FirmwareVersion}</strong></Label>}
              onSubmit={this._onSubmit}
              errors={( error != undefined ) ? [error] : [sessionTimeoutRebootMsg]}
              usernameType='text'/>
            <Footer
              direction='row'
              size='small'
              pad={{ horizontal: 'medium', vertical: 'small' }}>
              <span className='secondary'>&copy; 2019 Hewlett Packard Enterprise Development LP.</span>
            </Footer>
          </Sidebar>
        </Split>
      );
    }
  }
}

Login.defaultProps = {
  session: {
    error: undefined
  }
};

Login.propTypes = {
  dispatch: PropTypes.func.isRequired,
  session: PropTypes.shape({
    error: PropTypes.string
  })
};

Login.contextTypes = {
  router: PropTypes.object.isRequired,
};

const select = state => ({ session: state.session, ...state.redfish });

export default connect(select)(Login);
