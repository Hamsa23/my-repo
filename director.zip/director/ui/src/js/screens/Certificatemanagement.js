// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import DocsArticle from './DocsArticle';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import Paragraph from 'grommet/components/Paragraph';
import Notification from 'grommet/components/Notification';
import Layer from 'grommet/components/Layer';
import { Certificate } from '../actions/certificatemanagement';
import Header from 'grommet/components/Header';
import Heading from 'grommet/components/Heading';
import { ResetEIMConfig } from '../actions/resetEIM';
import FormFields from 'grommet/components/FormFields';


FormField.displayName = 'FormField';
Form.displayName = 'Form';

class Certificatemanagement extends Component {

  constructor() {
    super();
    this._onChangeCert = this._onChangeCert.bind(this);
    this._onChangeKey = this._onChangeKey.bind(this);
    this._UploadFile = this._UploadFile.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._onConfirmationClose = this._onConfirmationClose.bind(this);
    this._getFileExtension = this._getFileExtension.bind(this);
    this.state = {
      showNotification: false,
      LayerOpen: false,
      errorMessage: null,
      errorms: undefined,
      certificate_required: undefined,
      key: undefined,
      consoleLogin: false
    };
  }

  componentDidMount() {
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ errorms: nextProps.error })
  }
  _onConfirmationClose() {
    this.setState({ LayerOpen: false })
  }

  _getFileExtension(filename)
  {
    var ext = /^.+\.([^.]+)$/.exec(filename);
    return ext == null ? "" : ext[1];
  }
  //vaildate the form fields and pop up the confirmation layer.
  _onSubmit() {
    this.setState({ LayerOpen: true });
    this.setState({ certificate_required: "" });
    this.setState({ key_required: "" });
    let certfile = this.refs.certfile.files[0];
    let keyfile = this.refs.keyfile.files[0];
    if (certfile == undefined) {
      let errMsg = "certificate file is required";
      this.setState({ certificate_required: errMsg });
      this.setState({ LayerOpen: false });
    } else {
      let certExtn = this._getFileExtension(certfile.name);
      if (certExtn != "crt") {
        let errMsg = "invalid certificate file extension";
        this.setState({ certificate_required: errMsg });
        this.setState({ LayerOpen: false });
      }
    }

    if (keyfile == undefined) {
      let errMsg = "key file is required";
      this.setState({ key_required: errMsg });
      this.setState({ LayerOpen: false });
    } else{
      let keyExtn = this._getFileExtension(keyfile.name);
      if (keyExtn != "key") {
        let errMsg = "invalid key file extension";
        this.setState({ key_required: errMsg });
        this.setState({ LayerOpen: false });
      }
    }
  }
  _UploadFile() {
    let certfile = this.refs.certfile.files[0];
    let keyfile = this.refs.keyfile.files[0];
    this.props.dispatch(Certificate(certfile, keyfile));
    this.setState({ showNotification: true });
    this.setState({ LayerOpen: false })
  }
  _onclose() {
    this.setState({ notificatonMessage: false })
  }
  _onChangeCert(event) {
    this.setState({ certFileName: event.target.files[0].name });
    this.setState({ certFileHandle: event.target.files[0] });
  }
  _onChangeKey(event) {
    this.setState({ keyFileName: event.target.files[0].name });
    this.setState({ keyFileHandle: event.target.files[0] });
  }
  render() {
    //Notification Component
    const { error } = this.props;
    const { sslUpdate } = this.props;
    let notification;
    if (this.state.showNotification === true) {
      if (this.props.sslUpdate != undefined && this.props.sslUpdate.Response_message != undefined){
        if( this.props.sslUpdate.Response_message.indexOf('SSL files uploaded')>=0) {//files uploaded
          if( this.props.sslUpdate.restart_required.indexOf('True')>=0) {//uploaed with reboot required
            notification =
              <Notification onClose={this._onClose} pad='medium' size='medium' closer='true' status='ok'
                 message='Certificate file and key file are uploaded successfully. It will reboot the EIM and it will tkae few minutes to reboot.' />
            //reboot the eim
            var resetData = {"restart_required":"True"};
			window.localStorage.timeoutRebootMsg = "Reboot is in progress. Please wait...";
            this.props.dispatch(ResetEIMConfig(resetData));
            setTimeout(function() {
              window.location.href = '/Login';
            }, 5000);
          }else{
            notification =// uploaded but no reboot reuqired. may be this will never happens
              <Notification onClose={this._onClose} pad='medium' size='medium' closer='true' status='ok'
                message='Certificate file and key file are uploaded successfully.' />
          }
          this.setState({ showNotification: false });
        }
        else {// error, failed in uploading files.
          this.setState({ showNotification: false });
          notification =
            <Notification onClose={this._onClose} pad='medium' size='medium' closer='true' status='critical'
               message="Failed to upload certificate file and key file, check the ceritifate files an try again" />
        }
      }

    }
    //Layer Component for SSL update and reset confirmation
    let layer;
    if (this.state.LayerOpen) {
      layer =
        (
          <Layer align="right" closer={true} onClose={this._onConfirmationClose} compact={true} >
            <Form submitLabel="Apply SSL certificate">
              <Header><Heading tag='h2'>Apply SSL certificate and reboot</Heading></Header>
              <fieldset>
                <Paragraph>Applying new SSL certificate settings requires an EIM reboot. Would you like to apply the new settings and reboot EIM now? </Paragraph><br />
              </fieldset>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>

                <Button label='Apply & Reboot' primary={true} onClick={this._UploadFile} />
              </Box>
            </Form>
          </Layer>
        );
    }
    let consoleMessage = undefined;
    if(window.location.host == '127.0.0.1'){
      this.state.consoleLogin = true;
      consoleMessage = <Notification pad='medium' status='unknown' message="Use a remote web browser to upload or download files from EIM"></Notification>;
    }
    return (
      <DocsArticle title='Certificate Management'>
        <Box pad={{ vertical: 'small', between:'small'}}>
          {consoleMessage}
          {notification}
        </Box>
        <Paragraph><strong>
          Provide SSL certificate and key file to import certificate</strong>
        </Paragraph>
        <Form>
          <FormFields>
            <FormField label='SSL certificate file' htmlFor='input-id' error={this.state.certificate_required}>
              <input disabled={this.state.consoleLogin} type="file" id="certfile" ref="certfile" name="certfile" accept=".crt" onChange={this._onChangeCert} />
            </FormField>
            <FormField label='SSL certificate key file' htmlFor='input-id' error={this.state.key_required}>
              <input disabled={this.state.consoleLogin} type="file" id="keyfile" ref="keyfile" name="keyfile" accept=".key" onChange={this._onChangeKey} />
            </FormField>
          </FormFields>
          <Box pad={{vertical: 'small',horizontal: 'none'}} direction='row'>
            <Button label='Import Certificate' primary={true} onClick={(this.state.consoleLogin) ? null : this._onSubmit}/>
          </Box>
          {layer}
        </Form>
      </DocsArticle>
    );
  }
};

const select = state => ({
  ...state.certificatemanagement
});
export default connect(select)(Certificatemanagement);
