// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Split from 'grommet/components/Split';
import Sidebar from 'grommet/components/Sidebar';
import LoginForm from 'grommet/components/LoginForm';
import Article from 'grommet/components/Article';
import Section from 'grommet/components/Section';
import Heading from 'grommet/components/Heading';
import Footer from 'grommet/components/Footer';
import Label from 'grommet/components/Label';
import Anchor from 'grommet/components/Anchor';
import Form from 'grommet/components/Form';
import FormFields from 'grommet/components/FormFields';
import FormField from 'grommet/components/FormField';
import Box from 'grommet/components/Box';
import TextInput from 'grommet/components/TextInput';
import Button from 'grommet/components/Button';
import BrandHpeElementOutlineIcon from 'grommet/components/icons/base/BrandHpeElementOutline';
import Headline from 'grommet/components/Headline';
import Paragraph from 'grommet/components/Paragraph';
import { login, redfish } from '../actions/session';
import { navEnable } from '../actions/nav';
import { pageLoaded } from './utils';
import { EIMPasswordReset, EIMFactoryReset, getIPaddress } from '../actions/consoleLogin';
import Layer from 'grommet/components/Layer';
import Header from 'grommet/components/Header';


//Update Document Title
Label.displayName = 'Login';

class ConsoleLogin extends Component {
  constructor() {
    super();
    this._onChange = this._onChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._onForgotPwd = this._onForgotPwd.bind(this);
    this._onResetPassword = this._onResetPassword.bind(this);
    this._onFactoryReset = this._onFactoryReset.bind(this);
    this._onConfirmationClose = this._onConfirmationClose.bind(this);
    this._onConfirmReset = this._onConfirmReset.bind(this);
    this.state = {
      showForgotPwdForm: false,
      newPassword: undefined,
      confirmPassword: undefined,
      isValid: undefined,
      errors: [],
      eim_ipv4: undefined,
      eim_ipv6: undefined,
      refreshInterval: undefined,
      refreshIntervalIp: undefined,
      LayerOpen: false
    };
  }

  componentWillMount() {
    this.props.dispatch(redfish()); //Verify Redfish/v1 is working fine
    var interval = setInterval(() => {
      this.props.dispatch(redfish())
    }, 5000);
    this.setState({ refreshInterval: interval });
  }

  componentDidMount() {
    pageLoaded('Login');
    this.props.dispatch(navEnable(false));
    this.props.dispatch(getIPaddress());
    var interval = setInterval(() => {
      this.props.dispatch(getIPaddress())
    }, 5000);
    this.setState({ refreshIntervalIp: interval });
  }

  componentWillUnmount() {
    clearInterval(this.state.refreshInterval);
    clearInterval(this.state.refreshIntervalIp);
    this.props.dispatch(navEnable(true));
  }

  componentWillReceiveProps() {
    if (this.props.redfish != undefined && this.props.redfish != 'Server Unreachable') {
      clearInterval(this.state.refreshInterval);
    }
    if (this.props.eim_ipv4 != undefined && this.props.eim_ipv6 != undefined) {
      clearInterval(this.state.refreshIntervalIp);
    }
  }

  _onChange(event) {
    let err = {};
    var errMsg;
    var value = event.target.value;
    switch (event.target.name) {
      case "newPassword":
        if (value != "null" || value != "undefined") {
          this.state.isValid = (/^[a-zA-Z0-9_.@ ]{2,30}$/).test(value);
        }
        errMsg = (this.state.isValid) ? "" : "enter a valid password";
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({ errors: err });
        break;
      case "confirmPassword":
        if (value != "null" || value != "undefined") {
          this.state.isValid = (value === newPassword.value);
        }
        errMsg = (this.state.isValid) ? "" : "password fields do not match";
        err = Object.assign({}, this.state.errors);
        err[event.target.name] = errMsg;
        this.setState({ errors: err });
        break;
    }
  }

  _onSubmit(fields) {
    const { dispatch } = this.props;
    const { router } = this.context;
    dispatch(login(fields.username, fields.password, () => (
      router.history.push('/dashboard')
    )));
  }

  _onForgotPwd() {
    this.setState({ showForgotPwdForm: ((this.state.showForgotPwdForm == true) ? false : true) });
  }

  _onResetPassword() {
    var reqErr = "required";
    let err = Object.assign({}, this.state.errors);
    this.state.isValid = undefined;

    // Set error message on empty text boxes before submit

    if (newPassword.value == '' || newPassword.value == undefined) {
      err["newPassword"] = reqErr;
      this.setState({ errors: err });
      this.state.isValid = false;
    }
    if (confirmPassword.value == '' || confirmPassword.value == undefined) {
      err["confirmPassword"] = reqErr;
      this.setState({ errors: err });
      this.state.isValid = false;
    }
    if (newPassword.value != confirmPassword.value) {
      err["confirmPassword"] = 'password fields do not match';
      this.setState({ errors: err });
      this.state.isValid = false;
    }

    //POST information if no error
    if (this.state.isValid == undefined) {
      var resetData = {
        "Password": newPassword.value,
        "ConfirmPassword": confirmPassword.value
      }
      this.props.dispatch(EIMPasswordReset(resetData));
      this.setState({ showNotification: true });
    }

  }

  //Function to open Confirmation layer
  _onFactoryReset() {
    this.setState({ LayerOpen: true });
  }

//Function to perform Factory reset
  _onConfirmReset() {
    var resetEimData = {
      "ResetRequired": "true"
    }
    this.props.dispatch(EIMFactoryReset(resetEimData));
    this.setState({ LayerOpen: false });
  }
//Function to close comfirmation layer
  _onConfirmationClose() {
    this.setState({ LayerOpen: false });
  }
  render() {
    const { session: { error } } = this.props;
    const { redfish } = this.props; //Catch response from reducer
    this.state.eim_ipv4 = "EIM IPv4: " + this.props.eim_ipv4;
    this.state.eim_ipv6 = "EIM IPv6: " + this.props.eim_ipv6;

    var sessionTimeoutRebootMsg = window.localStorage.timeoutRebootMsg;
    if (sessionTimeoutRebootMsg != undefined) {
      try {
        window.localStorage.removeItem('username');
        window.localStorage.removeItem('name');
        window.localStorage.removeItem('token');
        window.localStorage.removeItem('location');
        window.localStorage.removeItem('registrationInProgress');
        window.localStorage.removeItem('ldap');
      }
      catch (e) {
        // ignore
      }
    }

    var resetPwdForm;
    if (this.state.showForgotPwdForm == true) {
      resetPwdForm = <Form pad='medium'>
        <FormFields>
          <FormField label='New password' error={this.state.errors['newPassword']}>
            <TextInput disabled={this.state.disabled} id='newPassword' name='newPassword' type='password' value={this.state.newPassword} onDOMChange={this._onChange} />
          </FormField>
          <FormField label='Confirm password' error={this.state.errors['confirmPassword']}>
            <TextInput disabled={this.state.disabled} id='confirmPassword' name='confirmPassword' type='password' value={this.state.confirmPassword} onDOMChange={this._onChange} />
          </FormField>
        </FormFields>
        <Box direction='row' pad={{ horizontal: 'none', vertical: 'medium', between: 'small' }}>
          <Button label='Reset password' primary={true} onClick={this._onResetPassword} />
          <Button label='EIM factory reset' primary={true} onClick={this._onFactoryReset} />
        </Box>
      </Form>
    } else {
      resetPwdForm = <Form pad='medium'>
        <Box direction='row' pad={{ horizontal: 'none', vertical: 'medium', between: 'small' }}>
          <Button label='EIM factory reset' primary={true} onClick={this._onFactoryReset} />
        </Box>
      </Form>
    }

    let layer;
    if (this.state.LayerOpen) {
      layer =
        (
          <Layer align="right" closer={true} overlayClose={true}
            onClose={this._onConfirmationClose} compact={true}>
            <Form submitLabel="EIM Factory Reset">
              <Header><Heading tag='h2'>EIM Factory Reset</Heading></Header>
              <Paragraph>Are you sure you want to do EIM Factory Reset?
              </Paragraph>
              <Box pad={{ vertical: 'small', horizontal: 'none' }} direction='row'>
                <Button label='Yes,Reset' primary={true} onClick={this._onConfirmReset} />
              </Box>
            </Form>
          </Layer>
        );
    }


    if (redfish == undefined || redfish == 'Server Unreachable') {
      return (
        <Box full={true} align='center' justify='center'>
          <BrandHpeElementOutlineIcon colorIndex='brand' size='xlarge' type='logo' />
          <Headline strong={true}>EIM Loading ...</Headline>
          <Paragraph size='large' align='center'><strong>Please wait while the system is getting ready, It may take a while.</strong></Paragraph>
        </Box>
      );
    } else {
      return (
        <Split flex='left' separator={false}>
          <Article>
            <Section
              full={true}
              colorIndex='neutral-1'
              texture='url(img/splash.png)'
              pad='large'
              justify='center'
              align='center'
              style={{ 'background-size': 'contain' }}>
            </Section>
          </Article>
          <Sidebar justify='between' align='center' pad='none' size='large'>
            <span />
            <Form>
              <LoginForm
                align='start'
                logo={<div><img src="img/mobile-app-icon.png" height="50px" width="120px" /><br /><br /></div>}
                title={<Heading strong={true} tag='h3' align='start'> Edgeline Infrastructure Manager (EIM)</Heading>}
                secondaryText={<Box><Paragraph><strong>{this.state.eim_ipv4}<br />{this.state.eim_ipv6}<br />{"EIM Application Version : "+ this.props.redfish.Oem.Hp.Manager[0].FirmwareVersion}</strong></Paragraph></Box>}
                onSubmit={this._onSubmit}
                errors={(error != undefined) ? [error] : [sessionTimeoutRebootMsg]}
                usernameType='text'
                forgotPassword={<Anchor onClick={this._onForgotPwd} label='Forgot password?' />} />
              {resetPwdForm}
              {layer}
            </Form>
            <Footer
              direction='row'
              size='small'
              pad={{ horizontal: 'medium', vertical: 'small' }}>
              <span className='secondary'>&copy; 2019 Hewlett Packard Enterprise</span>
            </Footer>
          </Sidebar>
        </Split>
      );
    }
  }
}

ConsoleLogin.defaultProps = {
  session: {
    error: undefined
  }
};

ConsoleLogin.propTypes = {
  dispatch: PropTypes.func.isRequired,
  session: PropTypes.shape({
    error: PropTypes.string
  })
};

ConsoleLogin.contextTypes = {
  router: PropTypes.object.isRequired,
};

const select = state => ({ session: state.session, ...state.redfish, ...state.consoleLoginInfo });

export default connect(select)(ConsoleLogin);
