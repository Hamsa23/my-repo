// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component } from 'react';
import { connect } from 'react-redux';
import DropdownMenu from 'react-dd-menu';

import Sidebar from 'grommet/components/Sidebar';
import Header from 'grommet/components/Header';
import Title from 'grommet/components/Title';
import Menu from 'grommet/components/Menu';
import Anchor from 'grommet/components/Anchor';
import DashboardIcon from 'grommet/components/icons/base/Dashboard';
import InspectIcon from 'grommet/components/icons/base/Inspect';
import Maintenance from 'grommet/components/icons/base/HostMaintenance';
import WorkshopIcon from 'grommet/components/icons/base/Workshop';
import DownIcon from 'grommet/components/icons/base/Down';
import Button from 'grommet/components/Button';
import CloseIcon from 'grommet/components/icons/base/Close';
import System from 'grommet/components/icons/base/System';
import Install from 'grommet/components/icons/base/Install';
import NotificationIcon from 'grommet/components/icons/base/Notification'
import LicenseIcon from 'grommet/components/icons/base/License';
import { navActivate } from '../actions/nav';

class NavSidebar extends Component {
  constructor() {
    super();
    this.state = {
        isMenuOpen: false
    };
    this.click = this.click.bind(this);
    this.toggle = this.toggle.bind(this);
    this.close = this.close.bind(this);
    this._onClose = this._onClose.bind(this);
  }

  _onClose() {
    this.props.dispatch(navActivate(false));
  }

  toggle() {
    this.setState({ isMenuOpen: !this.state.isMenuOpen });
  }

  close() {
    this.setState({ isMenuOpen: false });
  }

  click() {
  }

  render() {
    const menuOptions = {
      isOpen: this.state.isMenuOpen,
      close: this.close,
      toggle: <div onClick={this.toggle}><Anchor path="" icon={<Maintenance />}>Appliance Management&thinsp;&thinsp;&thinsp;&thinsp;</Anchor><DownIcon size="xsmall"/></div>,
      align: 'left',
      closeOnInsideClick: false,
    };

    return (
      <Sidebar colorIndex='neutral-1' fixed={true} size='medium'>
        <Header size='large' justify='between' pad={{ horizontal: 'medium' }}>
          <Title onClick={this._onClose} a11yTitle='Close Menu'>
            <div>
              <img src="img/mobile-app-icon.png" height="50px" width="120px"/>
            </div>           
          </Title>
          <Button
            icon={<CloseIcon />}
            onClick={this._onClose}
            plain={true}
            a11yTitle='Close Menu'
          />
        </Header>
        <Menu primary={true}>
        <Anchor path='/Dashboard' icon={<DashboardIcon />}>Dashboard</Anchor>
        <Anchor path='/Discovery' icon={<InspectIcon />}>Discovery & Registration</Anchor>
        <Anchor path='/FirmwareUpdate' icon={<Install />}>Firmware Update</Anchor>
        <Anchor>
      <DropdownMenu {...menuOptions}>
        <Menu primary={true}>
          <Anchor path='/NetworkConfiguration'>Network Configuration</Anchor>
          <Anchor path='/CertificateManagement'>Certificate Management</Anchor>
          <Anchor path='/UserManagement'>User Management</Anchor>
          {/* <Anchor path='/Dashboard'>LDAP Integration</Anchor> */}
          <Anchor path='/ApplianceConfiguration'>Appliance Configuration</Anchor>
          <Anchor path='/ApplianceMonitoring'>Appliance Monitoring</Anchor>
		  <Anchor path='/EventLogs'>Appliance Event Logs</Anchor>
        </Menu>
      </DropdownMenu>
      </Anchor>
      <Anchor path='/MonitoringReporting' icon={<WorkshopIcon />}> Monitoring & Reporting</Anchor>
      <Anchor path='/Logs' icon={<NotificationIcon />}>Alerts & Event Logs</Anchor>
      <Anchor path='/License' icon={<LicenseIcon />}>Licensing</Anchor>
      {/* <Anchor path='/#' icon={<TasksIcon />}>Active Tasks</Anchor> */}
    </Menu>
      </Sidebar>
    );
  }
}

const select = state => ({
  nav: state.nav
});

export default connect(select)(NavSidebar);
