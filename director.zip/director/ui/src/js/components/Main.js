// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import App from 'grommet/components/App';
import Split from 'grommet/components/Split';

import NavSidebar from './NavSidebar';
import { navResponsive } from '../actions/nav';

import Login from '../screens/Login';
import ConsoleLogin from '../screens/ConsoleLogin';
import Dashboard from '../screens/Dashboard';
import Graph from '../screens/Graph';
import Logs from '../screens/Logs';
import License from '../screens/License';
import EventLogs from '../screens/EventLogs';
import FWUpload from '../screens/FWUpload';
import Discovery from '../screens/Discovery';
import ApplianceConfiguration from '../screens/BackupRestore';
import NetworkConfiguration from '../screens/NetworkConfiguration';
import CertificateManagement from '../screens/Certificatemanagement';
import UserManagement from '../screens/UserManagement';
import NotFound from '../screens/NotFound';
import MonitoringReporting from '../screens/MonitoringReporting';
class Main extends Component {
  constructor() {
    super();
    this._onResponsive = this._onResponsive.bind(this);
  }

  _onResponsive(responsive) {
    this.props.dispatch(navResponsive(responsive));
  }

  render() {
    const {
      nav: { active: navActive, enabled: navEnabled, responsive }
    } = this.props;
    const includeNav = (navActive && navEnabled);
    let nav;
    if (includeNav) {
      nav = <NavSidebar />;
    }
    const priority = (includeNav && responsive === 'single' ? 'left' : 'right');

    return (
      <App centered={false}>
        <Router>
          <Split
            priority={priority}
            flex='right'
            onResponsive={this._onResponsive}
          >
            {nav}
            <Switch>
              <Route exact={true} path='/' component={Login} />
              <Route path='/Dashboard' component={Dashboard} />
              <Route path='/Login' component={Login} />
              <Route path='/Consolelogin' component={ConsoleLogin} />
              <Route path='/ApplianceMonitoring' component={Graph} />
              <Route path='/Monitoring&Reporting' component={Graph} />
              <Route path='/MonitoringReporting' component={MonitoringReporting} />
              <Route path='/FirmwareUpdate' component={FWUpload} />
              <Route path='/Discovery' component={Discovery} />
              <Route path='/Logs' component={Logs} />
              <Route path='/License' component={License} />
			        <Route path='/EventLogs' component={EventLogs} />
              <Route path='/ApplianceConfiguration' component={ApplianceConfiguration} />
              <Route path='/NetworkConfiguration' component={NetworkConfiguration} />
              <Route path='/CertificateManagement' component={CertificateManagement} />
              <Route path='/UserManagement' component={UserManagement} />
              <Route path='/*' component={NotFound} />
            </Switch>
          </Split>
        </Router>
      </App>
    );
  }
}

Main.defaultProps = {
  nav: {
    active: true, // start with nav active
    enabled: true, // start with nav disabled
    responsive: 'multiple'
  }
};

Main.propTypes = {
  dispatch: PropTypes.func.isRequired,
  nav: PropTypes.shape({
    active: PropTypes.bool,
    enabled: PropTypes.bool,
    responsive: PropTypes.string
  })
};

const select = state => ({
  nav: state.nav
});

export default connect(select)(Main);
