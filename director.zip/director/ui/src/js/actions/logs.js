// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { IEL_LOAD, IEL_UNLOAD, IEL_LOAD_FAILURE, IML_LOAD, IML_LOAD_FAILURE, IML_UNLOAD, IEL_LOGS_DELETE, IEL_LOGS_DELETE_FAILURE, IML_LOGS_DELETE, IML_LOGS_DELETE_FAILURE } from '../actions';
import { EventLogs, IMLogs, DeleteIELlogs, DeleteIMLlogs } from '../api/logs';

export function loadIELData(target, pageNum) {
  return dispatch => (
    EventLogs(target, pageNum)
      .then((payload) => {
        dispatch({ type: IEL_LOAD, payload })
      })
      .catch(payload => dispatch({
        type: IEL_LOAD_FAILURE,
        error: true,
        payload: payload.status
      }))
  )
};

export function unloadIELData() {
  return { type: IEL_UNLOAD };
}

export function loadIMLData(target, pageNum) {
  return dispatch => (
    IMLogs(target, pageNum)
      .then((payload) => {
        dispatch({ type: IML_LOAD, payload })
      })
      .catch(payload => dispatch({
        type: IML_LOAD_FAILURE,
        error: true,
        payload: payload.status
      }))
  )
};


export function unloadIMLData() {
  return { type: IML_UNLOAD };
}

export function del_IELData(target, body) {
  return dispatch => (
    DeleteIELlogs(target, body)
      .then((payload) => {
        dispatch({ type: IEL_LOGS_DELETE, payload })
        dispatch(loadIELData(target));
      })
      .catch(payload => dispatch({
        type: IEL_LOGS_DELETE_FAILURE,
        error: true,
        payload: payload.status

      }))
  );
};

export function del_IMLData(target, body) {
  return dispatch => (
    DeleteIMLlogs(target, body)
      .then((payload) => {
        dispatch({ type: IML_LOGS_DELETE, payload })
        dispatch(loadIMLData(target));
      })
      .catch(payload => dispatch({
        type: IML_LOGS_DELETE_FAILURE,
        error: true,
        payload: payload.status

      }))
  );
};
