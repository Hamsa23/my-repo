// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {NTP_LOAD, NTP_SETTING,NTP_SETTING_FAILURE} from '../actions';
import {EsmUri} from '../api/utils';
import {NtpPost} from '../api/ntpsettings';

//Performing Get operation
export function Ntp() {
  return dispatch => {
    const uri= EsmUri() + 'NtpConf';
    let auth1 = window.localStorage.getItem('token');
    let head = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': auth1
    };
    const payload = { method: 'GET', headers: head};

    //Perform get request
    return fetch(uri, payload)
      .then(payload => payload.json())
      .then((payload) => {
        dispatch({ type: NTP_LOAD, payload })}
      )
  };
}

//Performing post from API file
export function NtpConf(ntpdata) {
  return dispatch => (
    NtpPost(ntpdata)
      .then((payload) => {
        dispatch({ type: NTP_SETTING,
          payload: {
            statusCode: payload
          }
        });
      })
      .catch(payload => {
        dispatch({
          type: NTP_SETTING_FAILURE,
          error: true,
          payload: {
            statusCode: payload
          }
        })}
      )
  );
};
