// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
  NAV_ACTIVATE, NAV_ENABLE, NAV_RESPONSIVE, NAV_GRAPH, NAV_FWUPDATE, NAV_LOGS, NAV_DISCOVERY
} from '../actions';

export function navActivate(active) {
  return { type: NAV_ACTIVATE, active };
}

export function navEnable(enabled) {
  return { type: NAV_ENABLE, enabled };
}

export function navResponsive(responsive) {
  return { type: NAV_RESPONSIVE, responsive };
}

export function navGraph(graph) {
  return { type: NAV_GRAPH, graph };
}

export function navFwupdate(fwupdate) {
  return { type: NAV_FWUPDATE, fwupdate };
}

export function navDiscovery(discovery) {
  return { type: NAV_DISCOVERY, discovery };
}

export function navLogs(logs) {
  return { type: NAV_LOGS, logs };
}

export function navUsermanagement(usermanagement) {
  return { type: NAV_USERMANAGEMENT, usermanagement };
}
