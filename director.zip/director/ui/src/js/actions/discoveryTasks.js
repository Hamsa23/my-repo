// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { DISCOVERY_TASKS_LOAD, DISCOVERY_TASKS_FAILURE, DISCOVERY_TASKS_DELETE, DISCOVERY_TASKS_DELETE_FAILURE, DISCOVERY_TASKS_UNLOAD } from '../actions';
import {DiscoveryTasks, DelTask} from '../api/discoveryTasks';

export function loadDiscoveryTasks() {
    return dispatch => (
        DiscoveryTasks()
        .then((payload) => {
            dispatch({ type: DISCOVERY_TASKS_LOAD, payload })
        })
        .catch(payload => dispatch({
            type: DISCOVERY_TASKS_FAILURE,
            error: true,
            payload: payload.status
        }))
    )
}

export function deleteTasks(deleteTask) {
    return dispatch => (
        DelTask(deleteTask)
        .then((payload) => {
            dispatch({ type: DISCOVERY_TASKS_DELETE, payload })
            dispatch(loadDiscoveryTasks());
        })
        .catch(payload => dispatch({
            type: DISCOVERY_TASKS_DELETE_FAILURE,
            error: true,
            payload: payload
        }))
    );
}

export function unloadTasks() {
    return dispatch => (
        dispatch({ type: DISCOVERY_TASKS_UNLOAD })
    );
}
