// (C) Copyright 2019 Hewlett Packard Enterprise Development LP


import * as index from '../actions';
import { sendRedfishAPIRequest } from '../api/redfishAPIRequest';

/*
  parm1: Redfish api methord
  parm2: url
  parm3: input payload for POST and PATCH 
*/
export function sendRedfishActionRequest(apiMethord, uri, inPayload) {  
    return dispatch => (
      sendRedfishAPIRequest(apiMethord, uri, inPayload)
      .then((payload) => {
        dispatch({ type: index.API_SUCCESS, payload })
     })
     .catch(payload => dispatch({
      type:  index.API_ERROR,
      error: true,
      payload: {
        statusCode: payload
      }
    }))
    )
  };

  