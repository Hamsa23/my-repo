// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { CHASSIS_FAILURE, CHASSIS_LOAD, TARGET_POWER_FAILURE, TARGET_POWER_LOAD, TARGET_THERMAL_FAILURE, TARGET_THERMAL_LOAD, UNLOAD_MONITORING_DATA } from '.';
import {getChassisList, getPowerReport, getThermalReport } from '../api/moniteringtarget';

export function getRegisteredChassis() {
  return dispatch => (
    getChassisList()
    .then((payload) => {
      dispatch({ type: CHASSIS_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: CHASSIS_FAILURE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function getTargetPowerReport(ChassisIdx) {
  return dispatch => (
    getPowerReport(ChassisIdx)
    .then((payload) => {
      dispatch({ type: TARGET_POWER_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: TARGET_THERMAL_FAILURE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function getTargetThermalReport(ChassisIdx) {
  return dispatch => (
    getThermalReport(ChassisIdx)
    .then((payload) => {
      dispatch({ type: TARGET_THERMAL_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: TARGET_THERMAL_LOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function unloadMonitoringData() {
  return dispatch => (
    dispatch({ type: UNLOAD_MONITORING_DATA })
  );
}

