// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {LICENSE_LOAD, LICENSE_LOAD_FAILURE, LICENSE_UPLOAD, LICENSE_UPLOAD_FAILURE, DELETE_LICENSE, DELETE_LICENSE_FAILURE, UNLOAD_LICENSE, LICENSE_UUID, LICENSE_UUID_FAILURE} from '../actions';
import {loadLicense, uploadLicense, deleteLicense, loadSysUuid} from '../api/license';

export function LoadLicense() {
    return dispatch => (
      loadLicense()//accessing function from API call file
        .then((payload) => {
          dispatch({ type: LICENSE_LOAD, payload })
        })
        .catch(payload => dispatch({
          type: LICENSE_LOAD_FAILURE,
          error: true,
          payload: payload
        }))
    );
}

export function UploadLicense(file) {
    return dispatch => (
        uploadLicense(file)//accessing function from API call file
        .then((payload) => {
            dispatch({ type: LICENSE_UPLOAD, payload })
            dispatch(LoadLicense());
        })
        .catch(payload => dispatch({
            type: LICENSE_UPLOAD_FAILURE,
            error: true,
            payload: payload
        }))
    );
}

export function DeleteLicense(licenseId) {
    return dispatch => (
        deleteLicense(licenseId)//accessing function from API call file
        .then((payload) => {
            dispatch({ type: DELETE_LICENSE, payload })
            dispatch(LoadLicense());
        })
        .catch(payload => dispatch({
            type: DELETE_LICENSE_FAILURE,
            error: true,
            payload: payload
        }))
    );
}

export function UnloadLicense() {
    return dispatch => (
        dispatch({ type: UNLOAD_LICENSE })
    );
}

export function LoadSysUuid() {
    return dispatch => (
        loadSysUuid()//accessing function from API call file
        .then((payload) => {
          dispatch({ type: LICENSE_UUID, payload })
        })
        .catch(payload => dispatch({
          type: LICENSE_UUID_FAILURE,
          error: true,
          payload: payload
        }))
    );
}