// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { EVENTLOG_LOAD, EVENTLOG_FAILURE, EVENTLOG_UNLOAD } from '../actions';
import { EventLogs } from '../api/eventlogs';

export function loadEventLogs() {
    return dispatch => (
      EventLogs()
      .then((payload) => {
        dispatch({ type: EVENTLOG_LOAD, payload })
     })
     .catch(payload => dispatch({
      type: EVENTLOG_FAILURE,
      error: true,
      payload: {
        statusCode: payload
      }
    }))
    )
  };

  