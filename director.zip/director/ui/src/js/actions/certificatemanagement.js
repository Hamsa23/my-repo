// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {CERTIFICATE_LOAD} from '../actions';
import {ImportCertificate} from '../api/certificatemanagement';
export function Certificate(certfile, keyfile) {
  return dispatch => (
    ImportCertificate(certfile, keyfile)//accessing function from API call file
      .then((payload) => {
        dispatch({ type: CERTIFICATE_LOAD, payload })
      })
      .catch(payload => dispatch({
        type: CERTIFICATE_LOAD,
        error: true,
        payload: payload
      }))
  );
}


    
    