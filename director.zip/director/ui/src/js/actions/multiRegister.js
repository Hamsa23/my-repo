// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {REGISTER_SUCCESS, REGISTER_FAILURE} from '../actions';
import {RegisterPost} from '../api/multiRegister';

export function RegConf(regData) {
    return dispatch => (
        RegisterPost(regData)
        .then((payload) => {
        dispatch({ type: REGISTER_SUCCESS, payload })
        })
        .catch(payload => dispatch({
          type: REGISTER_FAILURE,
          error: true,
          payload: payload
        }))
    );
}
