// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {SYSTEM_REGISTER_SUCCESS, SYSTEM_REGISTER_FAILURE} from '../actions';
import {loadDashboard} from '../actions/dashboard';
import {RegisterSystem} from '../api/systemRegister';

export function RegServer(regData) {
  return dispatch => (
      RegisterSystem(regData)
      .then((payload) => {
        dispatch({ type: SYSTEM_REGISTER_SUCCESS, payload })
        dispatch(loadDashboard());
      })
      .catch(payload => dispatch({
        type: SYSTEM_REGISTER_FAILURE,
        error: true,
        payload: payload
      }))
  );
}

