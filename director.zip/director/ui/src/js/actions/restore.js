// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {RESTORE_LOAD, RESTORE_FAILURE} from '../actions';
import {Restore} from '../api/restore';

//Performing post from API file
export function RestoreFile(file) {
  return dispatch => (
    Restore (file)
      .then((payload) => {
        dispatch({ type: RESTORE_LOAD,
          payload: {
            statusCode: payload
          }
        });
      })
      .catch(payload => {
        dispatch({
          type: RESTORE_FAILURE,
          error: true,
          payload: {
            statusCode: payload
          }
        })}
      )
  );
};
