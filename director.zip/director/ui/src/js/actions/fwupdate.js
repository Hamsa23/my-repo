// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { FWBUNDLE_LOAD, FWFLASH, FWCONFIGUPLOAD, FWID, FWPROFILE, DELFWPROFILE } from '../actions';
import { FWBundleList, FWUpdateRequest, UploadConfigurationFile, GetFWIDInfo, GetFWProfileInfo, DeleteProfileInfo } from '../api/fwupdate';

export function GetFWBundleList() {
  return dispatch => (
    FWBundleList()
    .then((payload) => {
      dispatch({ type: FWBUNDLE_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: FWBUNDLE_LOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function SubmitFWRequest(body) {
  return dispatch => (
    FWUpdateRequest(body)
      .then((payload) =>
      {
        dispatch({ type: FWFLASH, 
          payload: {
            statusCode: payload
          }
        });
    })
      .catch(payload => dispatch({
        type: FWFLASH,
        error: true,
        payload: {
          statusCode: payload
        }
      }))
  );
};

export function UploadConfigFile(file, val) {
  return dispatch => (
    UploadConfigurationFile (file, val)
      .then((payload) => {
        dispatch({ type: FWCONFIGUPLOAD, payload: { statusCode: payload }});
        dispatch(GetFWBundleList());
      })
      .catch(payload => {
        dispatch({
          type: FWCONFIGUPLOAD,
          error: true,
          payload: {
            statusCode: payload
          }
        })}
      )
  );
};

export function GetFWID() {
  return dispatch => (
    GetFWIDInfo()
    .then((payload) => {
      dispatch({ type: FWID, payload })
   })
   .catch(payload => dispatch({
    type: FWID,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};


export function GetFWProfile() {
  return dispatch => (
    GetFWProfileInfo()
    .then((payload) => {
      dispatch({ type: FWPROFILE, payload });
   })
   .catch(payload => dispatch({
    type: FWPROFILE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function DeleteProfile(profilelist) {
  return dispatch => (
    DeleteProfileInfo(profilelist)
    .then((payload) => {
      dispatch({ type: DELFWPROFILE, payload });
      dispatch(GetFWBundleList());
   })
   .catch(payload => dispatch({
    type: DELFWPROFILE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};