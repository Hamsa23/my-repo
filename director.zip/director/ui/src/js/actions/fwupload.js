// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {NAVFWPROFILE, NAVBUNDLE_LOAD, NAV_FWULOAD, NAVFWDELETE} from '../actions';

import {firmwareupload, FWBundleList,   GetFWProfileInfo , DelFW} from '../api/fwupload';

export function FWUploadEvent(file) {
  return dispatch => (
    firmwareupload(file)//accessing function from API call file

      .then((payload) => {
        dispatch({ type: NAV_FWULOAD, payload: {statusCode: payload}});
        dispatch(GetFWBundleList());
        dispatch(GetFWProfile());
      })

      .catch(payload => dispatch({
        type: NAV_FWULOAD,
        error: true,
        payload: {
      statusCode: payload
    }
      }))

  );

};

export function GetFWBundleList() {
  return dispatch => (
    FWBundleList()
    .then((payload) => {
      dispatch({ type: NAVBUNDLE_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: NAVBUNDLE_LOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};


export function GetFWProfile() {
  return dispatch => (
    GetFWProfileInfo()
    .then((payload) => {
      dispatch({ type: NAVFWPROFILE, payload })
   })
   .catch(payload => dispatch({
    type: NAVFWPROFILE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};


export function Delfirmwarebundle(profilelist, firmwarelist) {
  return dispatch => (
    DelFW(profilelist, firmwarelist)
    .then((payload) => {
      dispatch({ type: NAVFWDELETE, payload })
      dispatch(GetFWBundleList());
      dispatch(GetFWProfile());
   })
   .catch(payload => dispatch({
    type: NAVFWDELETE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};
