// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { GRAPH_LOAD, GRAPH_UNLOAD, GRAPH_LOAD_FAILURE } from '../actions';
import { Graph } from '../api/graph';

export function loadGraph() {
  return dispatch => (
    Graph()
    .then((payload) => {
      dispatch({ type: GRAPH_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: GRAPH_LOAD_FAILURE,
    error: true,
    payload: payload.status
  }))
  )
}

export function unloadGraph() {
  return { type: GRAPH_UNLOAD };
}
