// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {ResetPassword, FactoryResetEIM, GetIPaddress} from '../api/consoleLogin';
import {IPADDRESS_LOAD} from '../actions';

export function EIMPasswordReset(passwordData) {
    return dispatch => (
        ResetPassword(passwordData)
        .then((payload) => {
            try {
                return response;
            } catch (e) {
            }
            done();
        })
        .catch(payload => dispatch({
            error: true,
            payload: payload
        }))
    );
}

export function EIMFactoryReset(resetData) {
    return dispatch => (
        FactoryResetEIM(resetData)
        .then((payload) => {
            try {
                return response;
            } catch (e) {
            }
            done();
        })
        .catch(payload => dispatch({
            error: true,
            payload: payload
        }))
    );
}

export function getIPaddress() {
    return dispatch => (
        GetIPaddress()
        .then((payload) => {
            dispatch({ type: IPADDRESS_LOAD, payload })
        })
        .catch(payload => dispatch({
            error: true,
            payload: payload.status
        }))
    );
}
