// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {  NETWORK_LOAD, NETWORK_LOAD_FAILURE, NETWORK_UNLOAD } from '../actions';
import { Network, updateNetworkSettings } from '../api/network';


export function loadNetwork() {
  return dispatch => (
    Network()
    .then((payload) => {
      dispatch({ type: NETWORK_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: NETWORK_LOAD_FAILURE,
    error: true,
    payload: payload.status
  }))
  )
};

export function loadNetworkSuccess(payload){
  return { type: NETWORK_LOAD, payload: payload };
}

export function loadNetworkFailure(error){
  return {type: NETWORK_LOAD_FAILURE, error: error};
}

export function unloadNetwork() {
  return { type: NETWORK_UNLOAD };
}

export function changeNetworkSettings(networkSettings) {
  return dispatch => (
    updateNetworkSettings(networkSettings)
    .then((payload) => {
      dispatch({ type: NETWORK_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: NETWORK_LOAD_FAILURE,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
}
