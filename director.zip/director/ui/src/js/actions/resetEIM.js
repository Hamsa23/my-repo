// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { Eimboot } from '../api/resetEIM';

export function ResetEIMConfig(resetdata, done) {
    return dispatch => (
      Eimboot(resetdata)
        .then((payload) => {
          try {
            return response;
          } catch (e) {
          }
          done();
        })
        .catch(payload => dispatch({
          error: true,
          payload: payload
        }))
    );
  }