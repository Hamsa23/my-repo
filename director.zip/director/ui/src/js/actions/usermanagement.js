
// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { USERMANAGEMENT_LOAD, USERMANAGEMENT_UNLOAD, SINGLEUSER_LOAD, SINGLEUSER_DELETE, USER_ADD, EDITUSER } from '../actions';
import { UserManagement, postAddUser, getSingleUser, postEditUser, DelSingleUser } from '../api/usermanagement';

export function loadusermanagement() {
  return dispatch => (
    UserManagement()
    .then((payload) => {
      dispatch({ type: USERMANAGEMENT_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: USERMANAGEMENT_UNLOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function loadSingleUser(info) {
  return dispatch => (
    getSingleUser(info)
    .then((payload) => {
      dispatch({ type: SINGLEUSER_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: USERMANAGEMENT_UNLOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function DeleteSingleUser(info) {
  return dispatch => (
    DelSingleUser(info)
    .then((payload) => {
      dispatch({ type: SINGLEUSER_DELETE, payload: { statusCode: payload }});
      dispatch(loadusermanagement());
    })
    .catch(payload => dispatch({
      type: SINGLEUSER_DELETE,
      error: true,
      payload: {
        statusCode: payload
      }
    }))
);
};

export function submitAddUser(body) {
  return dispatch => (
    postAddUser(body)
      .then((payload) => {
        dispatch({ type: USER_ADD, payload: { statusCode: payload }});
        dispatch(loadusermanagement());
    })
      .catch(payload => dispatch({
        type: USER_ADD,
        error: true,
        payload: {
          statusCode: payload
        }
      }))
  );
};

export function submitEditUser(id, body) {
  return dispatch => (
    postEditUser(id, body)
    .then((payload) => {
      dispatch({ type: EDITUSER, payload: { statusCode: payload }}),
      dispatch(loadusermanagement());
    })
    .catch(payload => dispatch({
      type: EDITUSER,
      error: true,
      payload: {
        statusCode: payload
      }
    }))
);
};