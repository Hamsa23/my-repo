// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {SYSTEM_UNREGISTER_SUCCESS, SYSTEM_UNREGISTER_FAILURE} from '../actions';
import {loadDashboard} from './dashboard';
import {UnRegisterMultipleSystem} from '../api/discovery';

export function UnRegSystems(unRegData) {
  return dispatch => (
    UnRegisterMultipleSystem(unRegData)
    .then((payload) => {
    dispatch({ type: SYSTEM_UNREGISTER_SUCCESS, payload })
    dispatch(loadDashboard());
    })
    .catch(payload => dispatch({
      type: SYSTEM_UNREGISTER_FAILURE,
      error: true,
      payload: payload
    }))
);
}
