// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { BACKUP_LOAD} from '../actions';
import {Backup, SupportDump} from '../api/backuprestore';

export function Download(file) {
  return dispatch => (
    Backup(file)
    .then((payload) => {
      const data = JSON.stringify(payload)
      var blob=new Blob([data]);
      var link=document.createElement('a');
      link.href=window.URL.createObjectURL(blob);
      link.download="eim.json";
      link.click();
    })
      
  )
};

export function DownloadSupportDump(file){
  return dispatch => (
    SupportDump(file)
    .then((payload) => {
      const data = JSON.stringify(payload);
      var blob=new Blob([payload]);
      var link=document.createElement('a');
      link.href=window.URL.createObjectURL(blob);
      link.download="supportdump.zip";
      link.click();
    })   
  )
}