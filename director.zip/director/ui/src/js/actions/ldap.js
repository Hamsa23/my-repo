// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { LDAP_LOAD, LDAP_UNLOAD } from '../actions';
import { GetLDAPInfo, PostLDAPInfo, TestLDAPInfo } from '../api/ldap';

export function GetLdap() {
  return dispatch => (
    GetLDAPInfo()
    .then((payload) => {
      dispatch({ type: LDAP_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: LDAP_UNLOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function SubmitLdap(body) {
  return dispatch => (
    PostLDAPInfo(body)
      .then((payload) => {
        dispatch({ type: LDAP_UNLOAD, 
          payload: {
            statusCode: payload
          }
        });
    })
      .catch(payload => {
        dispatch({
        type: LDAP_UNLOAD,
        error: true,
        payload: {
          statusCode: payload
        }
      })}
      )
  );
};

export function TestLdap() {
  return dispatch => (
    TestLDAPInfo()
      .then((payload) => {
        dispatch({ type: LDAP_UNLOAD, 
          payload: {
            statusCode: payload
          }
        });
    })
      .catch(payload => {
        dispatch({
        type: LDAP_UNLOAD,
        error: true,
        payload: {
          statusCode: payload
        }
      })}
      )
  );
};
