// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { SESSION_LOAD, SESSION_LOGIN, SESSION_LOGOUT, REDFISH_LOAD } from '../actions';
import { deleteSession, postSession, getRedfish } from '../api/session';
import { updateHeaders } from '../api/utils';

const localStorage = window.localStorage;

export function initialize() {
  return (dispatch) => {
    const { username, name, token, location } = localStorage;
    let authtoken = window.localStorage.getItem('token');
    if (username && token) {
      dispatch({
        type: SESSION_LOAD, payload: { username, name, token, location }
      });
    }
    if((authtoken === undefined || authtoken === null) && window.location.pathname != '/Consolelogin'){
      window.location = '/login';
    }
  };
}

export function redfish() {
  return dispatch => (
    getRedfish()
    .then((payload) => {
      dispatch({ type: REDFISH_LOAD, payload })
   })
   .catch(payload => dispatch({
    type: REDFISH_LOAD,
    error: true,
    payload: {
      statusCode: payload
    }
  }))
  )
};

export function login(username, password, done) {
  if( localStorage.timeoutRebootMsg != undefined ) {
    localStorage.removeItem('timeoutRebootMsg');
  }	
  return dispatch => (
    postSession(username, password)
      .then((payload) => {
        try {
          localStorage.name = username;
          localStorage.token = payload.headers.get('x-auth-token');//payload.token;
		      localStorage.location = payload.headers.get('location');
          localStorage.location = (localStorage.location.substring(localStorage.location.lastIndexOf('/'))).replace('/','');
          localStorage.ldap = payload.headers.get('Is-Ldap');
          
        } catch (e) {
          alert(
            'Unable to preserve session, probably due to being in private ' +
            'browsing mode.'
          );
        }
        done();
      })
      .catch(payload => dispatch({
        type: SESSION_LOGIN,
        error: true,
        payload: {
          statusCode: payload
        }
      }))
  );
}

export function logout(session) {
  return (dispatch) => {
    dispatch({ type: SESSION_LOGOUT });
    deleteSession(session);
    updateHeaders({ Auth: undefined });
    try {
      localStorage.removeItem('username');
      localStorage.removeItem('name');
      localStorage.removeItem('token');
      localStorage.removeItem('location');
      localStorage.removeItem('registrationInProgress');
      localStorage.removeItem('ldap');
    } catch (e) {
      // ignore
    }
    // reload fully
    if (window.location.host == '127.0.0.1'){
      window.location.href = '/Consolelogin'
    } else {
      window.location.href = '/login'; 
    }
  };
}
