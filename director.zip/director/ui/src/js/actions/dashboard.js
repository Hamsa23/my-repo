// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { DASHBOARD_LOAD, DASHBOARD_UNLOAD, DASHBOARD_FAILURE, CHANGE_STATE, CHANGESTATE_FAILURE} from '../actions';
import { Dashboard, Changestate } from '../api/dashboard';

export function loadDashboard() {
  return dispatch => (
    Dashboard()
    .then((payload) => {
      dispatch({ type: DASHBOARD_LOAD, payload })
   })
   .catch(payload =>
     dispatch({
    type: DASHBOARD_FAILURE,
    error: true,
    payload: payload.status
  }))
  )
};


export function unloadDashboard() {
  return { type: DASHBOARD_UNLOAD };
}

export function changePowerState(value,name) {
  return dispatch => (
    Changestate(value,name)
      .then((payload) => {
        dispatch({ type: CHANGE_STATE, payload });
    })
      .catch(payload => dispatch({
        type: CHANGESTATE_FAILURE,
        error: true,
        payload
      }))
  );
};