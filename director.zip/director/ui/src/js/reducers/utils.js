// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { getTimeoutMsg } from '../api/utils';

export function createReducer(initialState, handlers) {
  let sessionExpiryFlag = false;
  return (state = initialState, action) => {
	if( action.type != "REDFISH_LOAD"  && action.type != "SESSION_LOGIN"  &&  action.payload != undefined && action.error == true ) {
      if( action.payload.statusCode != undefined &&  ( action.payload.statusCode.status == 401 || action.payload.statusCode == 401 )) {
        sessionExpiryFlag = true;
      }
      else if( action.payload.status == 401 || action.payload == 401 ) {
        sessionExpiryFlag = true;
      }
      else {
        //ignore
      }

      if( sessionExpiryFlag == true ) {
          window.localStorage.timeoutRebootMsg = getTimeoutMsg();
          if (window.location.host == '127.0.0.1'){
            window.location.href = '/Consolelogin'
          } else {
            window.location.href = '/login'; 
          }
          return state;
      } 
    }
	
    const handler = handlers[action.type];
    if (!handler) return state;
    return { ...state, ...handler(state, action) };
  };
}

export default { createReducer };
