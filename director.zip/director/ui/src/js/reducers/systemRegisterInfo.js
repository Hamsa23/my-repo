// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { SYSTEM_REGISTER_SUCCESS, SYSTEM_REGISTER_FAILURE } from '../actions';
import { createReducer } from './utils';

const initialState = {
    systemRegResp: undefined,
    systemRegErr: undefined,
    toggle: undefined
};

const handlers = {

    [SYSTEM_REGISTER_SUCCESS]: (state, action) => {
        window.localStorage.registrationInProgress = "false";
        return {
            systemRegResp: action.payload,
            systemRegErr: undefined,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [SYSTEM_REGISTER_FAILURE]: (state, action) => {
        var message;
        window.localStorage.registrationInProgress = "false";
        if (action.payload.status == 202) {
            message = "Server is already registered";
        } else if (action.payload.status == 403) {
            message = "Failed to authenticate";
        } else if (action.payload == 'TypeError: Failed to fetch'){ // Validate 504
            message = "Unable to get response due to network or iLO non responsive";
        } else {
            message = "Failed to discover and register";
        }
        return {
            systemRegResp: undefined,
            systemRegErr: message,
            toggle: (state.toggle == true) ? false : true
        };
    }
};

export default createReducer(initialState, handlers);