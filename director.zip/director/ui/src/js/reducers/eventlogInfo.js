// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { EVENTLOG_LOAD, EVENTLOG_FAILURE, EVENTLOG_UNLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
    IP: undefined,
    URI: undefined,
    MessageId: undefined,
    MessageArgs: undefined,
    TimeStamp: undefined,
    eventlog: [],
    sessionError: undefined

  };


//Get all event logs for appliance
const handlers = {
  [EVENTLOG_LOAD]: (state, action) => {
    if (!action.error) {
      let eventlog = []

      if (action.payload != undefined) {
        var ip, uri, timestamp, msgid, msgArgs, tmpMsg, tmpMsgArgs;
        Object.keys(action.payload.Members).map(function (key) {
          if (action.payload.Members[key] != undefined) {
            ip = action.payload.Members[key].IP;
            uri = action.payload.Members[key].URI;
            timestamp = action.payload.Members[key].TimeStamp;
            //Removing milliseconds from timestamp
            timestamp = timestamp.slice(0, timestamp.lastIndexOf('.'));

            Object.keys(action.payload.Members[key]).map(function (key1) {
              if (key1 == "EventData" && action.payload.Members[key][key1] != undefined) {
                Object.keys(action.payload.Members[key][key1].Events).map(function (key2) {
                  if (action.payload.Members[key][key1].Events[key2] != undefined) {
                  //In the api response, "MessageId" is the attribute for iLOs and "Message" for iSM(EL300)
                    tmpMsg = action.payload.Members[key][key1].Events[key2].MessageId;
                    msgid = (tmpMsg != undefined) ? (tmpMsg) : (action.payload.Members[key][key1].Events[key2].Message);
                    if( action.payload.Members[key][key1].Events[key2].MessageArgs != undefined ) {
                    //In the api response, MessageArgs is defined as Array for iLOs and as string for iSM(EL300)
                      tmpMsgArgs = action.payload.Members[key][key1].Events[key2].MessageArgs;
                      msgArgs = (Array.isArray(tmpMsgArgs)) ? (tmpMsgArgs.join()) : (tmpMsgArgs);
                    }
                  }
                });
              }
            });

            eventlog.push({
              IP: ip,
              URI: uri,
              TimeStamp: timestamp,
              MessageId: msgid,
              MessageArgs: msgArgs
            })
          }
        });

        return {eventlog};
      }
    }
  },

  [EVENTLOG_FAILURE]: (state, action) => {
    var message;
    if (action.payload >= '404') {
      message = "Failed to load Appliance Event logs";
    }
    return { sessionError: message };
  },

  [EVENTLOG_UNLOAD]: () => initialState
};

export default createReducer(initialState, handlers);
