// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { combineReducers } from 'redux';
import redfish from './redfish';
import dashboardInfo from './dashboardInfo';
import discoveryInfo from './discoveryInfo';
import systemRegisterInfo from './systemRegisterInfo';
import multiRegisterInfo from './multiRegisterInfo';
import discoveryTasksInfo from './discoveryTasksInfo';
import nav from './nav';
import session from './session';
import restore from './restore';
import usermanagement from './usermanagement';
import networkInfo from './networkInfo';
import ntpsettings from './ntpsettings';
import certificatemanagement from './certificatemanagement';
import ldap from './ldap';
import graphInfo from './graphInfo';
import moniteringtarget from  './moniteringtarget';
import logInfo from './logInfo';
import firmware from './fwupdate';
import fwupload from './fwupload';
import eventlogInfo from './eventlogInfo';
import firmwareupdate from './fwupdate';
import FWConfigUpload from './FWConfigUpload';
import FWStatus from './FWStatus';
import FWProfile from './FWProfile';
import licenseInfo from './licenseInfo';
import fwfirmwarelist from './fwfirmwarelist';
import redfishReducers from './redfishReducers';
import consoleLoginInfo from './consoleLoginInfo';

export default combineReducers({
  redfish,
  dashboardInfo,
  discoveryInfo,
  systemRegisterInfo,
  multiRegisterInfo,
  discoveryTasksInfo,
  nav,
  session,
  restore,
  usermanagement,
  networkInfo,
  ntpsettings,
  certificatemanagement,
  ldap,
  graphInfo,
  logInfo,
  firmware,
  fwupload,
  moniteringtarget,
  eventlogInfo,
  firmwareupdate,
  FWConfigUpload,
  FWStatus,
  FWProfile,
  licenseInfo,
  fwfirmwarelist,
  consoleLoginInfo,
  redfishReducers
});
