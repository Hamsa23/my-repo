// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { RESTORE_FAILURE, RESTORE_LOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
  error: undefined
};

const handlers = {
  [RESTORE_LOAD]: (state, action) => {
    return { configUpdate: action.payload };
  },

  [RESTORE_FAILURE]: (state, action) => {
    if (!action.error) {
      return { err: action.payload.statusCode.message };
    } else if (action.payload.statusCode == 406) {
      return { err: 'Unable to connect EIM.' };
    } else if (action.payload.statusCode == 500) {
      return { err: 'Internal Server Error' };
    } else {
      return { err: 'Unable to restore the Appliance configuration json file.' };
    }
  }

};

export default createReducer(initialState, handlers);

