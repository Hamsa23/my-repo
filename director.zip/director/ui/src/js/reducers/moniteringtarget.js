// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { CHASSIS_FAILURE, CHASSIS_LOAD, TARGET_POWER_FAILURE, TARGET_POWER_LOAD, TARGET_THERMAL_FAILURE, TARGET_THERMAL_LOAD, UNLOAD_MONITORING_DATA } from '../actions';
import { createReducer } from './utils';

const initialState = {
  chassisData: undefined,
  powerData: undefined,
  thermalData: undefined,
  dashboardError: undefined,
  thermalError: undefined,
  powerError: undefined

};

//Get all users
const handlers = {
  
  [CHASSIS_LOAD]: (state, action) => {
    if (!action.error) {        
     return { chassisData: action.payload };
    }
  },  
  [CHASSIS_FAILURE]: (state, action) => {
    return { dashboardError: action.erroe };
  },

  [TARGET_POWER_LOAD]: (state, action) => {
    if (!action.error) {        
      return { powerData: action.payload };
    }   
  },
  [TARGET_POWER_FAILURE]: (state, action) => {
    return { powerError: action.payload };
  },

  [TARGET_THERMAL_LOAD]: (state, action) => {
    if (!action.error) {       
      return { thermalData: action.payload };
     }     
  },
  [TARGET_THERMAL_FAILURE]: (state, action) => {
    return { thermalError: 'Failed to load users' };
  },
  [UNLOAD_MONITORING_DATA]: () => initialState
};

export default createReducer(initialState, handlers);
