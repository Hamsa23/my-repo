// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { REDFISH_LOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
  error: undefined
};

const handlers = {
  [REDFISH_LOAD]: (state, action) => {
      if (!action.error) {
        return {redfish : action.payload};
      }
      else return { redfish: 'Server Unreachable' };
    }
};

export default createReducer(initialState, handlers);

