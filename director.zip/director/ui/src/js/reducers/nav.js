// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
  NAV_ACTIVATE, NAV_ENABLE, NAV_RESPONSIVE, NAV_GRAPH, NAV_FWUPDATE, NAV_DISCOVERY, NAV_USERMANAGEMENT
} from '../actions';

import { createReducer } from './utils';

import UserIcon from 'grommet/components/icons/base/User';
const initialState = {
  active: true, // start with nav active
  enabled: true, // start with nav disabled
  responsive: 'multiple',
  items: [
    { path: '/Dashboard', label: 'Dashboard' },
    { path: '/Discovery', label: 'Discovery' },
    { path: '/fwupdate', label: 'Firmware Update' },
    { path: '/#', label: 'Application Management', refs:'parent' },
    // { path: '/#', sublabel: 'Console Configuration Tool', refs:'subchild' },
    { path: '/NetworkConfiguration', sublabel: 'Network Configuration', refs:'subchild' },
    { path: '/Certificatemanagement', sublabel: 'Certificate Management', refs:'subchild'},
    { path: '/UserManagement', sublabel: 'User Management', refs:'subchild'},
    // { path: '/#', sublabel: 'LDAP Integration', refs:'subchild'},
    { path: '/BackupRestore', sublabel: 'Application Configuration', refs:'subchild'},
    { path: '/Graph', label: 'Monitoring & Reporting' },
    { path: '/logs', label: 'Alerts and Event Logs' },
    { path: '/#', label: 'Active Tasks' }
  ]
};


const handlers = {
  [NAV_ACTIVATE]: (_, action) => (
    { active: action.active, activateOnMultiple: undefined }
  ),

  [NAV_ENABLE]: (_, action) => (
    { enabled: action.enabled }
  ),

  [NAV_GRAPH]: (_, action) => (
    { graph: action.graph }
  ),

  [NAV_FWUPDATE]: (_, action) => (
    { fwupdate: action.fwupdate }
  ),

  [NAV_DISCOVERY]: (_, action) => (
    { Discovery: action.Discovery }
  ),

  [NAV_USERMANAGEMENT]: (_, action) => (
    { Usermanagement: action.Usermanagement }
  ),

  [NAV_RESPONSIVE]: (state, action) => {
    const result = { responsive: action.responsive };
    if (action.responsive === 'single' && state.active) {
      result.active = false;
      result.activateOnMultiple = true;
    } else if (action.responsive === 'multiple' && state.activateOnMultiple) {
      result.active = true;
    }
    return result;
  }
};

export default createReducer(initialState, handlers);
