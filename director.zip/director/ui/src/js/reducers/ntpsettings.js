// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
  NTP_LOAD, NTP_SETTING, NTP_SETTING_FAILURE
} from '../actions';
import { createReducer } from './utils';

const initialState = {
  ntp1: undefined,
  ntp2: undefined,
  tz : [],
  restart_required:undefined,

};

const handlers = {
  [NTP_LOAD]: (state, action) => {
    return{
      ntp1: action.payload.NTP1,
      ntp2: action.payload.NTP2,
      tz: action.payload.TimeZones,
      restart_required: action.payload.restart_required
    };
  },
  [NTP_SETTING]: (state, action) => {
    return { ntpUpdate: action.payload };
  },

  [NTP_SETTING_FAILURE]: (state, action) => {
    if (!action.error) {
      return { err: action.payload.statusCode.message };
    } else if (action.payload.statusCode == 406) {
      return { err: 'Unable to establish connection.' };
    } else if (action.payload.statusCode == 500) {
      return { err: 'Internal Server Error' };
    } else {
      return { err: 'Unable to update the NTP settings.' };
    }
  }
};
export default createReducer(initialState, handlers);

