// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {LICENSE_LOAD, LICENSE_LOAD_FAILURE, LICENSE_UPLOAD, LICENSE_UPLOAD_FAILURE, DELETE_LICENSE, DELETE_LICENSE_FAILURE, UNLOAD_LICENSE, LICENSE_UUID, LICENSE_UUID_FAILURE} from '../actions';
import { createReducer } from './utils';

const initialState = {
    availableCapacity: undefined,
    licenseResp: undefined,
    licenseErr: undefined,
    deviceID: undefined,
    startDate: undefined,
    expirationDate: undefined,
    licenseId: undefined,
    licenselist: [],
    agg_availableCapacity: undefined,
    agg_deviceID: undefined,
    agg_expirationDate: undefined,
    agg_licenseId: undefined,
    agg_expired: undefined,
    status: undefined
};

const handlers = {

    [LICENSE_LOAD]: (state, action) => {
        let licenselist = [];
        if ( action.payload["Aggregated Licenses"][0] != undefined  && action.payload.Licenses != undefined) {
            
            for(let license=0; license < action.payload.Licenses.length; license++){
                licenselist.push({
                availableCapacity: action.payload.Licenses[license]["Available Capacity"],
                deviceID: action.payload.Licenses[license]["Node Locked Device ID"],
                startDate: action.payload.Licenses[license]["License Start Date"],
                expirationDate: action.payload.Licenses[license]["Expiration Date"],
                licenseId: action.payload.Licenses[license]["License ID"] })
            }
            return {    
                licenselist,
                agg_availableCapacity: action.payload["Aggregated Licenses"][0]["Available Capacity"],
                agg_deviceID: action.payload["Aggregated Licenses"][0]["Node Locked Device ID"],
                agg_startDat: action.payload["Aggregated Licenses"][0]["License Start Date"],
                agg_expirationDate:  action.payload["Aggregated Licenses"][0]["Expiration Date"],
                agg_licenseId: action.payload["Aggregated Licenses"][0]["License ID"],
                agg_expired: action.payload["Aggregated Licenses"][0]["Expired"] 
            }
        } 

        else {
            return  { licenselist };
        }
    },

    [LICENSE_LOAD_FAILURE]: (state, action) => {
        var message;
        if (action.payload.status == '500') {
            message = "Internal server error";
        } else if (action.payload.status >= '400') {
            message = "Failed to load license information";
        }
        return { licenseErr: message, licenseResp: undefined };
    },

    [LICENSE_UPLOAD]: (state, action) => {
        if (action.payload.Licenses != undefined) {
            let licenselist = [];
            for(let license=0; license < action.payload.Licenses.length; license++){
                licenselist.push({
                availableCapacity: action.payload.Licenses[license]["Available Capacity"],
                deviceID: action.payload.Licenses[license]["Node Locked Device ID"],
                startDate: action.payload.Licenses[license]["License Start Date"],
                expirationDate: action.payload.Licenses[license]["Expiration Date"],
                licenseId: action.payload.Licenses[license]["License ID"] })
            }
            return {licenselist, licenseResp: "License uploaded successfully", licenseErr: undefined};
        }
    },

    [LICENSE_UPLOAD_FAILURE]: (state, action) => {
        var message;
        if (action.payload.status >= '400') {
            message = "Failed to upload license file";
        }
        return { licenseErr: message, licenseResp: undefined };
    },

    [DELETE_LICENSE]: (state, action) => {
        return { licenseResp: "License deleted successfully", licenseErr: undefined };
    },

    [DELETE_LICENSE_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
          message = "Failed to delete license";
        }
        return { licenseErr: message, licenseResp: undefined };
    },

    [LICENSE_UUID]: (state, action) => {
        return {
            sysUuid: action.payload[0]
        };
    },

    [LICENSE_UUID_FAILURE]: (state, action) => {
        var message;
        if (action.payload.status == '500') {
            message = "Internal server error";
        } else if (action.payload.status >= '400') {
            message = "Failed to load system uuid information";
        }
        return { licenseErr: message, licenseResp: undefined };
    },

    [UNLOAD_LICENSE]: () => initialState
};

export default createReducer(initialState, handlers);