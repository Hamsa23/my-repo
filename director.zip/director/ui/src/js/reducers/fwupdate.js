// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { FWBUNDLE_LOAD, FWFLASH } from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
    [FWFLASH]: (state, action) => {  //Update below validations as required
      if (!action.error) {
        action.payload.error = undefined;
        return {
          FWFlashInfo: action.payload
         };
      }
      else if (action.payload.statusCode.status == 400)
      {
        return { FWFlashInfo: 'Malformed Syntax' };
      }
      else if (action.payload.statusCode.status >= 500)
      {
        return { FWFlashInfo: 'Internal Server Error' };
      }
      else return { FWFlashInfo: 'Unable to initiate Firmware Update.' };
    },
    [FWBUNDLE_LOAD]: (state, action) => {  //Update below validations as required
      if (!action.error) {
        action.payload.error = undefined;
        return {
          BundleInfo: action.payload
         };
      }
      else if (action.payload.statusCode.status == 401)
      {
        return { error: 'Unauthorized Login Attempt' };
      }
      else if (action.payload.statusCode.status == 400)
      {
        return { error: 'Malformed Syntax' };
      }
      else if (action.payload.statusCode.status >= 500)
      {
        return { error: 'Internal Server Error' };
      }
      else if (action.payload.statusCode.status >= 403)
      {
        return { error: 'Session Limit Exceeded' };
      }
      else return { error: 'Server Unreachable' };
    }
  };
  
  export default createReducer(initialState, handlers);