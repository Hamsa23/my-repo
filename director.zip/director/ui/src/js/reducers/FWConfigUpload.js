// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { FWCONFIGUPLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
    [FWCONFIGUPLOAD]: (state, action) => {  //Update below validations as required
      if (!action.error) {
        action.payload.error = undefined;
        return {
          UploadStatus: action.payload
         };
      }
      else if (action.payload.statusCode.status == 400)
      {
        return { UploadStatus: 'Malformed Syntax' };
      }
      else if (action.payload.statusCode.status == 409)
      {
        return { UploadStatus: 'File already exists' };
      }
      else if (action.payload.statusCode.status >= 500)
      {
        return { UploadStatus: 'Internal Server Error' };
      }
      else return { UploadStatus: 'Unable to Upload Config File' };
    }
  };
  
  export default createReducer(initialState, handlers);