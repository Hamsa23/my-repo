// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { REGISTER_SUCCESS, REGISTER_FAILURE } from '../actions';
import { createReducer } from './utils';

const initialState = {
    discoveryResp: undefined,
    discoveryErr: undefined,
    toggle: undefined
};

const handlers = {

    [REGISTER_SUCCESS]: (state, action) => {
        return {
            discoveryResp: action.payload,
            discoveryErr: undefined,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [REGISTER_FAILURE]: (state, action) => {
        var message;
        if (action.payload.status == '202') {
            message = "Server is already registered";
        } else {
            message = "Failed to discover the specified network target.  Please review the online help to ensure that you are specifying a valid IP network and subnet mask or CIDR value.";
        }
        return {
            discoveryResp: undefined,
            discoveryErr: message,
            toggle: (state.toggle == true) ? false : true
        };
    }
}

export default createReducer(initialState, handlers);