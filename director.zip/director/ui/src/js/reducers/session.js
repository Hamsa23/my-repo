// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
  SESSION_LOAD, SESSION_LOGIN, SESSION_LOGOUT
} from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
  [SESSION_LOAD]: (state, action) => {action.payload},
  [SESSION_LOGIN]: (state, action) => {
    if (!action.error) {
      return action.payload;
    }
    else if (action.payload.statusCode.status == 401)
    {
      return { error: 'Unauthorized Login Attempt' };
    }
    else if (action.payload.statusCode.status == 400)
    {
      return { error: 'Malformed Syntax' };
    }
    else if (action.payload.statusCode.status >= 500)
    {
      return { error: 'Internal Server Error' };
    }
    else if (action.payload.statusCode.status >= 403)
    {
      return { error: 'Session Limit Exceeded' };
    }
    else return { error: 'Server Unreachable' };
  },
  [SESSION_LOGOUT]: () => ({})
};

export default createReducer(initialState, handlers);
