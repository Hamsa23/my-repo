// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { GRAPH_LOAD, GRAPH_LOAD_FAILURE, GRAPH_UNLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
        sessionError: undefined,
        cpu: undefined,
        memory: undefined,
        network: undefined
};

const handlers = {
  [GRAPH_LOAD]: (state, action) => {
        return{
                cpu: action.payload.CPU,
                memory: action.payload.Memory,
                network: action.payload.Network
        };
  },
  [GRAPH_LOAD_FAILURE]: (state, action) => {
    var message;
    if (action.payload >= '404') {
      message = "Failed to load graph data";
    }
    return { sessionError: message };
  },
  [GRAPH_UNLOAD]: () => initialState
};

export default createReducer(initialState, handlers);