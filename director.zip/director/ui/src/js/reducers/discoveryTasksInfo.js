// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { DISCOVERY_TASKS_LOAD, DISCOVERY_TASKS_FAILURE, DISCOVERY_TASKS_DELETE, DISCOVERY_TASKS_DELETE_FAILURE, DISCOVERY_TASKS_UNLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
    discoveryTasks: undefined,
    discoveryTasksErr: undefined,
    delTaskResp: undefined,
    delTaskErr: undefined,
    toggle: undefined
};

const handlers = {

    [DISCOVERY_TASKS_LOAD]: (state, action) => {
        return {
            discoveryTasks: action.payload.Tasks,
            delTaskErr: undefined,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [DISCOVERY_TASKS_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
          message = "Failed to load discovery tasks data";
        }
        return {
            discoveryTasksErr: message,
            delTaskResp: undefined,
            delTaskErr: undefined,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [DISCOVERY_TASKS_DELETE]: (state, action) => {
        return {
            discoveryTasksErr: undefined,
            delTaskResp: action.payload,
            delTaskErr: undefined,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [DISCOVERY_TASKS_DELETE_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
          message = "Failed to delete discovery tasks";
        }
        return {
            discoveryTasksErr: undefined,
            delTaskResp: undefined,
            delTaskErr: message,
            toggle: (state.toggle == true) ? false : true
        };
    },

    [DISCOVERY_TASKS_UNLOAD]: () => initialState
};

export default createReducer(initialState, handlers);