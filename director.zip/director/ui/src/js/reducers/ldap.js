// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { LDAP_LOAD, LDAP_UNLOAD} from '../actions';
import { createReducer } from './utils';

const initialState = {  
  Enable: undefined,
  BindPassword: undefined,
  ServerUri: undefined,
  BindDn: undefined,
  UserSearch: undefined,
  DenyGroup: undefined,
  RequireGroup: undefined,
  err: undefined
};

const handlers = {
  [LDAP_LOAD]: (state, action) => {
    if (!action.error) {
      action.payload.error = undefined;
      return {
        Enable: action.payload.Enable,
        BindPassword: action.payload.BindPassword,
        ServerUri: action.payload.ServerUri,
        BindDn: action.payload.BindDn,
        UserSearch: action.payload.UserSearch,
        DenyGroup: action.payload.DenyGroup,
        RequireGroup: action.payload.RequireGroup
     	};
    }
  },
  [LDAP_UNLOAD]: (state, action) => {
    if (!action.error) {
      return { err: action.payload.statusCode.message };
    }
    else if (action.payload.statusCode == 403)
    {
      return  { err: 'Forbidden Operation' }
    }
    else if (action.payload.statusCode == 406)
    {
      return { err: 'Unable to establish LDAP connection.' };
    }
    else if (action.payload.statusCode == 500)
    {
      return { err: 'Internal Server Error' };
    }
    else return { err: 'Unable to perform operation. Please try again' };
  }
};

export default createReducer(initialState, handlers);
