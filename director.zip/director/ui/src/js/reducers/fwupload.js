// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
  NAVBUNDLE_LOAD, NAV_FWULOAD, NAVFWDELETE
} from '../actions';
    import { createReducer } from './utils';

const initialState = {

  fwuploadstatus: undefined
};

const handlers = {
  [NAV_FWULOAD]: (state, action) => {
    return {fwuploadstatus: action.payload.statusCode};
  },
    [NAVBUNDLE_LOAD]: (state, action) => {  //Update below validations as required
    if (!action.error) {
      action.payload.error = undefined;
      return {
        BundleInfo: action.payload
      };
    }
    else if (action.payload.statusCode.status == 401) {
      return {BundleInfo: 'Unauthorized Login Attempt'};
    }
    else if (action.payload.statusCode.status == 400) {
      return {BundleInfo: 'Malformed Syntax'};
    }
    else if (action.payload.statusCode.status >= 500) {
      return {BundleInfo: 'Internal Server Error'};
    }
    else if (action.payload.statusCode.status >= 403) {
      return {BundleInfo: 'Session Limit Exceeded'};
    }
    else return {BundleInfo: 'Server Unreachable'};
  },
    [NAVFWDELETE]: (state, action) => {  //Update below validations as required
    if (!action.error && action.payload.success != undefined) {
      return {
        ProfileInfo: action.payload
        };
    }
    else if (action.payload.error != undefined)
    {
      return { ProfileInfo: action.payload.error };
    }
    else return { ProfileInfo: 'Failed to perform Operation' };
  }
};
export default createReducer(initialState, handlers);
