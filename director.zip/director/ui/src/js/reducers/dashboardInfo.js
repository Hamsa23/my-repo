// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { DASHBOARD_LOAD, DASHBOARD_UNLOAD, DASHBOARD_FAILURE,CHANGE_STATE,CHANGESTATE_FAILURE } from '../actions';
import { createReducer } from './utils';

const initialState = {
  dashboardData: undefined,
  sessionError: undefined,
  poweroffmessage: undefined
};

const handlers = {
  [DASHBOARD_LOAD]: (state, action) => {
      return { dashboardData: action.payload };
    },
  [DASHBOARD_FAILURE]: (state, action) => {
    var message = undefined;
    if (action.payload >= '404') {
      message = "Bad response from backend";
    }
    return { sessionError: message };
  },
  [CHANGE_STATE]: (state,action) => {
  var message;
  if( action.payload.Messages[0].MessageID ==='Base.0.10.Success')
  {
    message ="Server powered off successfully, it will take few seconds to update the page";
  }
  return {poweroffmessage:message };
  },
  [CHANGESTATE_FAILURE]: (state, action) => {
    var message;
    if (action.payload.status >= '400') {
      message = "Failed to poweroff the server";
    }
    return { poweroffmessage: message };
  },
  [DASHBOARD_UNLOAD]: () => initialState
};

export default createReducer(initialState, handlers);
