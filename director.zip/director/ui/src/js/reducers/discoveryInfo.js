// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { SYSTEM_UNREGISTER_SUCCESS, SYSTEM_UNREGISTER_FAILURE } from '../actions';
import { createReducer } from './utils';

const initialState = {
    unregisterResp: undefined,
    unregisterErr: undefined,
    toggle: undefined
};

const handlers = {

  [SYSTEM_UNREGISTER_SUCCESS]: (state, action) => {

  if( action.payload.Messages[0].MessageID === "Base.1.0.Success")
  {
     var message = "Selected targets(s) are deleted";
         return {
           unregisterResp: message,
           unregisterErr: undefined,
           toggle: (state.toggle == true) ? false : true
         };
  }
    },

    [SYSTEM_UNREGISTER_FAILURE]: (state, action) => {
        var message;
        if (action.payload.status >= '400') {
            message = "Failed to unregister the selected systems(s)";
        } else {
            message = "No Systems to delete";
        }
        return {
            unregisterResp: undefined,
            unregisterErr: message,
            toggle: (state.toggle == true) ? false : true
        };
    }
};

export default createReducer(initialState, handlers);