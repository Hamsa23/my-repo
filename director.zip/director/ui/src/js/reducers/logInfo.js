// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { IEL_LOAD, IEL_UNLOAD, IEL_LOAD_FAILURE, IML_LOAD, IML_LOAD_FAILURE, IEL_LOGS_DELETE, IEL_LOGS_DELETE_FAILURE, IML_LOGS_DELETE, IML_LOGS_DELETE_FAILURE, IML_UNLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
    eventLogData: undefined,
    ielError: undefined,
    imlError: undefined,
    IELLogData: undefined,
    IMLLogData: undefined,
    iellogError: undefined,
    imllogError: undefined
};

const handlers = {
    [IEL_LOAD]: (state, action) => {
        return { eventLogData: action.payload, imlData: undefined, ielError: undefined };
    },
    [IEL_LOAD_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
            message = "Failed to load iLO service log";
        }
        return { ielError: message };
    },
    [IEL_UNLOAD]: () => initialState,
    [IML_LOAD]: (state, action) => {
        return { imlData: action.payload, eventLogData: undefined, imlError: undefined };
    },
    [IML_LOAD_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
            message = "Failed to load Integrated management log";
        }
        return { imlError: message };
    },
    [IEL_LOGS_DELETE]: (state, action) => {
        if (action.payload != undefined) {
            if( action.payload.hasOwnProperty("Messages") ) {
                return { IELLogData: action.payload.Messages[0].MessageID };
            }
            else {
                return { IELLogData: action.payload.error.code } ;
            }
        }
    },
    [IEL_LOGS_DELETE_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
            message = "IEL logs could not be cleared";
        }
        return { iellogError: message };

    },
    [IML_LOGS_DELETE]: (state, action) => {
        if (action.payload != undefined) {
            if( action.payload.hasOwnProperty("Messages") ) {
                return { IMLLogData: action.payload.Messages[0].MessageID };
            }
            else {
                return { IMLLogData: action.payload.error.code } ;
            }
        }
    },
    [IML_LOGS_DELETE_FAILURE]: (state, action) => {
        var message;
        if (action.payload >= '400') {
            message = "IML logs could not be cleared";
        }
        return { imllogError: message };

    },
    [IML_UNLOAD]: () => initialState

};



export default createReducer(initialState, handlers);
