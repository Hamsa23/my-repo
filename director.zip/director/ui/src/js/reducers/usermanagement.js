// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { USERMANAGEMENT_LOAD, USERMANAGEMENT_UNLOAD, SINGLEUSER_LOAD, SINGLEUSER_DELETE, USER_ADD, EDITUSER } from '../actions';
import { createReducer } from './utils';

const initialState = {
  Id: undefined,
  email: undefined,
  FirstName: undefined,
  LastName: undefined,
  UserName: undefined,
  mngacct: [],
  response: []
};

//Get all users
const handlers = {
  [USERMANAGEMENT_LOAD]: (state, action) => {
    if (!action.error) {
        let mngacct=[];
        for(let users=0;users<action.payload.Members.length;users++){
          mngacct.push({Id: action.payload.Members[users].Id,
          Email: action.payload.Members[users].Email,
          FirstName: action.payload.Members[users].FirstName,
          LastName:  action.payload.Members[users].LastName,
          UserName:  action.payload.Members[users].UserName})
        }
      return {mngacct};
    }
    return { error: action.payload };
  },

  [USERMANAGEMENT_UNLOAD]: (state, action) => {
    if (!action.error) {
       return action.payload;
     }
     else{
       return { error: 'Failed to load users' };
     }
     
  },

  //Single User Delete
  [SINGLEUSER_DELETE]: (state, action) => { 
    if (!action.error) {
      return { err: "User Successfully Deleted" };
    }
    else if(action.payload.statusCode.status == 400 ){
      return  { err: "User Does not Exists" }
    }
    else if(action.payload.statusCode.status == 403 ){
      return  { err: "Operation not permitted" }
    }
    else return { err: 'Operation not Supported' };
  },

  //Single User Get
  [SINGLEUSER_LOAD]: (state, action) => { 
    if (!action.error) {
      let response=[];
      response.push({Id: action.payload.Id,
        Email: action.payload.Email,
        FirstName: action.payload.FirstName,
        LastName:  action.payload.LastName,
        UserName:  action.payload.UserName})
      return {response};
    }
    return { error: action.payload };
  },

  //On Single User Add
  [USER_ADD]: (state, action) => {  
    if (!action.error) {
      return { err: "New User Successfully Added" };
    }
    else if(action.payload.statusCode.status == 202 ){
      return  { err: "User Already Exists" }
    }
    else if(action.payload.statusCode.status == 400 ){
      return  { err: "Bad Request" }
    }
  },

//On EDIT User Save
[EDITUSER]: (state, action) => {  
    if (!action.error) {
      if (action.payload.statusCode.Valid_Entries.length == 1) {
        return { err: "User password reset successfully" };
      }
      else {
        return { err: "User Successfully Modified" };
      }
    }
    else if(action.payload.statusCode.status == 400 ){
      return  { err: "User Does not Exists" }
    }
    else {
      return { err: "Failed to modify user details" }
    }
  }
};

export default createReducer(initialState, handlers);
