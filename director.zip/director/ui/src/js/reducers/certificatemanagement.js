// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {
    CERTIFICATE_LOAD
    } from '../actions';
    import { createReducer } from './utils';

const initialState = {

  error: undefined
};

const handlers = {

  [CERTIFICATE_LOAD]: (state, action) => {
    return { sslUpdate: action.payload };
  },

};

export default createReducer(initialState, handlers);

