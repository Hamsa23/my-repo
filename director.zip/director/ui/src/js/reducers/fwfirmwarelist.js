// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { NAVFWPROFILE } from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
    [NAVFWPROFILE]: (state, action) => {  //Update below validations as required
      if (!action.error) {
        action.payload.error = undefined;
        return {
          ProfileList: action.payload
         };
      }
      else if (action.payload.statusCode.status == 400)
      {
        return { ProfileList: 'Malformed Syntax' };
      }
      else if (action.payload.statusCode.status >= 500)
      {
        return { ProfileList: 'Internal Server Error' };
      }
      else return { ProfileList: 'Unable to get Profile list' };
    }
  };

  export default createReducer(initialState, handlers);
