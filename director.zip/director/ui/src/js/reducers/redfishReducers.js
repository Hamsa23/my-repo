// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import * as index from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
  [index.API_SUCCESS]: (state, action) => {  //Update below validations as required
    var  response = {};
    if(action.payload.hasOwnProperty("EIMDateAndTime")){ //date and time
      response = {DateAndTime :action.payload};
    } else {
      response = action.payload;
    }
      return {
        successResponse: response
      };
  },
  [index.API_ERROR]: (state, action) => {  //Update below validations as required
      return {
        errorResponse: action.payload
    }
  }
};

export default createReducer(initialState, handlers);