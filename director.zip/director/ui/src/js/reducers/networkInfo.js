// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { NETWORK_LOAD, NETWORK_LOAD_FAILURE, NETWORK_UNLOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
        sessionError: undefined,
        hostname: undefined,
        device: undefined,
        dns1: undefined,
        dns2: undefined,
        gateway: undefined,
        ipAddr: undefined,
        ipv6Addr: undefined,
        ipv6AutoConf: undefined,
        bootProto: undefined,
        uuid: undefined,
        onBoot: undefined,
        ipv6Init: undefined,
        netmask: undefined,
        dhcpv4: undefined,
        dhcpv6: undefined,
        bootProto: undefined,
        manualIpv6: undefined,
        networkSettingsUpdated: undefined,
        restartRequired: undefined,
        responseMessage: undefined
};

const handlers = {
  [NETWORK_LOAD]: (state, action) => {
        return{
                hostname: action.payload.HOSTNAME,
                device: action.payload.DEVICE,
                dns1: action.payload.DNS1,
                dns2: action.payload.DNS2,
                gateway: action.payload.GATEWAY,
                ipAddr: action.payload.IPADDR,
                ipv6Addr: action.payload.IPV6ADDR,
                ipv6Init: action.payload.IPV6INIT,
                ipv6AutoConf: action.payload.IPV6_AUTOCONF,
                netmask: action.payload.NETMASK,
                bootProto: action.payload.BOOTPROTO,
                uuid: action.payload.UUID,
                onBoot: action.payload.ONBOOT,
                dhcpv4: action.payload.dhscpv4,
                dhcpv6: action.payload.dhcpv6,
                manualIpv6: action.payload.manual_ipv6,
                networkSettingsUpdated: action.payload.network_settings_updated,
                restartRequired: action.payload.restart_required,
                responseMessage: action.payload.Response_Message
        };
  },
  [NETWORK_LOAD_FAILURE]: (state, action) => {
    var message;
    if (action.payload >= '404') {
      message = "Failed to load network settings";
    }
    return { sessionError: message };
  },
  [NETWORK_UNLOAD]: () => initialState
};

export default createReducer(initialState, handlers);