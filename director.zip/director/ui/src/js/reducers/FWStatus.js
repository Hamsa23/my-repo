// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { FWID } from '../actions';
import { createReducer } from './utils';

const initialState = {};

const handlers = {
    [FWID]: (state, action) => {  //Update below validations as required
      if (!action.error) {
        action.payload.error = undefined;
        return {
          FWIDInfo: action.payload
         };
      }
      else if (action.payload.statusCode.status == 400)
      {
        return { FWIDInfo: 'Malformed Syntax' };
      }
      else if (action.payload.statusCode.status >= 500)
      {
        return { FWIDInfo: 'Internal Server Error' };
      }
      else return { FWIDInfo: 'Unable to fetch firmware status ID' };
    },
  };
  
  export default createReducer(initialState, handlers);