// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { IPADDRESS_LOAD } from '../actions';
import { createReducer } from './utils';

const initialState = {
    eim_ipv4: undefined,
    eim_ipv6: undefined
};

const handlers = {

    [IPADDRESS_LOAD]: (state, action) => {
        return {
            eim_ipv4: action.payload.EIM_IPv4,
            eim_ipv6: action.payload.EIM_IPv6
        };
    },
};

export default createReducer(initialState, handlers);