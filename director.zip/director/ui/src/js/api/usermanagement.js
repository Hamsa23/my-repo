// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, RedfishUri, parseJSON } from './utils';

export function UserManagement() {
  const uri= RedfishUri() + 'AccountService/Accounts';
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function getSingleUser(event) {
  let userid = undefined; //reset the value to reuse
  userid = event;
  const uri= RedfishUri() + 'AccountService/Accounts/' + userid;
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function DelSingleUser(event) {
  let userid = undefined; //reset the value to reuse
  userid = event;
  const uri= RedfishUri() + 'AccountService/Accounts/' + userid;
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'DELETE', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function postAddUser(body) {
  const uri= RedfishUri() + 'AccountService/Accounts';
  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(body);
  let _postheaders = {
    'x-auth-token': authtoken
  };

  const payload = {
    method: 'POST',
    headers: _postheaders,
    mode: 'cors',
    body: load,
};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 201) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function postEditUser(id, body) {
  let userid = undefined; //reset the value to reuse
  userid = id;
  const uri= RedfishUri() + 'AccountService/Accounts/' + userid;
  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(body);
  let _postheaders = {
    'x-auth-token': authtoken
  };

  const payload = {
    method: 'PATCH',
    headers: _postheaders,
    mode: 'cors',
    body: load,
};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}
