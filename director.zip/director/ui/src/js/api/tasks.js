// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import RequestWatcher from './request-watcher';

let protocol = 'ws:';
if (window.location.protocol === 'https:') {
  protocol = 'wss:';
}
const host = ((process.env.NODE_ENV === 'development') ?
  'localhost:8102' : `${window.location.host}`);
const webSocketUrl = `${protocol}//${host}`;

const socketWatcher = new RequestWatcher({ webSocketUrl });

let tasksWatcher;

export function watchTasks() {
  tasksWatcher = undefined;
  return tasksWatcher;
}

export function unwatchTasks() {
  if (tasksWatcher) {
    tasksWatcher.stop();
  }
}

const taskWatcher = {};

export function watchTask(id) {
  
}

export function unwatchTask(id) {

}

