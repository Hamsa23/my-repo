// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri,bootUri, parseJSON } from './utils';

export function ImportCertificate(certfile, keyfile) {
    const uri= EsmUri() + 'SSL';//Api calling for ssl certificate
    let x_auth_token = localStorage.getItem('token');
    let head = {
      'x-auth-token': x_auth_token
    };
    let data = new FormData();
    data.append('cert', certfile);
    data.append('key',keyfile);
    const payload = {
      method: 'POST',
      headers: head,
      body: data,
    };
    return fetch(uri, payload)
    .then((response) =>{
      if(response.ok) {
        return response.json();
        }
      return Promise.reject(response);
    })
  }
  
   