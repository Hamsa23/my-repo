// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, parseJSON } from './utils';

export function FWBundleList() {
  const uri= EsmUri() + 'firmware/config';
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
  }


  export function FWUpdateRequest(body) {
    const uri= EsmUri() + 'firmware';
    let authtoken = window.localStorage.getItem('token');
    const load = JSON.stringify(body);
    let _postheaders = {
      'x-auth-token': authtoken
    };
  
    const payload = {
      method: 'POST',
      headers: _postheaders,
      mode: 'cors',
      body: load,
  };
  
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 202) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }

  export function UploadConfigurationFile(file, val) {
    const uri= EsmUri() + 'firmware/config';
    let authtoken = window.localStorage.getItem('token');
    let _postheaders = {
      'x-auth-token': authtoken
    };
    let data = new FormData();
    data.append('firmware_config', file);
    //Only send FW bundle value if selected
    if(val != undefined){ 
      data.append('bundle_name', val);
    }

    const payload = {
      method: 'POST',
      headers: _postheaders,
      mode: 'cors',
      body: data,
    };
  
    // Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
        }
        return Promise.reject(response);
      })
  }

  export function GetFWIDInfo() {
    const uri= EsmUri() + 'task_manager';
    let authtoken = window.localStorage.getItem('token');
    let _headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': authtoken
    };
    const payload = { method: 'GET', headers: _headers};
  
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }

  export function GetFWProfileInfo() {
    const uri= EsmUri() + 'firmware/repository';
    let authtoken = window.localStorage.getItem('token');
    let _headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': authtoken
    };
    const payload = { method: 'GET', headers: _headers};
  
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }

  export function DeleteProfileInfo(profilelist) {
    const uri= EsmUri() + 'firmware/config';
    let authtoken = window.localStorage.getItem('token');
    const load = JSON.stringify(profilelist);
    let _headers = {
      'x-auth-token': authtoken
    };
    const payload = { method: 'DELETE', headers: _headers, body: load};
  
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }

