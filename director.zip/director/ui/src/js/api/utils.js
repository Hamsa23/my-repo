// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import RequestWatcher from './request-watcher';

let _headers = {
  Accept: 'application/json',
  'Content-Type': 'application/json'
};

let Host = window.location.host;
let _RedfishUri = 'https://'+ Host+'/redfish/v1/'; //Red fish API
let _EsmUri = 'https://'+ Host+'/eim/v1/'; //Non Red fish API
let timeoutMsg = 'Session Expired. Please login again';

export function headers() {
  return _headers;
}

export function parseJSON(response) {
  if(response.status == 201) {
    return response.json();
  }
  return Promise.reject(response);
}

export function updateHeaders(newHeaders) {
  _headers = { ..._headers, newHeaders };
  Object.keys(_headers).forEach((key) => {
    if (undefined === _headers[key]) {
      delete _headers[key];
    }
  });
}

export function RedfishUri() {
  return _RedfishUri;
}
export function EsmUri() {
  return _EsmUri;
}
export function getHost() {
  return Host;
}
export function getTimeoutMsg() {
  return timeoutMsg;
}


export const requestWatcher = new RequestWatcher();
