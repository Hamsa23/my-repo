// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, getHost, parseJSON } from './utils';

export function sendRedfishAPIRequest(apiMethord, uri, inputPayload = undefined) {

  const url = 'https://' + getHost() + uri;
  const authtoken = window.localStorage.getItem('token');
  var _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  var payload ;

  if (apiMethord.toUpperCase() == ('POST') ||( apiMethord.toUpperCase() == 'PATCH')) {//Post OR PATCH
    payload = {
      method: apiMethord,
      headers: _headers,
      mode: 'cors',
      body: inputPayload
    };
  } else if (apiMethord.toUpperCase() == 'DELETE') {//Delete
    payload = {
      method: apiMethord,
      headers: _headers,
      mode: 'cors'
    };

  } else if (apiMethord.toUpperCase() == 'GET') {//Get
    if (uri !== '/redfish/v1') {
      payload = { method: apiMethord, headers: _headers };
      //need to remove the x-auth-token from the header
    } else {      
    }
  }

  return fetch(url, payload)
    .then((response) => {
      if (response.status == 200 || response.status == 201 || response.status == 202) {
        var resp = response.json();
        return resp;
      }
      return Promise.reject(response);
    })
}