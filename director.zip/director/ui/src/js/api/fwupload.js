// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {EsmUri, RedfishUri} from './utils';

export function firmwareupload(firmware_file) {
    const uri= EsmUri() + 'firmware/repository';//Api calling for storing the firmware file and bundle
    let x_auth_token = localStorage.getItem('token');
    let head = {
      'x-auth-token': x_auth_token
    };
    let data = new FormData();

    data.append('firmware', firmware_file);
    const payload = {
      method: 'POST',
      headers: head,
      mode: 'cors',
      body: data,
    };
    return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 201) {
        return response.status;
        }
      return Promise.reject(response.status);
    })
  }

  export function FWBundleList() {
  const uri= EsmUri() + 'firmware/config';
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

  export function GetFWProfileInfo() {
    const uri= EsmUri() + 'firmware/repository';
    let authtoken = window.localStorage.getItem('token');
    let _headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': authtoken
    };
    const payload = { method: 'GET', headers: _headers};

    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }


  export function DelFW(profilelist, firmwarelist) {
    const uri= EsmUri() + 'firmware/repository';
    let authtoken = window.localStorage.getItem('token');
     let load = undefined;
    if (firmwarelist.length == 0) {

          load = '{"bundles": ' + JSON.stringify(profilelist) + '}';
    } else if(profilelist.length ==0) {

          load = '{"firmware": ' + JSON.stringify(firmwarelist) + '}';
    } else if(firmwarelist.length != 0 && profilelist.length !=0 ) {

          load = '{"firmware": ' + JSON.stringify(firmwarelist) + ',"bundles": ' + JSON.stringify(profilelist) + '}';
     }

    let _headers = {
      'x-auth-token': authtoken
    };
    const payload = { method: 'DELETE', headers: _headers, body: load};

    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{

        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }
