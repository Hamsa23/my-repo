// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri,parseJSON } from './utils'

export function Backup(file) {
  const uri= EsmUri() + 'Config';//accessing API for file downloading
  let x_auth_token = localStorage.getItem('token')
  let head = {
    'x-auth-token': x_auth_token
  };

  const options = { method: 'GET', headers: head};
  return fetch(uri, options) //Getting Response from Backend API
  .then(function(response) {
    if (response.status >= 400) {
      throw new Error("Bad response from server");
    }
    if(response.status >= 200){
      var str = JSON.stringify(response);
    }
    return response.json();
  })
  }

  export function SupportDump(file) {
    const uri= EsmUri() + 'supportdump';//accessing API for file downloading
    let x_auth_token = localStorage.getItem('token')
    let head = {
      'x-auth-token': x_auth_token
    };
  
    const options = { method: 'GET', headers: head};
    return fetch(uri, options) //Getting Response from Backend API
    .then(function(response) {
      if (response.status >= 400) {
        throw new Error("Bad response from server");
      }
      if(response.status >= 200){
        var str = JSON.stringify(response);
      }
      return response.arrayBuffer();
    })
    }
