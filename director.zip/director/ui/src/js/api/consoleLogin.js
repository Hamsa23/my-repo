// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { getHost } from '../api/utils';

export function ResetPassword(passwordData) {
    const uri= 'https://' + getHost() + '/private/AdminPassReset';
    const data = JSON.stringify(passwordData);
    let head = {
      'Content-Type': 'application/json'
    };
    const payload = {
      headers: head,
      method: 'POST',
      body: data,
      mode: 'cors'
  }; 
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response;
          }
        return Promise.reject(response);
      })
  }

  export function FactoryResetEIM(resetData) {
    const uri= 'https://' + getHost() + '/private/ResetAppliance';
    const data = JSON.stringify(resetData);
    let head = {
      'Content-Type': 'application/json'
    };
    const payload = {
      headers: head,
      method: 'POST',
      body: data,
      mode: 'cors'
  }; 
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response;
          }
        return Promise.reject(response);
      })
  }

  export function GetIPaddress() {
    const uri= 'https://' + getHost() + '/private/EIMApplianceIP';
    let _headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json'
    };
    const options = { method: 'GET', headers: _headers};
  
    //Perform get request
    return fetch(uri, options)
    .then((response) =>{
        if(response.status == 200) {
          return response.json();
        }
        return Promise.reject(response);
      })
  }
  