// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { EsmUri } from './utils';

export function DiscoveryTasks() {
    const uri= EsmUri() + 'celery_tasks';
    let auth1 = window.localStorage.getItem('token');
    let _headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-auth-token': auth1
    };
    const options = { method: 'GET', headers: _headers};

    //Perform get request
    return fetch(uri, options)
    .then((response) =>{
        if(response.status == 200) {
            return response.json();
        }
        return Promise.reject(response);
    })
}
export function DelTask(delTask) {
    let Host = window.location.host;
    const uri= 'https://' + Host + delTask;
    let x_auth_token = localStorage.getItem('token');
    let _headers = {
        'x-auth-token': x_auth_token
    };
    const payload = {
        headers: _headers,
        method: 'DELETE',
        mode: 'cors'
    };
    //Perform Post request
    return fetch(uri, payload)
        .then((response) =>{
          if(response.status == 200) {
              return response.json();
          }
          return Promise.reject(response);
        })
}
