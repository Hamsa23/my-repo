// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, RedfishUri, parseJSON } from './utils';

export function postSession(UserName, Password) {
  const uri= RedfishUri() + 'SessionService/Sessions';
  const credentials = JSON.stringify({ UserName, Password })

  const payload = {
    method: 'POST',
    headers: headers(),
    mode: 'cors',
    body: credentials,
};


  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 201) {
        return response;
        }
      return Promise.reject(response);
    })
}

export function getRedfish() {
  const uri= RedfishUri();
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json'
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function deleteSession(session) {
  const session_id = localStorage.location.toLowerCase();
  const uri = RedfishUri() + 'SessionService/Sessions/' + session_id;
  let authtoken = window.localStorage.getItem('token');	
  
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  
  const options = {
    headers: _headers,
	method: 'DELETE'
  };

  return fetch(uri, options)
	.then((response) =>{
      if(response.status == 200) {
        return response.json();
      }
    return Promise.reject(response);
    })
}
