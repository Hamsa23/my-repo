// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import {EsmUri} from '../api/utils';

export function Graph() {
    const uri= EsmUri() + 'ui/graph_metrics';
    let auth1 = window.localStorage.getItem('token');
    let _headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-auth-token': auth1
    };
    const options = { method: 'GET', headers: _headers};
  
    //Perform get request
    return fetch(uri, options)
    .then((response) =>{
        if(response.status == 200) {
            return response.json();
        }
        return Promise.reject(response);
    })
}