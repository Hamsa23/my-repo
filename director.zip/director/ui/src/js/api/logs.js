// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { RedfishUri } from './utils';

export function EventLogs(target, pageNum) {
  var uri = "";
  var server = target.split(":");
  if(server[1] == "true" ) {
       uri = RedfishUri() + 'Managers/' + server[0] + 'M1/LogServices/EventLog/Entries?expand=1';
  } else {
      if(pageNum > 1) {
        uri = RedfishUri() + 'Managers/' + server[0] + 'M1/Logservices/IEL/Entries?page=' + pageNum;
      }
      else {
       uri = RedfishUri() + 'Managers/' + server[0] + 'M1/Logservices/IEL/Entries';
      }
  }

  let auth1 = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': auth1
  };
  const options = { method: 'GET', headers: _headers };

  //Perform get request
  return fetch(uri, options)
    .then((response) => {
      if (response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}

export function IMLogs(target, pageNum) {
  var uri = "";
  var server = target.split(":");

   if(server[1] == "true" ) {
    uri = RedfishUri() + 'Systems/' + server[0] + '/LogServices/HealthLog/Entries?expand=1';
  } else {
    if(pageNum > 1) {
      uri = RedfishUri() + 'Systems/' + server[0] + '/LogServices/IML/Entries?page=' + pageNum;
    }
    else {
      uri = RedfishUri() + 'Systems/' + server[0] + '/LogServices/IML/Entries';
    }
  } 

  let auth1 = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': auth1
  };
  const options = { method: 'GET', headers: _headers };

  //Perform get request
  return fetch(uri, options)
    .then((response) => {
      if (response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}

//delete IEL 
export function DeleteIELlogs(target, body) {
  var uri = "";
  var server = target.split(":");
  if(server[1] == "true" ) {
    uri = RedfishUri() + 'Managers/' + server[0] + 'M1/LogServices/EventLog/Actions/LogService.ClearLog';
    body = {};
  }
  else {
    uri = RedfishUri() + 'Managers/' + server[0] + 'M1/Logservices/IEL';
  }

  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(body);
  let _headers = {
    'x-auth-token': authtoken
  };
  const payload = { method: 'POST', headers: _headers, mode: 'cors', body: load };


  return fetch(uri, payload)
    .then((response) => {
      if (response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}

//Delete IML 
export function DeleteIMLlogs(target, body) {
  var uri = "";
  var server = target.split(":");
  if(server[1] == "true" ) {
    uri = RedfishUri() + 'Systems/' + server[0] + '/LogServices/HealthLog/Actions/LogService.ClearLog';
    body = {};
  }
  else {
    uri = RedfishUri() + 'Systems/' + server[0] + '/LogServices/IML'
  }

  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(body);
  let _headers = {
    'x-auth-token': authtoken
  };
  const payload = { method: 'POST', headers: _headers, mode: 'cors', body: load };


  return fetch(uri, payload)
    .then((response) => {
      if (response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}