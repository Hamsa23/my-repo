// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { RedfishUri } from './utils';

export function UnRegisterMultipleSystem(IPs) {
    const uri= RedfishUri() + 'Systems';
    let x_auth_token = localStorage.getItem('token');
    let _headers = {
        'x-auth-token': x_auth_token
    };
    const load = JSON.stringify({IPs});
    const payload = {
        headers: _headers,
        method: 'DELETE',
        mode: 'cors',
        body:load
    };
    //Perform Post request
    return fetch(uri, payload)
        .then((response) =>{
          if(response.status == 200) {
              return response.json();
          }
          return Promise.reject(response);
        })
}
