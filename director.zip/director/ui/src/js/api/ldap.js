// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, parseJSON } from './utils';

export function GetLDAPInfo() {
  const uri= EsmUri() + 'ldap';
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform GET request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function PostLDAPInfo(body) {
  const uri= EsmUri() + 'ldap';
  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(body);
  let _postheaders = {
    'x-auth-token': authtoken
  };

  const payload = {
    method: 'POST',
    headers: _postheaders,
    mode: 'cors',
    body: load,
};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response());
    })
}

export function TestLDAPInfo() {
  const uri= EsmUri() + 'ldap/connection';
  let authtoken = window.localStorage.getItem('token');
  let _postheaders = {
    'x-auth-token': authtoken
  };

  const payload = {
    method: 'GET',
    headers: _postheaders
};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response());
    })
}
