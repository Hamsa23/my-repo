// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, RedfishUri, parseJSON } from './utils';


export function getChassisList() {
  const uri= EsmUri() + 'ui/dashboard/system_summary';
  let auth1 = window.localStorage.getItem('token');
  let _headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': auth1
  };
  const options = { method: 'GET', headers: _headers};

  //Perform get request
  return fetch(uri, options)
  .then((response) =>{
      if(response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}


export function getPowerReport(chassisIdx) {
  const uri= RedfishUri() + 'Chassis/' + chassisIdx + '/Power';
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function getThermalReport(chassisIdx) {
  const uri= RedfishUri() + 'Chassis/' + chassisIdx + '/Thermal';   
  let authtoken = window.localStorage.getItem('token');
  let _headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'x-auth-token': authtoken
  };
  const payload = { method: 'GET', headers: _headers};

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}
