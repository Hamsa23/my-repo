// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { EsmUri } from '../api/utils';

export function Eimboot(resetdata) {
    const uri= EsmUri() + 'reboot';
    const credential = JSON.stringify(resetdata)
    let x_auth_token = localStorage.getItem('token')
    let head = {
      'x-auth-token': x_auth_token,
      'Content-Type': 'application/json'
    };
    const payload = {
      headers: head,
      method: 'POST',
      body: credential,
      mode: 'cors'
  }; 
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response;
          }
        return Promise.reject(response);
      })
  }