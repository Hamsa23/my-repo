// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, parseJSON } from './utils';

export function EventLogs() {
    const uri= EsmUri() + 'ui/event_reporting';
    let authtoken = window.localStorage.getItem('token');
    let _headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-auth-token': authtoken
    };
    const payload = { method: 'GET', headers: _headers};
  
    //Perform Post request
    return fetch(uri, payload)
      .then((response) =>{
        if(response.status == 200) {
          return response.json();
          }
        return Promise.reject(response);
      })
  }