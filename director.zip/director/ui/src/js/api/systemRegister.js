// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { RedfishUri } from './utils';

export function RegisterSystem(regData) {
    const uri= RedfishUri() + 'Systems';
    const data = JSON.stringify(regData);
    let x_auth_token = localStorage.getItem('token');
    let _headers = {
        'x-auth-token': x_auth_token
    };
    const payload = {
        headers: _headers,
        method: 'POST',
        body: data,
        mode: 'cors'
    };
    //Perform Post request
    return fetch(uri, payload)
        .then((response) =>{
          if(response.status == 201) {
              return response.json();
          }
          return Promise.reject(response);
        })
}

