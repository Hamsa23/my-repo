// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, parseJSON } from './utils';

export function NtpPost(ntpdata) {
  const uri= EsmUri() + 'NtpConf';
  let authtoken = window.localStorage.getItem('token');
  const load = JSON.stringify(ntpdata);
  let _postheaders = {
    'x-auth-token': authtoken
  };

  const payload = {
    method: 'POST',
    headers: _postheaders,
    mode: 'cors',
    body: load,
  };

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
      }
      return Promise.reject(response);
    })
}
