// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { EsmUri } from './utils';

export function loadLicense() {
    const uri= EsmUri() + 'license';//Api calling for fetching the EIM license information
    let x_auth_token = localStorage.getItem('token');
    let head = {
      'x-auth-token': x_auth_token
    };
    const payload = {
      method: 'GET',
      headers: head
    };
    return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function uploadLicense(licenseFile) {
    const uri= EsmUri() + 'license';//Api calling for uploading the license file
    let x_auth_token = localStorage.getItem('token');
    let head = {
      'x-auth-token': x_auth_token
    };
    let data = new FormData();
    data.append('license', licenseFile);
    const payload = {
      method: 'POST',
      headers: head,
      body: data
    };
    return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function deleteLicense(licenseId) {
  var uri = "";  
  if(licenseId == undefined) {
       uri = EsmUri() + 'license';  //Api calling for deleting all license files
    }
    else {
       uri = EsmUri() + 'license/' + licenseId;   //Api calling for deleting the specific license file
    }
    let x_auth_token = localStorage.getItem('token');
    let head = {
      'x-auth-token': x_auth_token
    };

    const payload = {
      method: 'DELETE',
      headers: head
    };
    return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 200) {
        return response.json();
        }
      return Promise.reject(response);
    })
}

export function loadSysUuid() {
  const uri= EsmUri() + 'system_uuid';//Api calling for fetching the system uuid information
  let x_auth_token = localStorage.getItem('token');
  let head = {
    'x-auth-token': x_auth_token
  };
  const payload = {
    method: 'GET',
    headers: head
  };
  return fetch(uri, payload)
  .then((response) =>{
    if(response.status == 200) {
      return response.json();
      }
    return Promise.reject(response);
  })
}