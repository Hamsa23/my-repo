// (C) Copyright 2019 Hewlett Packard Enterprise Development LP

import { headers, EsmUri, parseJSON } from './utils';

export function Restore(file) {
  const uri= EsmUri() + 'Config';
  let authtoken = window.localStorage.getItem('token');
  let _postheaders = {
    'x-auth-token': authtoken
  };

  let data = new FormData();
  data.append('json_config_file', file);
  const payload = {
    method: 'POST',
    headers: _postheaders,
    mode: 'cors',
    body: data,
  };

  //Perform Post request
  return fetch(uri, payload)
    .then((response) =>{
      if(response.status == 201) {
        return response.json();
      }
      return Promise.reject(response);
    })
}
