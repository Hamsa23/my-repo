module.exports = {
  Tasks: 'Tasks'
};
