module.exports = {
  Tasks: 'Tarefas'
};
